# Hello CodeBot - generated application

Thank you for building your application with CodeBot!

For complete CodeBot documentation (including a Parallel Agile process guide), see: https://parallelagile.github.io/CodeBot


## Contents of this zipfile

This zipfile contains the complete generated code suite. It consists of the following packages:

1. Domain classes (Java "POJOs" etc) - in `DomainClasses`
2. Client libraries including a Redux client-side state-management library - in the `Clients` directory
3. Server-side REST API which connects to a MongoDB database - in `Server`
4. React web-app - in `UX`

Each package has its own README.md file with setup instructions.

The Redux and React suites are only created if your model includes UI wireframes.


## Cloud hosting

Do consider our AWS-based cloud hosting service, "one-click generate, build and deploy". Among other things, it's ideal for trying out quick proof-of-concepts. We also offer managed hosting for UAT and production systems.

If you have questions or encounter any problems, please email us (support@parallelagile.com) and we'll do our best to help out.
