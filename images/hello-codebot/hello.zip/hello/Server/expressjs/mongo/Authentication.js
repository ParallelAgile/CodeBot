const jwt = require("jsonwebtoken");
const config = require('config');
const crypto = require('crypto');
const Error = require('./errors.js')

const saltRounds = 10;
const passwordHashSalt = config.get("authentication.passwordHashSalt");

const Auth = {
  generateOptions: {
    algorithm: 'HS256',
    expiresIn: '300m'
  },
  verifyOptions: {
    algorithms: ['HS256']
  },
  jwtSecret: config.get("authentication.jwt.secret"),

  // This is set by UserApi to avoid a circular Node dependency:
  identityApi: {}
}

if (Auth.jwtSecret === "SECRET") {
  console.log("** The JWT private key needs to be configured **");
}
if (passwordHashSalt === "SECRET") {
  console.log("** The password hash salt needs to be configured **");
}

Auth.hashPassword = password => {
  return crypto.pbkdf2Sync(password, passwordHashSalt, saltRounds, 64, "sha512").toString("hex");
}

// JWT middleware function
Auth.authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  if (authHeader === undefined) {
    return res.status(401).send(Error.errorJson("Authorization header required."));
  }
  const token = authHeader.toLowerCase().startsWith("bearer ")? authHeader.split(' ')[1] : authHeader;

  jwt.verify(token, Auth.jwtSecret, Auth.verifyOptions, (err, decoded) => {
    if (err) {
      console.log(err);
      const msg = err.name == "TokenExpiredError"? "Session has expired" : "Authentication failed";
      return res.status(403).send(Error.errorJson(msg));
    }

    Auth.identityApi.callFindOne(
      { username: decoded.username }, {}, res,
      notFound => {
        console.log("User details not found for " + decoded.username);
        res.status(401).send(Error.errorJson("Unable to locate User details matching your login."));
      },
      result => {
        delete result.password;
        req.user = result;
        next();
      }
    );
  })
}

Auth.generateAccessToken = username => {
  if (!Auth.jwtSecret) {
    console.log("JWT_SECRET environment variable must be set.");
  }
  const payload = {
    username: username
  }
  return jwt.sign(payload, Auth.jwtSecret, Auth.generateOptions);
}

module.exports = Auth;
