const express = require('express');
const router = express();
const _ = require('lodash');
const config = require('config');
const adapter = require('../adapters/VideoAdapter.js');
const typeConverter = require("../type_converter.js");
const authentication = require('../Authentication.js')
const authorisation = require('../Authorisation.js').instance;
const apiHelper = require("./ApiHelper.js");
const VideoDao = require("../database/VideoDao.js");
const Validator = require('jsonschema').Validator;
const $RefParser = require("@apidevtools/json-schema-ref-parser");
const Error = require('../errors.js')


const VideoApi = {
    attribute_schema: {},
    jsonValidator: new Validator(),

    ensureIndexes: () => {
        VideoDao.ensureIndexes();
    },

    callOnStart: () => {
        VideoApi.onStart();
    }
};

VideoApi.onStart = () => {
}



$RefParser.dereference('json_schema/Video.schema.json', (err, schema) => {
    if (err) {
        console.error(err);
        throw "Unable to dereference the VideoApi schema"
    }
    VideoApi.attribute_schema = schema.definitions.Video;
});


VideoApi.validateField = (field, minLength, maxLength) => {
    if (minLength===undefined) minLength = 0;
    if (maxLength===undefined) maxLength = 100;

    return field !== undefined &&
            field.length > minLength &&
            field.length < maxLength;
}

VideoApi.toResponse = entity => {
    return entity;
}

// middleware function
VideoApi.validate = (req, res, next) => {
    const useJsonSchema = config.get("validation.useJsonSchema")
    const data = Array.isArray(req.body) ? req.body : [req.body];

    if (useJsonSchema === true || useJsonSchema === "true") {
        const validatorSettings = {
            throwError: false,
            allowUnknownAttributes: false
        }

        const allErrors = data.reduce((acc, entity)=> {
            delete entity.id;
            const result = VideoApi.jsonValidator.validate(entity, VideoApi.attribute_schema, validatorSettings);
            if (result.valid) {
                return acc;
            } else {
                const errs = result.errors.map(err =>
                    err.stack.replace(/\"/g, "'").replace(/^instance /, "").replace(/^instance\./, ""));
                return acc.concat(errs);
            }
        }, []);

        if (allErrors.length === 0) {
            next();
        } else {
            res.status(400).send({
                "message": "Validation failed",
                "validationErrors": allErrors,
                "directive": {}
            });
        }
    } else {
        next();
    }
}

/**
 * Ref. the domain model, this is composed from all the aggregation references
 * from the logged-in user directly to Video.
 */
VideoApi.referencesFromOwner = user => {
   // The User isn't a direct parent of Video via aggregation, so no 'owner' references:
   return [];
}

// middleware
VideoApi.findOwnerReferences = (req, res, next) => {
    const id = req.params.id;
    const referencesFromOwner = VideoApi.referencesFromOwner(req.user);
    authorisation.ensureAuthorisationObject(req, {
        referencesFromOwner: referencesFromOwner,
        isOwnEntity: referencesFromOwner.includes(id)
    });
    next();
}


VideoApi.prepareForCreate = rec => {
    const data = adapter.prepForCreate(
        typeConverter.convert(rec, VideoApi.attribute_schema)
    );
    delete data["id"];
    delete data["_id"];
    return data;
}

VideoApi.callCreate = (data, res, onSuccess) => {
    VideoDao.create(data,
        failed => {
            res.status(500).send(failed);
        },
        createError => {
            res.status(400).send(createError);
        },
        result => {
            onSuccess(result);
        }
    );
};

VideoApi.onCreate = 

VideoApi.onReadMany = (wrappedData) => {
 if (wrappedData.items.length === 0) {
     wrappedData.items = [
      {
    id: "1",
       name: "Generating complete web apps including UI and database",
       url: "https://youtu.be/ZUm6esxrua8"
      },
      {
    id: "2",
       name: "Domain Driven Database Design",
       url: "https://youtu.be/zsfj64Wmdek"
      }
     ];
 }
}



// Create a new Video. Pass in a JSON array to create many.
router.post('/',
    authentication.authenticateToken,
    authorisation.authorise,
    VideoApi.validate,

    function (req, res) {
        try {
            if (typeof req.body !== "undefined") {
                const fromArray = Array.isArray(req.body)
                const records = fromArray? req.body : [req.body];
                if (records.length === 0) return res.status(400).send(Error.errorJson("The supplied array was empty."));

                // Run the Video.onCreate function defined in the UML model:
                const onCreateResults = records.map(rec => {
                    const onCreateResult = VideoApi.onCreate(rec, req.user);
                    return onCreateResult? {left: onCreateResult} : {right: VideoApi.prepareForCreate(rec)};
                });

                const vetoes = onCreateResults.filter(result => result.left).map(result => result.left);
                if (vetoes.length > 0) {
                    return apiHelper.sendCombinedVetoResponse(vetoes, fromArray, res);
                }

                VideoApi.callCreate(records, res,
                    result => {
                        const newItems = result.data;
                        const reply = {
                            data: fromArray? newItems : newItems[0] || {},
                            directive: apiHelper.ensureDirective(req)
                        }

                        res.status(201).send(reply);
                    }
                );

            } else {
                res.status(400).send(Error.errorJson("POST body is missing"));
            }
        } catch(err) {
            res.status(500).send(Error.handleError("POST", err));
        }
    }
);

VideoApi.readOne = (req, res, next) => {
    try {
        const id = req.params["id"];
        if (id === undefined || id.length === 0) {
            return res.status(400).send(Error.errorJson("Invalid id query-parameter"));
        }
        VideoApi.callReadOne(id, res, video => {
            req.entity = video;
            next();
        });
    } catch (err) {
        res.status(500).send(Error.handleError("GET", err));
    }
}

VideoApi.callReadOne = (id, res, onSuccess) => {
    VideoDao.readOne(id,
        failed => {
            res.status(500).send(failed);
        },
        queryError => {
            res.status(400).send(queryError);
        },
        notFound => {
            res.status(404).send(notFound);
        },
        result => {
            onSuccess(result);
        }
    )
};

VideoApi.callFindOne = (query, options, res, onNotFound, onSuccess) => {
    VideoDao.findOne(query, options,
        failed => {
            res.status(500).send(failed);
        },
        queryError => {
            res.status(400).send(queryError);
        },
        notFound => {
            onNotFound(notFound);
        },
        result => {
            onSuccess(result);
        }
    )
};

// Count the total number of Video records.
// Appears before router.get("/:id") to take precedence.
router.get(
    '/count',
    authentication.authenticateToken,
    authorisation.authorise,

    function (req, res) {
        try {
            VideoDao.countAll(
                failed => {
                    res.status(500).send(failed)
                },
                queryError => {
                    res.status(400).send(queryError)
                },
                result => {
                    const directive = apiHelper.ensureDirective(req)
                    const reply = {
                        data: {
                            count: result
                        },
                        directive: directive
                    }
                    res.status(200).send(reply)
                }
            )
        } catch (err) {
            res.status(500).send(Error.handleError("GET", err))
        }
    }
);

// Count the number of Video records matching the JSON query in the request body.
router.post(
    '/count',
    authentication.authenticateToken,
    authorisation.authorise,

    function (req, res) {
        try {
            const query = req.body
            VideoDao.count(
                query,

                failed => {
                    res.status(500).send(failed)
                },
                queryError => {
                    res.status(400).send(queryError)
                },
                result => {
                    const directive = apiHelper.ensureDirective(req)
                    const reply = {
                        data: {
                            count: result
                        },
                        directive: directive
                    }
                    res.status(200).send(reply)
                }
            )
        } catch (err) {
            res.status(500).send(Error.handleError("POST", err))
        }
    }
);

// Read one identified by its ID
router.get(
    '/:id',
    authentication.authenticateToken,
    authorisation.requestingSingle,
    VideoApi.findOwnerReferences,
    authorisation.authorise,
    VideoApi.readOne,

    function (req, res) {
        const reply = {
            data: req.entity,
            directive: apiHelper.ensureDirective(req)
        }
        res.status(200).send(VideoApi.toResponse(reply));
    }
);

// Read many from attributes. Pass the attributes into the REST endpoint as 'name=value' URL query parameters.
router.get(
    '/',
    authentication.authenticateToken,
    authorisation.requestingMany,
    VideoApi.findOwnerReferences,
    authorisation.authorise,

    function (req, res) {
        try {
            const query = typeConverter.convert(req.query, VideoApi.attribute_schema);
            const options = {
                caseInsensitive: false,
                limit: 10000 // arbitrary upper limit on number of records returned.
            }
            VideoDao.readMany(query, options,
                failed => {
                    res.status(500).send(failed);
                },
                queryError => {
                    res.status(400).send(queryError);
                },
                result => {
                    let responseEntities = result.map(entity => VideoApi.toResponse(entity));
                    const checkOwnerReferences = false;
                    responseEntities = authorisation.authoriseResponseEntities(req, responseEntities, checkOwnerReferences);
                    const data = { items: responseEntities }
                    const readManyVeto = VideoApi.onReadMany(data);
                    if (readManyVeto !== undefined) {
                        return apiHelper.sendVetoResponse(readManyVeto, res);
                    } else {
                        responseEntities = data.items;
                    }

                    const directive = apiHelper.ensureDirective(req);
                    const reply = {
                        data: responseEntities,
                        directive: directive
                    }
                    res.status(200).send(reply);
                }
            );

        } catch(err) {
            res.status(500).send(Error.handleError("GET", err));
        }
    }
);

// Read many from the query in the request body.
router.post(
    '/find',
    authentication.authenticateToken,
    authorisation.requestingMany,
    VideoApi.findOwnerReferences,
    authorisation.authorise,

    function (req, res) {
        try {
            const query = req.body;
            const options = {
                caseInsensitive: false,
                limit: 10000 // arbitrary upper limit on number of records returned.
            }
            VideoDao.readMany(query, options,
                failed => {
                    res.status(500).send(failed);
                },
                queryError => {
                    res.status(400).send(queryError);
                },
                result => {
                    let responseEntities = result.map(entity => VideoApi.toResponse(entity));
                    const checkOwnerReferences = false;
                    responseEntities = authorisation.authoriseResponseEntities(req, responseEntities, checkOwnerReferences);

                    const directive = apiHelper.ensureDirective(req);
                    const reply = {
                        data: responseEntities,
                        directive: directive
                    }
                    res.status(200).send(reply);
                }
            );

        } catch(err) {
            res.status(500).send(Error.handleError("POST", err));
        }
    }
);

// Delete one record by its ID
router.delete(
    '/:id',
    authentication.authenticateToken,
    authorisation.requestingSingle,
    VideoApi.findOwnerReferences,
    authorisation.authorise,
    VideoApi.readOne,

    function (req, res) {
        try {
            if (typeof(req.params.id) !== 'undefined') {
                const id = req.params.id;
                VideoApi.callReadOne(id, res, (oldVideo) => {
                    VideoDao.deleteOne(id,
                        failed => {
                            res.status(500).send(failed);
                        },
                        queryError => {
                            res.status(400).send(queryError);
                        },
                        notFound => {
                            res.status(404).send(notFound);
                        },
                        result => {
                            result.directive = apiHelper.ensureDirective(req);
                            res.status(200).send(result);
                        }
                    );
                });
            } else {
                res.status(400).send(Error.errorJson({errmsg: "Missing ID"}));
            }
        } catch(err) {
            res.status(500).send(Error.handleError("GET", err));
        }
    }
);

// Delete records by matching key:value pairs contained as a JSON object in the request body.
router.delete('/',
    authentication.authenticateToken,
    authorisation.requestingMany,
    VideoApi.findOwnerReferences,
    authorisation.authorise,
    function (req, res) {
        try {
            var query = req.body? req.body : {};
            delete query["_id"];
            query = typeConverter.convert(query, VideoApi.attribute_schema);

            // Add custom code here by defining an onDeleteMany operation on Video in the model,
            // and defining the function body (not the whole function) in the 'code' property.
            // This function will be called once with the API query object, not once per record.

            VideoDao.deleteMany(query,
                failed => {
                    res.status(500).send(failed);
                },
                queryError => {
                    res.status(400).send(queryError);
                },
                result => {
                    result.directive = apiHelper.ensureDirective(req);
                    res.status(200).send(result);
                }
            );

        } catch(err) {
            res.status(500).send(Error.handleError("DELETE", err));
        }
    }
);

// PUT Replace the entity with a new version
router.put(
    '/:id',
    authentication.authenticateToken,
    authorisation.requestingSingle,
    VideoApi.findOwnerReferences,
    authorisation.authorise,
    apiHelper.requestBodyContainsObject,
    VideoApi.validate,
    VideoApi.readOne,

    function (req, res) {
        try {
            const newVideo = req.body;
            const id = req.params.id;
            const preppedVideo = adapter.prepForUpdate(newVideo);

            VideoDao.replaceOne(id, preppedVideo,
                failed => {
                    res.status(500).send(failed);
                },
                queryError => {
                    res.status(400).send(queryError);
                },
                result => {
                    const reply = {
                        data: VideoApi.toResponse(newVideo),
                        modified: result.modified,
                        directive: apiHelper.ensureDirective(req)
                    }
                    res.status(200).send(reply);
                }
            );
        } catch(err) {
            res.status(500).send(Error.handleError("PUT", err));
        }
    }
);

VideoApi.callPatchOne = (id, data, res, onSuccess) => {
    VideoDao.patchOne(id, data,
        failed => {
            res.status(500).send(failed);
        },
        queryError => {
            res.status(400).send(queryError);
        },
        result => {
            onSuccess(result);
        }
    );
};

// PATCH: Update/Modify the entity with individual attributes
router.patch(
    '/:id',
    authentication.authenticateToken,
    authorisation.requestingSingle,
    VideoApi.findOwnerReferences,
    authorisation.authorise,
    apiHelper.requestBodyContainsObject,
    VideoApi.readOne,

    function (req, res) {
        try {
            const newAttributes = req.body;
            const id = req.params.id;
            const preppedAttributes = adapter.prepForUpdate(newAttributes);

            VideoApi.callPatchOne(id, preppedAttributes, res, result => {
                result.directive = apiHelper.ensureDirective(req);
                res.status(200).send(result);
            });
        } catch(err) {
            res.status(500).send(Error.handleError("PATCH", err));
        }
    }
);


module.exports = {
    name: "Video",
    router: router,
    ensureIndexes: VideoApi.ensureIndexes,
    callOnStart: VideoApi.callOnStart
}
