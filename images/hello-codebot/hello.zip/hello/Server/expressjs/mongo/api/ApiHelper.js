const Error = require("../errors.js");

const ApiHelper = {};

ApiHelper.ensureDirective = req => {
    if (typeof req.directive !== "object") {
        req.directive = {};
    }
    return req.directive;
};

ApiHelper.vetoable = (res, next, onEvent) => {
    try {
        const result = onEvent();
        if (result !== undefined) {
            return ApiHelper.sendVetoResponse(result, res);
        }
        next();
    } catch (err) {
        res.status(500).send(Error.handleError("POST", err));
    }
};

ApiHelper.vetoableWithPasswordHidden = (req, res, next, entity, onEvent, includeLoggedInUser) => {
    try {
        includeLoggedInUser = includeLoggedInUser == null ? true : includeLoggedInUser;
        const pw = entity.password;
        delete entity.password;

        const directive = ApiHelper.ensureDirective(req);
        const result = includeLoggedInUser ? onEvent(entity, req.user, directive) : onEvent(entity, directive);
        if (result === undefined) {
            entity.password = pw;
            next();
        } else {
            return ApiHelper.sendVetoResponse(result, res);
        }
    } catch (err) {
        res.status(500).send(Error.handleError("POST", err));
    }
};

ApiHelper.filterVetoables = (entities, fn, directive, loggedInUser) => {
    return entities.filter(entity => fn(entity, directive, loggedInUser) === undefined);
}

ApiHelper.sendVetoResponse = (veto, res) => {
    const status = veto.status === undefined ? 400 : veto.status;
    const msg = typeof veto === "string" ? veto : veto.msg;
    res.status(status).send(Error.errorJson(msg));
};

ApiHelper.sendCombinedVetoResponse = (vetoes, fromArray, res) => {
    const vetoWithStatus = vetoes.find((veto) => veto.status !== undefined);
    const status = vetoWithStatus === undefined ? 400 : vetoWithStatus.status;
    const messages = vetoes.map(v => typeof v === "string"? v : typeof v.msg === "string"? v.msg : typeof v.message === "string"? v.message : "").filter(v => v !== "")
    const uniqueMsgs = [... new Set(messages)];

    if (fromArray) {
        res.status(status).send({ "message": uniqueMsgs })
    } else {
        res.status(status).send({ "message": uniqueMsgs[0] })
    }
};

ApiHelper.requestBodyContainsObject = (req, res, next) => {
    if (Object.keys(req.body).length === 0) {
        return res.status(400).send(Error.errorJson("Invalid request body"));
    }
    next();
};

module.exports = ApiHelper;
