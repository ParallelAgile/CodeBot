const express = require('express');
const router = express();
const _ = require('lodash');
const config = require('config');
const adapter = require('../adapters/UserAdapter.js');
const typeConverter = require("../type_converter.js");
const authentication = require('../Authentication.js')
const authorisation = require('../Authorisation.js').instance;
const apiHelper = require("./ApiHelper.js");
const UserDao = require("../database/UserDao.js");
const Validator = require('jsonschema').Validator;
const $RefParser = require("@apidevtools/json-schema-ref-parser");
const Error = require('../errors.js')


const UserApi = {
    attribute_schema: {},
    jsonValidator: new Validator(),

    ensureIndexes: () => {
        UserDao.ensureIndexes();
    },

    callOnStart: () => {
        // To include a custom startup function, add an Operation called "on start" to the User domain class.
    }
};


authentication.identityApi = UserApi;

$RefParser.dereference('json_schema/User.schema.json', (err, schema) => {
    if (err) {
        console.error(err);
        throw "Unable to dereference the UserApi schema"
    }
    UserApi.attribute_schema = schema.definitions.User;
});


UserApi.validateField = (field, minLength, maxLength) => {
    if (minLength===undefined) minLength = 0;
    if (maxLength===undefined) maxLength = 100;

    return field !== undefined &&
            field.length > minLength &&
            field.length < maxLength;
}

UserApi.toResponse = entity => {
    const r = _.cloneDeep(entity);
    delete r.password;
    return r;
}

// middleware function
UserApi.validate = (req, res, next) => {
    const useJsonSchema = config.get("validation.useJsonSchema")
    const data = Array.isArray(req.body) ? req.body : [req.body];

    if (useJsonSchema === true || useJsonSchema === "true") {
        const validatorSettings = {
            throwError: false,
            allowUnknownAttributes: false
        }

        const allErrors = data.reduce((acc, entity)=> {
            delete entity.id;
            const result = UserApi.jsonValidator.validate(entity, UserApi.attribute_schema, validatorSettings);
            if (result.valid) {
                return acc;
            } else {
                const errs = result.errors.map(err =>
                    err.stack.replace(/\"/g, "'").replace(/^instance /, "").replace(/^instance\./, ""));
                return acc.concat(errs);
            }
        }, []);

        if (allErrors.length === 0) {
            next();
        } else {
            res.status(400).send({
                "message": "Validation failed",
                "validationErrors": allErrors,
                "directive": {}
            });
        }
    } else {
        next();
    }
}

// middleware
UserApi.findOwnerReferences = (req, res, next) => {
    const a = authorisation.ensureAuthorisationObject(req);

    if (a.requestingSingle) { // requesting a single User by ID
        if (req.user.id !== req.params.id)
            return Error.sendError(res, 403, "User unavailable");

        a.referencesFromOwner = [req.user.id];
        a.isOwnEntity = true;
    } else {
        a.referencesFromOwner = [req.user.id];
    }

    next();
}

router.post('/login',
      function (req, res) {
        try {
            if (typeof(req.body) !== 'undefined' && Object.keys(req.body).length != 0) {
                const username = req.body["username"];
                const password = req.body["password"];

                if (UserApi.validateField(username) && UserApi.validateField(password)) {
                    const query = {
                        username: username,
                        password: authentication.hashPassword(password)
                    };
                    const options = {
                        caseInsensitive: true
                    }
                    UserApi.callFindOne(query, options, res,
                        notFound => {
                            console.log("Login failed for user " + username);
                            res.status(401).send(Error.errorJson("Your login details were incorrect."));
                        },
                        result => {
                            const user = UserApi.toResponse(result);
                            const directive = apiHelper.ensureDirective(req);
                            const jwt = authentication.generateAccessToken(username);
                            const reply = {
                                data: user,
                                jwt: jwt,
                                directive: directive
                            }
                            res.status(200).send(reply);
                        }
                    );
                } else {
                    res.status(400).send(Error.errorJson("Invalid login details"));
                }
            } else {
                res.status(400).send(Error.errorJson("POST body is missing"));
            }

        } catch(err) {
            res.status(500).send(Error.handleError("POST", err));
        }
    }
);

UserApi.canRegister = (req, res, next) => {
    try {
        const usersCanRegister = config.get("authentication.usersCanSelfRegister").toLowerCase();
        if (usersCanRegister === "never") {
            console.log("Returning a 403 for /register, as user registration is not allowed.");
            res.status(403).send(Error.errorJson("User registration not allowed"));
        }

        UserApi.callFindOne({}, {}, res,
            notFound => { // none exist yet
                authorisation.ensureAuthorisationObject(req, {firstUser: true});
                next();
            },
            foundOne => { // at least 1 User exists
                if (usersCanRegister === "first") {
                    console.log("Returning a 403 for /register, as user registration is configured as once only.");
                    res.status(403).send(Error.errorJson("User registration is not allowed"));
                } else {
                    next();
                }
            }
        );
    } catch(err) {
        res.status(500).send(Error.handleError("POST", err));
    }
};

UserApi.onRegister = (user) => {
 
 /*
   This server-side event handler runs each time a new user registers an account.
   It uses a generated Data Access Object (DAO) to access the MongoDB 'Video' collection.
   
   The function first checks whether the Video collection contains any data.
   If the collection is empty, it then creates some example video records,
   which will appear in the "choose a video" selector in the React UI.
 
   For a more detailed discussion of "bootstrap data" options, see:
   https://parallelagile.github.io/CodeBot/articles/creating-bootstrap-data
 */
 
    const VideoDao = require("../database/VideoDao.js")

    const data = [
        {
            name: "Generating complete web apps including UI and database",
            url: "https://youtu.be/ZUm6esxrua8"
        },
        {
            name: "Domain Driven Database Design",
            url: "https://youtu.be/zsfj64Wmdek"
        }
    ]

    const createData = () => {
        VideoDao.create(
            data,

            failed => {
                console.error("Unable to create Video bootstrap data", failed)
            },
            createError => {
                console.error("Query error creating Video bootstrap data", createError)
            },
            result => {
                console.log("Video bootstrap data created.", result)
            }
        )
    }


    VideoDao.countAll(
        failed => {
            console.error("Unable to count Video records", failed)
        },
        queryError => {
            console.error("Query error counting Video records", queryError)
        },
        count => {
            if (count === 0) {
                createData()
            }
        })
}


UserApi.callOnRegister = (req, res, next) => {
    return apiHelper.vetoableWithPasswordHidden(req, res, next, req.body, UserApi.onRegister, false);
}

UserApi.validateForAuthentication = (req, res, next) => {
    const data = req.body;

    function checkStr(name, value, minLength) {
        return value===undefined || (typeof value !== "string") || value.length < minLength?
        [`${name} must have at least ${minLength} characters`] : [];
    }

    const errs =
        checkStr("username", data.username, 4)
        .concat(checkStr("password", data.password, 8));

    if (errs.length === 0) next();
    else res.status(400).send(Error.errorJson(errs.join(", ")));
};

router.post('/register',
    UserApi.canRegister,
    UserApi.validateForAuthentication,
    UserApi.validate,
    UserApi.callOnRegister,

    function (req, res) {
        try {
            const data = req.body;
            data.roles = authorisation.defaultRoleNames;
            if (authorisation.ensureAuthorisationObject(req).firstUser) {
                data.roles = data.roles.concat(authorisation.firstRoleNames);
            }
            data.roles = [...new Set(data.roles)];
            UserApi.callCreate(UserApi.prepareForCreate(data), res,
                result => {
                    const reply = {
                        data: result.data,
                        directive: apiHelper.ensureDirective(req)
                    }
                    res.status(201).send(reply);
                }
            );
        } catch(err) {
            res.status(500).send(Error.handleError("POST", err));
        }
    }
);

UserApi.findTargetUser = (req, res, next) => {
    const targetUsername = req.params.username;
    const query = {
        username: targetUsername
    };
    const options = {
        caseInsensitive: true,
    };
    UserApi.callFindOne(query, options, res,
        notFound => {
            res.status(404).send(Error.errorJson("The requested username doesn't exist."));
        },
        result => {
            delete result.password;
            req.targetUser = result;
            next();
        }
    );
}

router.post(
    "/role/:username/:roleName",
    authentication.authenticateToken,
    (req,res,next) => {
        const role = req.user.username.toLowerCase() === req.params.username.toLowerCase()? "add role to self" : "add role";
        authorisation.ensureAuthorisationObject(req, {action: role});
        next();
    },
    authorisation.authorise,
    authorisation.validateRoleName,
    UserApi.findTargetUser,

    function (req, res) {
        try {
            const roleName = req.params.roleName;
            const roles = req.targetUser.roles || [];
            if (roles.includes(roleName)) {
                return res.status(400).send({msg: "Role already assigned"});
            }
            roles.push(roleName);
            const toPatch = {
                roles: roles
            }

            UserApi.callPatchOne(req.targetUser.id, toPatch, res,
                result => {
                    res.status(200).send(result);
                }
            );
        } catch (err) {
            res.status(500).send(Error.handleError("POST", err));
        }
    }
);

router.delete(
    "/role/:username/:roleName",
    authentication.authenticateToken,
    (req, res, next) => {
        const role = req.user.username.toLowerCase() === req.params.username.toLowerCase()? "remove role from self" : "remove role";
        authorisation.ensureAuthorisationObject(req, {action: role});
        next();
    },
    authorisation.authorise,
    authorisation.validateRoleName,
    UserApi.findTargetUser,

    function (req, res) {
        try {
            const roleName = req.params.roleName;
            const roles = req.targetUser.roles || [];
            if (!roles.includes(roleName)) {
                return res.status(400).send({msg: "Role not assigned"});
            }

            const toPatch = {
                roles: roles.filter(r => r != roleName)
            }

            UserApi.callPatchOne(req.targetUser.id, toPatch, res,
                result => {
                    res.status(200).send(result);
                }
            );
        } catch (err) {
            res.status(500).send(Error.handleError("DELETE", err));
        }
    }
);

UserApi.prepareForCreate = rec => {
    const data = adapter.prepForCreate(
        typeConverter.convert(rec, UserApi.attribute_schema)
    );
    if (data.password) data.password = authentication.hashPassword(data.password);
    delete data["id"];
    delete data["_id"];
    return data;
}

UserApi.callCreate = (data, res, onSuccess) => {
    UserDao.create(data,
        failed => {
            res.status(500).send(failed);
        },
        createError => {
            res.status(400).send(createError);
        },
        result => {
            onSuccess(result);
        }
    );
};



// Create a new User. Pass in a JSON array to create many.
router.post('/',
    authentication.authenticateToken,
    authorisation.authorise,
    UserApi.validate,

    function (req, res) {
        try {
            if (typeof req.body !== "undefined") {
                const fromArray = Array.isArray(req.body)
                const records = fromArray? req.body : [req.body];
                if (records.length === 0) return res.status(400).send(Error.errorJson("The supplied array was empty."));

                // To run a custom onCreate function here, add it as an Operation to the User class in the UML model:
                const onCreateResults = records.map(rec => {
                    return {right: UserApi.prepareForCreate(rec)};
                });

                const vetoes = onCreateResults.filter(result => result.left).map(result => result.left);
                if (vetoes.length > 0) {
                    return apiHelper.sendCombinedVetoResponse(vetoes, fromArray, res);
                }

                UserApi.callCreate(records, res,
                    result => {
                        const newItems = result.data;
                        const reply = {
                            data: fromArray? newItems : newItems[0] || {},
                            directive: apiHelper.ensureDirective(req)
                        }

                        res.status(201).send(reply);
                    }
                );

            } else {
                res.status(400).send(Error.errorJson("POST body is missing"));
            }
        } catch(err) {
            res.status(500).send(Error.handleError("POST", err));
        }
    }
);

UserApi.readOne = (req, res, next) => {
    try {
        const id = req.params["id"];
        if (id === undefined || id.length === 0) {
            return res.status(400).send(Error.errorJson("Invalid id query-parameter"));
        }
        UserApi.callReadOne(id, res, user => {
            req.entity = user;
            next();
        });
    } catch (err) {
        res.status(500).send(Error.handleError("GET", err));
    }
}

UserApi.callReadOne = (id, res, onSuccess) => {
    UserDao.readOne(id,
        failed => {
            res.status(500).send(failed);
        },
        queryError => {
            res.status(400).send(queryError);
        },
        notFound => {
            res.status(404).send(notFound);
        },
        result => {
            onSuccess(result);
        }
    )
};

UserApi.callFindOne = (query, options, res, onNotFound, onSuccess) => {
    UserDao.findOne(query, options,
        failed => {
            res.status(500).send(failed);
        },
        queryError => {
            res.status(400).send(queryError);
        },
        notFound => {
            onNotFound(notFound);
        },
        result => {
            onSuccess(result);
        }
    )
};

/**
 * Asserts that the user is currently logged-in, and returns the logged-in user details.
 * Calls the 'onRead' event handler followed by 'onLogin', so a veto or directive can be returned if required,
 * e.g. provide a custom route for the UI to navigate to.
 */
router.get(
    "/loggedIn",
    authentication.authenticateToken,
    authorisation.requestingSingle,
    authorisation.authorise,

    function (req, res) {
        try {
            const user = req.user;
            const directive = apiHelper.ensureDirective(req);
            const reply = {
                data: req.entity,
                directive: directive
            };
            res.status(200).send(UserApi.toResponse(reply));
        } catch (err) {
            res.status(500).send(Error.handleError("POST", err));
        }
    }
);

// Count the total number of User records.
// Appears before router.get("/:id") to take precedence.
router.get(
    '/count',
    authentication.authenticateToken,
    authorisation.authorise,

    function (req, res) {
        try {
            UserDao.countAll(
                failed => {
                    res.status(500).send(failed)
                },
                queryError => {
                    res.status(400).send(queryError)
                },
                result => {
                    const directive = apiHelper.ensureDirective(req)
                    const reply = {
                        data: {
                            count: result
                        },
                        directive: directive
                    }
                    res.status(200).send(reply)
                }
            )
        } catch (err) {
            res.status(500).send(Error.handleError("GET", err))
        }
    }
);

// Count the number of User records matching the JSON query in the request body.
router.post(
    '/count',
    authentication.authenticateToken,
    authorisation.authorise,

    function (req, res) {
        try {
            const query = req.body
            UserDao.count(
                query,

                failed => {
                    res.status(500).send(failed)
                },
                queryError => {
                    res.status(400).send(queryError)
                },
                result => {
                    const directive = apiHelper.ensureDirective(req)
                    const reply = {
                        data: {
                            count: result
                        },
                        directive: directive
                    }
                    res.status(200).send(reply)
                }
            )
        } catch (err) {
            res.status(500).send(Error.handleError("POST", err))
        }
    }
);

// Read one identified by its ID
router.get(
    '/:id',
    authentication.authenticateToken,
    authorisation.requestingSingle,
    UserApi.findOwnerReferences,
    authorisation.authorise,
    UserApi.readOne,

    function (req, res) {
        const reply = {
            data: req.entity,
            directive: apiHelper.ensureDirective(req)
        }
        res.status(200).send(UserApi.toResponse(reply));
    }
);

// Read many from attributes. Pass the attributes into the REST endpoint as 'name=value' URL query parameters.
router.get(
    '/',
    authentication.authenticateToken,
    authorisation.requestingMany,
    UserApi.findOwnerReferences,
    authorisation.authorise,

    function (req, res) {
        try {
            const query = typeConverter.convert(req.query, UserApi.attribute_schema);
            const options = {
                caseInsensitive: false,
                limit: 10000 // arbitrary upper limit on number of records returned.
            }
            UserDao.readMany(query, options,
                failed => {
                    res.status(500).send(failed);
                },
                queryError => {
                    res.status(400).send(queryError);
                },
                result => {
                    let responseEntities = result.map(entity => UserApi.toResponse(entity));
                    const checkOwnerReferences = true;
                    responseEntities = authorisation.authoriseResponseEntities(req, responseEntities, checkOwnerReferences);
                    const directive = apiHelper.ensureDirective(req);
                    const reply = {
                        data: responseEntities,
                        directive: directive
                    }
                    res.status(200).send(reply);
                }
            );

        } catch(err) {
            res.status(500).send(Error.handleError("GET", err));
        }
    }
);

// Read many from the query in the request body.
router.post(
    '/find',
    authentication.authenticateToken,
    authorisation.requestingMany,
    UserApi.findOwnerReferences,
    authorisation.authorise,

    function (req, res) {
        try {
            const query = req.body;
            const options = {
                caseInsensitive: false,
                limit: 10000 // arbitrary upper limit on number of records returned.
            }
            UserDao.readMany(query, options,
                failed => {
                    res.status(500).send(failed);
                },
                queryError => {
                    res.status(400).send(queryError);
                },
                result => {
                    let responseEntities = result.map(entity => UserApi.toResponse(entity));
                    const checkOwnerReferences = true;
                    responseEntities = authorisation.authoriseResponseEntities(req, responseEntities, checkOwnerReferences);

                    const directive = apiHelper.ensureDirective(req);
                    const reply = {
                        data: responseEntities,
                        directive: directive
                    }
                    res.status(200).send(reply);
                }
            );

        } catch(err) {
            res.status(500).send(Error.handleError("POST", err));
        }
    }
);

// Delete one record by its ID
router.delete(
    '/:id',
    authentication.authenticateToken,
    authorisation.requestingSingle,
    UserApi.findOwnerReferences,
    authorisation.authorise,
    UserApi.readOne,

    function (req, res) {
        try {
            if (typeof(req.params.id) !== 'undefined') {
                const id = req.params.id;
                UserApi.callReadOne(id, res, (oldUser) => {
                    UserDao.deleteOne(id,
                        failed => {
                            res.status(500).send(failed);
                        },
                        queryError => {
                            res.status(400).send(queryError);
                        },
                        notFound => {
                            res.status(404).send(notFound);
                        },
                        result => {
                            result.directive = apiHelper.ensureDirective(req);
                            res.status(200).send(result);
                        }
                    );
                });
            } else {
                res.status(400).send(Error.errorJson({errmsg: "Missing ID"}));
            }
        } catch(err) {
            res.status(500).send(Error.handleError("GET", err));
        }
    }
);

// Delete records by matching key:value pairs contained as a JSON object in the request body.
router.delete('/',
    authentication.authenticateToken,
    authorisation.requestingMany,
    UserApi.findOwnerReferences,
    authorisation.authorise,
    function (req, res) {
        try {
            var query = req.body? req.body : {};
            delete query["_id"];
            query = typeConverter.convert(query, UserApi.attribute_schema);

            // Add custom code here by defining an onDeleteMany operation on User in the model,
            // and defining the function body (not the whole function) in the 'code' property.
            // This function will be called once with the API query object, not once per record.

            UserDao.deleteMany(query,
                failed => {
                    res.status(500).send(failed);
                },
                queryError => {
                    res.status(400).send(queryError);
                },
                result => {
                    result.directive = apiHelper.ensureDirective(req);
                    res.status(200).send(result);
                }
            );

        } catch(err) {
            res.status(500).send(Error.handleError("DELETE", err));
        }
    }
);

// PUT Replace the entity with a new version
router.put(
    '/:id',
    authentication.authenticateToken,
    authorisation.requestingSingle,
    UserApi.findOwnerReferences,
    authorisation.authorise,
    apiHelper.requestBodyContainsObject,
    UserApi.validate,
    UserApi.readOne,

    function (req, res) {
        try {
            const newUser = req.body;
            const id = req.params.id;
            const preppedUser = adapter.prepForUpdate(newUser);
            if (preppedUser.password) preppedUser.password = authentication.hashPassword(preppedUser.password);

            UserDao.replaceOne(id, preppedUser,
                failed => {
                    res.status(500).send(failed);
                },
                queryError => {
                    res.status(400).send(queryError);
                },
                result => {
                    const reply = {
                        data: UserApi.toResponse(newUser),
                        modified: result.modified,
                        directive: apiHelper.ensureDirective(req)
                    }
                    res.status(200).send(reply);
                }
            );
        } catch(err) {
            res.status(500).send(Error.handleError("PUT", err));
        }
    }
);

UserApi.callPatchOne = (id, data, res, onSuccess) => {
    UserDao.patchOne(id, data,
        failed => {
            res.status(500).send(failed);
        },
        queryError => {
            res.status(400).send(queryError);
        },
        result => {
            onSuccess(result);
        }
    );
};

// PATCH: Update/Modify the entity with individual attributes
router.patch(
    '/:id',
    authentication.authenticateToken,
    authorisation.requestingSingle,
    UserApi.findOwnerReferences,
    authorisation.authorise,
    apiHelper.requestBodyContainsObject,
    UserApi.readOne,

    function (req, res) {
        try {
            const newAttributes = req.body;
            const id = req.params.id;
            const preppedAttributes = adapter.prepForUpdate(newAttributes);
            if (preppedAttributes.password) preppedAttributes.password = authentication.hashPassword(preppedAttributes.password);

            UserApi.callPatchOne(id, preppedAttributes, res, result => {
                result.directive = apiHelper.ensureDirective(req);
                res.status(200).send(result);
            });
        } catch(err) {
            res.status(500).send(Error.handleError("PATCH", err));
        }
    }
);


module.exports = {
    name: "User",
    router: router,
    ensureIndexes: UserApi.ensureIndexes,
    callOnStart: UserApi.callOnStart
}
