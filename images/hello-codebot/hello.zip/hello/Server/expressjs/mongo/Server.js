const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const pathToSwaggerUi = require('swagger-ui-dist').absolutePath();
const Error = require('./errors.js');
const config = require('config');

const app = express();
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));
app.use(bodyParser.json({limit: '50mb'}));
app.use(cors());
app.options('*', cors());

// Uncomment this to output full stack traces for warnings:
//process.on('warning', e => console.warn(e.stack));

/*
 * The Hello CodeBot REST API can optionally run as an AWS Lambda function
 * combined with API Gateway in proxy mode, via the serverless-http library.
*/
const isInLambda = !!process.env.LAMBDA_TASK_ROOT;
console.log("isInLambda=" + isInLambda);

const collection_names = ["User", "Video"];
const apis = collection_names.map(name => require(`./api/${name}Api.js`));

const username = config.get("server.codebotUsername");
const dbname = config.get("server.codebotProject");


// If you do not include the path in the node itself (pure REST from front-end to back-end), you need this:
app.use(function (req, res, next) {

    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});


try {
    apis.forEach(api => {
        app.use(`/${username}/${dbname}/${api.name}`, api.router);
    });
} catch (error) {
    console.log(error);
}

// Add a /liveness endpoint, for monitoring.
// This doesn't necessarily reflect the "health" of the system e.g. database connectivity, just that the API is responding.
const livenessEndpoint = express().get('/liveness',function (req, res) {
    res.status(200).send({msg: "Ok"});
});
app.use(`/${username}/${dbname}`, livenessEndpoint);


// Swagger/OpenAPI reference
const api_file = 'api.json'
app.use('/apiref', express.static(pathToSwaggerUi));
app.use('/' + api_file, function(req, res) {
    res.json(require('./' + api_file));
})

// This allows the Swagger/OpenAPI web page to access the schema:
app.use('/json_schema', express.static('json_schema'));


// Redirect to Swagger/OpenAPI docs
app.use('/api', function(req, res) {
    res.redirect('/apiref?url=/' + api_file);
})

// Must be the last "app.use" added:
app.use(function (req, res, next) {
    res.status(404).send(Error.errorJson("Requested resource not found."));
});

function ensureIndexes() {
    apis.forEach(api => {
        api.ensureIndexes();
    });
}

function callOnStart() {
    apis.forEach(api => {
        api.callOnStart();
    });
}

if (isInLambda) {

    // If you're running the API as a Lambda function, call GET /ensure_indexes to create the DB indexes
    // (In a normal deployment the API runs this automatically on startup):
    app.use('/ensure_indexes', function(req, res) {
        ensureIndexes();
        res.status(200).send();
    });
    app.use('/call_on_start', function(req, res) {
        callOnStart();
        res.status(200).send();
    });

    const serverless = require('serverless-http');
    exports.handler = serverless(app);
} else {
    // Normal deployment:

    ensureIndexes();
    callOnStart();

    const server = app.listen(config.get("server.port"), function () {
        const url = `http://${config.get("server.hostname")}:${server.address().port}`
        console.log(`The API is available at ${url}/${username}/${dbname}/<DomainClass>`)
        console.log(`View the OpenAPI documentation at ${url}/api`)
    });
}
