# Hello CodeBot Node Express.js service

This readme file provides setup instructions for the MongoDB-backed REST API.

More info can be found in our online [process guide](https://parallelagile.github.io/CodeBot/).


# Quick setup using Docker

Install Docker if you don't already have it, and make sure the docker daemon is running.

In the Server/expressjs/mongo directory (i.e. here), run:

```
docker-compose up
```

This starts up a MongoDB container and an express.js container for the REST API. You should now be able to access the API docs at `0.0.0.0:7000/api`.

The API docs include "Try it now", which allows you to try out the API directly. Alternatively, try the Java client under `Clients/...`

Note the `0.0.0.0` address instead of localhost; you may find this is needed so that you can access the REST API from outside the docker container.
The address is configured as an environment variable `API_SERVER_HOSTNAME` in `docker-compose.yml`. This in turn is referenced in `config/custom-environment-variables.yml`,
which provides a way to override the settings in `config/default.yml`.

Using environment variables to override the default settings enables you to change the server config without the changes being overwritten next time you generate the application.


# Setup

Install Node.js (and therefore NPM) via:  www.npmjs.com/get-npm

In the Server/expressjs directory (i.e. here), run:

```
npm install
```

This reads `package.json` to download and install locally the required packages in the `node_modules` subdirectory.


## MongoDB setup

If you're running this without the hosted API, you should be able to simply run a local MongoDB server on the default port,
and the API will connect to and use it.

If you've defined any class attribute constraints (e.g. "unique"), you'll find these generated as index definitions in
`ensure_indexes.js`. This can be run directly in the MongoDB console (or in Robo 3T etc) to create the indexes; just
make sure you're in the hello database first:

```
use hello;
```

There's also `indexes.json`, which may be useful if you need to iterate through the required indexes in a script of your own.
(For example, CodeBot uses this when creating or redeploying the hosted API).


# Running the Server

At the command-line run:

```
npm start
```


# Viewing the OpenAPI/Swagger API Docs

The local Swagger URL is output in the console when the API starts up. There you can click the URL (or ctrl-click or cmd-click) to launch the Swagger docs in a web browser.
Usually the URL is the following (adjust the host and port to match your config):

```
http://localhost:7000/api
```

A static HTML version of the API docs is also generated in the `api-docs` folder; this doesn't have the `Try it out` button though, as it's offline documentation.


# Calling the API

To test the API, use the `Try it out` buttons for each endpoint in the above Swagger page.

You can also copy the `curl` commands from that page, to use them on the command-line.

Once you're happy that the API works, try out one of the client libraries to call the API from your own program.
(Check their respective readme files for more info).

# CORS on localhost

The API has been set up to enable CORS (see Server.js). If you're running the API on localhost and see a network error or something that looks like a CORS problem, it's worth checking if the ad-blocker in your browser is blocking the request.


# Data validation

By default, the API runs with data validation switched on - the aim being to prevent "bad" data from accumulating in a database... often the cause of follow-on bugs and confusion.
However, data validation can be switched off - e.g. for early prototyping while the domain model may still be rapidly evolving, or to allow quick exploratory changes to be made to the generated API.

However, we recommend switching the data validation on as soon as possible after that initial stage. Once data validation is switched on,
all data operations are validated against the data schema.

To switch data validation on or off, load up `config/default.yml`, and change the useJsonSchema setting to true or false.
This can be done via an environment variable, so validation remains the same even if the config file is re-generated and overwritten.
(Check the notes in default.yml for more info).
