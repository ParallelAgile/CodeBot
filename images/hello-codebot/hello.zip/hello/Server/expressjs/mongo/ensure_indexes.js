// Run the following script directly in the MongoDB console:

db.User.createIndex( { username: 1 }, { unique: true } )
