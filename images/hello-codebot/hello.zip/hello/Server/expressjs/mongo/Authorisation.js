const yaml = require("js-yaml");
const fs = require("fs");

class Authorisation {
    static instance = new Authorisation();

    static loadRoles() {
        const obj = yaml.load(fs.readFileSync("./config/roles.yml", "utf8")).roles || {};
        const arr = Object.keys(obj).map(roleName => [
            roleName,
            obj[roleName],
        ]);
        return new Map(arr);
    }

    actionsByRequestMethod = new Map([
        ["POST", "create"],
        ["PUT", "replace"],
        ["PATCH", "update"],
        ["DELETE", "delete"],
        ["GET", "read"],
    ]);

    fileActionsByRequestMethod = new Map([
        ["POST", "uploadfile"],
        ["PUT", "replacefile"],
        ["DELETE", "deletefile"],
        ["GET", "downloadfile"],
    ]);

    findAction = /([^\/]+$)/g;
    roles;
    /**
     * A list of the role names that are assigned by default to a new user when they register via the API.
     * To create a new user without assigning the default roles, use the "create" endpoint instead.
     */
    defaultRoleNames;

    /**
     * If the API setting "authentication.usersCanSelfRegister" is "FIRST", then the role names listed here
     * will be assigned to the *first* new user who registers via the API.
     * This can be useful as a way to "bootstrap" a new system; if an Admin role is included here, then the
     * first user created has the ability to create or assign roles to subsequent users.
     */
    firstRoleNames;

    constructor() {
        this.roles = Authorisation.loadRoles();

        this.defaultRoleNames = [...this.roles]
            .filter(([roleName, role]) => role.assignOnRegister)
            .map(([roleName, role]) => roleName);

        this.firstRoleNames = [...this.roles]
            .filter(([roleName, role]) => role.assignOnFirstRegister)
            .map(([roleName, role]) => roleName);
    }

    ensureAuthorisationObject(req, toAdd) {
        if (req.authorisation === undefined) req.authorisation = {};
        if (toAdd !== undefined) {
            Object.assign(req.authorisation, toAdd);
        }
        return req.authorisation;
    }

    // middleware
    requestingSingle(req, res, next) {
        Authorisation.instance.ensureAuthorisationObject(req, {
            requestingSingle: true,
        });
        next();
    }

    // middleware
    requestingMany(req, res, next) {
        Authorisation.instance.ensureAuthorisationObject(req, {
            requestingSingle: false,
        });
        next();
    }

    // middleware
    fileUploadsRequest(req, res, next) {
        const self = Authorisation.instance;
        const action = self.fileActionsByRequestMethod.get(req.method);
        if (action === undefined) {
            return res.status(403).send({ msg: "File uploads action not recognised" });
        }
        self.ensureAuthorisationObject(req, {
            fileUploadsRequest: true,
            action: action
        });
        next();
    }

    /**
     * Middleware function for any API endpoints that specify
     * the role name in the request params (e.g. add/remove role).
     */
    validateRoleName(req, res, next) {
        if (Authorisation.instance.roles.has(req.params.roleName))
            next();
        else
            res.status(404).send({msg: "Role name not found"})
    }

    // middleware
    authorise(req, res, next) {
        const self = Authorisation.instance;
        const domainArr = req.baseUrl.match(self.findAction);  // Example req.baseUrl:'/matt/vsrads/User'
        if (domainArr === null || domainArr.length === 0) {
            console.log("Unable to determine requested domain class from the URL: " + req.baseUrl);
            return res.status(403).send({ msg: "Domain class not recognised" });
        }
        const domainClassName = domainArr[0];

        // The action is either self-declared via a prior request middleware fn, or inferred from the request method:
        const action =
            self.ensureAuthorisationObject(req).action ||
            self.actionsByRequestMethod.get(req.method);

        if (action === undefined) {
            console.log(
                `Unable to determine requested action from method ${req.method}. URL: ${req.baseUrl}`
            );
            return res.status(403).send({ msg: "Action not recognised" });
        }

        const permissions = self.permissionsFor(req.user);
        const grantArrays = permissions.includes("ALL") || permissions.includes("ANY")
            ? [["ALL"]]
            : (
                  permissions.filter((p) => p.domain == domainClassName) || {
                      grants: [],
                  }
              ).map(p => p.grants);
        const grants = [...new Set([].concat(... grantArrays))];

        self.ensureAuthorisationObject(req, {
            action: action,
            domainClassName: domainClassName,
            permissions: permissions,
            grants: grants,
        });

        if (self.isAllowed(req.authorisation)) next();
        else res.status(403).send({ msg: "Action not allowed" });
    }

    authoriseResponseEntities(req, entities, checkOwnerReferences) {
        const a = req.authorisation;
        if (a.grants.includes("ALL")) return entities;

        const allowReadAny = a.grants.includes("read any");

        if (allowReadAny || !checkOwnerReferences) return entities;
        if (
            a.referencesFromOwner === undefined ||
            a.referencesFromOwner.length === 0
        )
            return [];

        return entities.filter((entity) => {
            return a.referencesFromOwner.includes(entity.id);
        });
    }

    /**
     * @param {*} a.action One of: create, read, update, delete, uploadfile, downloadfile, deletefile, or (for users) login, register
     * @param {*} a.domainClassName e.g. "User"
     * @param {*} a.permissions Array of permission objects for each domain class
     * @param {*} a.grants Array of grant names bound to this user for the requested domain class
     * @param {*} a.requestingSingle Does this request involve a single entity identified by its ID, or potentially many?
     * @param {*} a.isOwnEntity Does the user directly "own" the entity being requested? If 'undefined', it isn't relevant for this action.
     */
    isAllowed(a) {

        // If no roles have been defined in roles.yml, allow access to everything.
        // This is really intended for early prototyping and development.
        // As soon as at least one role is defined, the whole system is then suitably locked-down, and
        // must be selectively opened by assigning roles to users.
        if (this.roles.size === 0) {
            return true;
        }

        if (a.grants.includes("ALL") || a.grants.includes("ANY")) return true;

        if (!a.fileUploadsRequest && !a.requestingSingle) {
            // if the request involves many, the own/any question will be resolved via the database query or the result dataset.
            return a.grants.find(
                grant =>
                    grant === a.action ||
                    grant === a.action + " own" ||
                    grant === a.action + " any"
            ) !== undefined;
        }

        let action = a.action;
        if (a.isOwnEntity !== undefined) {
            action += a.isOwnEntity ? " own" : " any";
        }

        return a.grants.includes(action);
    }

    permissionsFor(user) {
        const userRoles = user.roles || [];
        return Authorisation.instance.permissionsFrom(userRoles);
    }

    permissionsFrom(userRoles) {
        const allRoles = Authorisation.instance.roles;

        const permissions = userRoles.map((roleName) => {
            const role = allRoles.get(roleName);
            if (role === undefined) return [];
            return role.permissions;
        });

        return [].concat(...permissions);
    }
}

module.exports = Authorisation;
