const dbOps = require("../db_ops.js")
const Error = require('../errors.js')
const ObjectId = require('mongodb').ObjectID;

const UserDao = {
    attribute_schema: require('../json_schema/User.schema.json'),
    attributes: [ // Domain model attributes, plus any relationship fields
        "email",
        "password",
        "roles",
        "username"
    ],

    ensureIndexes: () => {
        dbOps.ensureIndexes("User");
    }
};


UserDao.check_collection = function() {
    dbOps.check_collection("User", UserDao.attribute_schema,
        (err, result) => {
            if (err) {
                console.error("Error checking User schema:");
                console.error(err);
            } else {
                console.log("User schema checked");
            }
        }
    );
}

UserDao.dbError = (action, err) =>{
    console.log("Database error: ", err);

    switch (err.code) {
        case 11000: return "Duplicate User";
    };

    return `Cannot ${action}: database error`;
}

// Create one or create many
UserDao.create = (data, onFailure, onCreateError, onSuccess) => {
    try {
        dbOps.create("User", UserDao.attributes, data, (err, result) => {
            if (err) {
                const msg = UserDao.dbError("create", err);
                onCreateError(Error.errorJson(msg));
            } else {
                const data = result.ops.map(rec => {
                    rec.id = rec._id;
                    delete rec._id;
                    delete rec.password;
                    return rec;
                });
                const insertedIds =
                    result.insertedIds === undefined?
                        [result.insertedId.toString()] :
                        Object.keys(result.insertedIds).map(key => result.insertedIds[key].toString());
                const response = {
                    data: data,
                    insertedCount: result.insertedCount,
                    insertedIds: insertedIds
                };
                onSuccess(response);
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

// Count the total number of User records
UserDao.countAll = (onFailure, onQueryError, onSuccess) => {
    UserDao.count({}, onFailure, onQueryError, onSuccess)
}

// Count the number of User records matching the query
UserDao.count = (query, onFailure, onQueryError, onSuccess) => {
    const mongoOptions = {
    };
    try {
        dbOps.count("User", query, mongoOptions, (err, count) => {
            if (err) {
                onQueryError(Error.errorJson(err))
            } else {
                onSuccess(count);
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

// Read one identified by its ID
UserDao.readOne = (id, onFailure, onQueryError, onNotFound, onSuccess) => {
    try {
        dbOps.readOne("User", id, (err, result) => {
            if (err) {
                onQueryError(Error.errorJson(err));
            } else {
                if (result === null || result === undefined) {
                    onNotFound(Error.errorJson({errmsg:"User not found"}));
                } else {
                    onSuccess(dbOps.mongoIdToId(result));
                }
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

UserDao.findOne = (query, options, onFailure, onQueryError, onNotFound, onSuccess) => {
    options.limit = 1;
    UserDao.readMany(query, options, onFailure, onQueryError,
        (result) => {
            if (result.length == 0) {
                onNotFound(Error.errorJson({errmsg:"User not found"}));
            } else {
                onSuccess(result[0]);
            }
        }
    );
}

// Read many from attributes
UserDao.readMany = (query, options, onFailure, onQueryError, onSuccess) => {
    try {
        const mongoOptions = {
            limit: options.limit
        };

        Object.keys(query).forEach((attrName)=> {
            var attrValue = query[attrName];
            if (typeof attrValue === "string") {
                if (options.caseInsensitive) {  // e.g. to login with a case-insensitive username
                    query[attrName] = new RegExp(attrValue, "i");
                }

            } else if (Array.isArray(attrValue)) {
                // If the query value is an array, turn it into a Mongo "$in" query:

                if (attrName === "id" || attrName === "_id") {
                    attrName = "_id"
                    delete query.id
                    attrValue = attrValue.map(v => new ObjectId(v));
                }

                query[attrName] = {
                    $in: attrValue
                }
            }
        });

        dbOps.find("User", query, mongoOptions, (err, result) => {
            if (err) {
                onQueryError(Error.errorJson(err));
            } else {

                try {
                    result.forEach(entity => {
                        dbOps.mongoIdToId(entity);
                    });
                    onSuccess(result);
                } catch (err) {
                    onFailure(Error.handleError("GET", err));
                }

            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

// Delete one record by its ID
UserDao.deleteOne = (id, onFailure, onQueryError, onNotFound, onSuccess) => {
    try {
        dbOps.deleteOne("User", id, (err, result) => {
            if (err) {
                onQueryError(Error.errorJson(err));
            } else if (result.deletedCount === 0) {
                onNotFound(Error.errorJson({errmsg: "User not found"}));
            } else {
                onSuccess({
                    deletedCount: result.deletedCount
                });
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

// Delete records by matching key:value pairs contained as a Json object in the request body.
UserDao.deleteMany = (query, onFailure, onQueryError, onSuccess) => {
    try {
        Object.keys(query).forEach((attrName)=> {
            var attrValue = query[attrName];
            if (Array.isArray(attrValue)) {
                // If the query value is an array, turn it into a Mongo "$in" query:

                if (attrName === "id" || attrName === "_id") {
                    attrName = "_id"
                    delete query.id
                    attrValue = attrValue.map(v => new ObjectId(v));
                }

                query[attrName] = {
                    $in: attrValue
                }
            }
        });

        dbOps.deleteMany("User", query, (err, result) => {
            if (err) {
                onQueryError(Error.errorJson(err));
            } else {
                onSuccess({
                    deletedCount: result.deletedCount
                });
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

// Update/replace the whole entity
UserDao.replaceOne = (id, data, onFailure, onQueryError, onSuccess) => {
    try {
        dbOps.put("User", id, UserDao.attributes, data, (err, result) => {
            if (err) {
                onQueryError(Error.errorJson(err));
            } else {
                onSuccess({
                    modified: result.result.nModified
                });
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

// Update/modify individual fields in the entity
UserDao.patchOne = (id, data, onFailure, onQueryError, onSuccess) => {
    try {
        dbOps.patch("User", id, UserDao.attributes, data, (err, result) => {
            if (err) {
                onQueryError(Error.errorJson(err));
            } else {
                onSuccess({
                    modified : result.result.nModified
                });
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

module.exports = UserDao
