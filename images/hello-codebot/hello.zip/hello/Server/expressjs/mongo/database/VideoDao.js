const dbOps = require("../db_ops.js")
const Error = require('../errors.js')
const ObjectId = require('mongodb').ObjectID;

const VideoDao = {
    attribute_schema: require('../json_schema/Video.schema.json'),
    attributes: [ // Domain model attributes, plus any relationship fields
        "name",
        "url"
    ],

    ensureIndexes: () => {
        dbOps.ensureIndexes("Video");
    }
};


VideoDao.check_collection = function() {
    dbOps.check_collection("Video", VideoDao.attribute_schema,
        (err, result) => {
            if (err) {
                console.error("Error checking Video schema:");
                console.error(err);
            } else {
                console.log("Video schema checked");
            }
        }
    );
}

VideoDao.dbError = (action, err) =>{
    console.log("Database error: ", err);

    switch (err.code) {
        case 11000: return "Duplicate Video";
    };

    return `Cannot ${action}: database error`;
}

// Create one or create many
VideoDao.create = (data, onFailure, onCreateError, onSuccess) => {
    try {
        dbOps.create("Video", VideoDao.attributes, data, (err, result) => {
            if (err) {
                const msg = VideoDao.dbError("create", err);
                onCreateError(Error.errorJson(msg));
            } else {
                const data = result.ops.map(rec => {
                    rec.id = rec._id;
                    delete rec._id;
                    return rec;
                });
                const insertedIds =
                    result.insertedIds === undefined?
                        [result.insertedId.toString()] :
                        Object.keys(result.insertedIds).map(key => result.insertedIds[key].toString());
                const response = {
                    data: data,
                    insertedCount: result.insertedCount,
                    insertedIds: insertedIds
                };
                onSuccess(response);
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

// Count the total number of Video records
VideoDao.countAll = (onFailure, onQueryError, onSuccess) => {
    VideoDao.count({}, onFailure, onQueryError, onSuccess)
}

// Count the number of Video records matching the query
VideoDao.count = (query, onFailure, onQueryError, onSuccess) => {
    const mongoOptions = {
    };
    try {
        dbOps.count("Video", query, mongoOptions, (err, count) => {
            if (err) {
                onQueryError(Error.errorJson(err))
            } else {
                onSuccess(count);
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

// Read one identified by its ID
VideoDao.readOne = (id, onFailure, onQueryError, onNotFound, onSuccess) => {
    try {
        dbOps.readOne("Video", id, (err, result) => {
            if (err) {
                onQueryError(Error.errorJson(err));
            } else {
                if (result === null || result === undefined) {
                    onNotFound(Error.errorJson({errmsg:"Video not found"}));
                } else {
                    onSuccess(dbOps.mongoIdToId(result));
                }
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

VideoDao.findOne = (query, options, onFailure, onQueryError, onNotFound, onSuccess) => {
    options.limit = 1;
    VideoDao.readMany(query, options, onFailure, onQueryError,
        (result) => {
            if (result.length == 0) {
                onNotFound(Error.errorJson({errmsg:"Video not found"}));
            } else {
                onSuccess(result[0]);
            }
        }
    );
}

// Read many from attributes
VideoDao.readMany = (query, options, onFailure, onQueryError, onSuccess) => {
    try {
        const mongoOptions = {
            limit: options.limit
        };

        Object.keys(query).forEach((attrName)=> {
            var attrValue = query[attrName];
            if (typeof attrValue === "string") {
                if (options.caseInsensitive) {  // e.g. to login with a case-insensitive username
                    query[attrName] = new RegExp(attrValue, "i");
                }

            } else if (Array.isArray(attrValue)) {
                // If the query value is an array, turn it into a Mongo "$in" query:

                if (attrName === "id" || attrName === "_id") {
                    attrName = "_id"
                    delete query.id
                    attrValue = attrValue.map(v => new ObjectId(v));
                }

                query[attrName] = {
                    $in: attrValue
                }
            }
        });

        dbOps.find("Video", query, mongoOptions, (err, result) => {
            if (err) {
                onQueryError(Error.errorJson(err));
            } else {

                try {
                    result.forEach(entity => {
                        dbOps.mongoIdToId(entity);
                    });
                    onSuccess(result);
                } catch (err) {
                    onFailure(Error.handleError("GET", err));
                }

            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

// Delete one record by its ID
VideoDao.deleteOne = (id, onFailure, onQueryError, onNotFound, onSuccess) => {
    try {
        dbOps.deleteOne("Video", id, (err, result) => {
            if (err) {
                onQueryError(Error.errorJson(err));
            } else if (result.deletedCount === 0) {
                onNotFound(Error.errorJson({errmsg: "Video not found"}));
            } else {
                onSuccess({
                    deletedCount: result.deletedCount
                });
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

// Delete records by matching key:value pairs contained as a Json object in the request body.
VideoDao.deleteMany = (query, onFailure, onQueryError, onSuccess) => {
    try {
        Object.keys(query).forEach((attrName)=> {
            var attrValue = query[attrName];
            if (Array.isArray(attrValue)) {
                // If the query value is an array, turn it into a Mongo "$in" query:

                if (attrName === "id" || attrName === "_id") {
                    attrName = "_id"
                    delete query.id
                    attrValue = attrValue.map(v => new ObjectId(v));
                }

                query[attrName] = {
                    $in: attrValue
                }
            }
        });

        dbOps.deleteMany("Video", query, (err, result) => {
            if (err) {
                onQueryError(Error.errorJson(err));
            } else {
                onSuccess({
                    deletedCount: result.deletedCount
                });
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

// Update/replace the whole entity
VideoDao.replaceOne = (id, data, onFailure, onQueryError, onSuccess) => {
    try {
        dbOps.put("Video", id, VideoDao.attributes, data, (err, result) => {
            if (err) {
                onQueryError(Error.errorJson(err));
            } else {
                onSuccess({
                    modified: result.result.nModified
                });
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

// Update/modify individual fields in the entity
VideoDao.patchOne = (id, data, onFailure, onQueryError, onSuccess) => {
    try {
        dbOps.patch("Video", id, VideoDao.attributes, data, (err, result) => {
            if (err) {
                onQueryError(Error.errorJson(err));
            } else {
                onSuccess({
                    modified : result.result.nModified
                });
            }
        });
    } catch (err) {
        onFailure(Error.handleError("GET", err))
    }
}

module.exports = VideoDao
