var ObjectId = require('mongodb').ObjectID;

var typeConverter = {};

// MongoDB types
typeConverter.type = {
	"double" : 1,
	"string" : 2,
	"object" : 3,
	"array" : 4,
	"binData" : 5,
	"objectId" : 7,
	"bool" : 8,
	"date" : 9,
	"integer" : 16,
	"timestamp" : 17,
	"long" : 18,		// 64-bit integer
	"decimal" : 19		// Decimal128
};

typeConverter.typeConvert = function(data, key, schema) {
    const value = data[key];
    const schemaProperties = schema.properties || schema;
    const property = schemaProperties[key];
    const type = property.type;

    switch(type) {
        case "number":
        case "double":
        case "decimal":
            return parseFloat(value);
        case "string":
            return String(value);
        case "object":
            return typeConverter.convert(data[key], property);
        case "array":
            if (property.items.type === 'object') {
                return value.map(v=> typeConverter.convert(v, property.items.properties));
            } else {
                return value.map(v => {
                    const data = {'items': [v]};
                    return typeConverter.typeConvert(data, 'items', property);
                });
            }
        case "bool":
        case "boolean":
            return value == true;
        case "date":
            return new Date(value);
        case "int":
        case "integer":
        case "long":
            return parseInt(value);
        case "objectId":
            return new ObjectId(value);
        default:
            throw "Cannot convert unrecognised type: " + type;
    }
}

/**
 * Converts the input Json Schema type to a MongoDB type.
 */
typeConverter.convert = function(data, attribute_schema) {
    return Object.keys(data).reduce((acc, key) => {
        if (attribute_schema.properties && attribute_schema.properties.hasOwnProperty(key)) {
            acc[key] = typeConverter.typeConvert(data, key, attribute_schema);
        } else {
        	acc[key] = data[key];
        }
        return acc;
    }, {});
}

module.exports = typeConverter;
