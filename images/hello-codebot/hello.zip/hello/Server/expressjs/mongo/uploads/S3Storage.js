const config = require('config');
const AWS = require("aws-sdk");
const multerS3 = require('multer-s3');
const Error = require('../errors.js');

AWS.config.update(config.get('aws'));
const s3 = new AWS.S3();
const bucket = config.get('uploads.s3.bucket');

function createUploader() {
  console.log(`Initialising S3 uploader: bucket ${bucket}, root folder matt/hello`);
  return multerS3(
    {
      s3: s3,
      bucket: bucket,
      key: (req, file, callback) => {
        const uploadNamespace = `${req.entityName}/${req.attrName}`;
        console.log(`S3 uploader: received file, uploading to namespace ${uploadNamespace}. MIME type=${file.mimetype}, encoding=${file.encoding}, entityId=${req.entityId}`);
        console.log("Content length is: " + req.headers['content-length']);
        callback(null, `matt/hello/${uploadNamespace}/${req.entityId}`);
      }
    }
  );
}

function createDownloader() {
  return (entityId, entityName, attrName, originalFilename, res) => {
    const uploadNamespace = `${entityName}/${attrName}`;
    const filename = `matt/hello/${uploadNamespace}/${entityId}`;
    const params = { Bucket: bucket, Key: filename };

    console.log(`Retrieving ${filename} from s3 bucket ${bucket}.`);
    s3.getObject(params, (err, data) => {
      if (err) {
        switch (err.statusCode) {
          case 404:
            res.status(404).send(Error.errorJson("File not found."));
            break;
          case 403:
            res.status(500).send(Error.errorJson("We don't have access to the configured storage. Please check your project config."))
            break;
          default:
            res.status(500).send(Error.errorJson("Error retrieving the file."));
        }
      } else {
        const file = new Buffer(data.Body, 'base64');
        res.attachment(originalFilename);
        res.status(200).send(file);
      }
    });
  }
}


function createDeleter() {
  return (entityId, entityName, attrName, res, onSuccess, onNotFound) => {
    const uploadNamespace = `${entityName}/${attrName}`;
    const filename = `matt/hello/${uploadNamespace}/${entityId}`;
    const params = { Bucket: bucket, Key: filename };

    console.log(`Deleting ${filename} (if it exists) from s3 bucket ${bucket}.`);
    s3.deleteObject(params, (err, data) => {
      if (err) {
        switch (err.statusCode) {
          case 404:
            if (onNotFound) onNotFound(); else onSuccess();
          case 403:
            res.status(500).send(Error.errorJson("We don't have access to the configured storage. Please check your project config."))
            break;
          default:
            res.status(500).send(Error.errorJson("Error deleting the file."));
        }
      } else {
        onSuccess();
      }
    });
  }
}

module.exports = {
  createUploader: createUploader,
  createDownloader: createDownloader,
  createDeleter: createDeleter
}
