const config = require('config');
const dbClient = require('../db_connection');
const GridFsStorage = require('multer-gridfs-storage');
const Error = require('../errors.js');

const bucket = config.get("uploads.gridfs.bucket");

function createUploader() {

  return new GridFsStorage({
    url: config.get("database.mongodb.connectionUrl"),
    file: (req, file) => {
      const uploadNamespace = `${req.entityName}/${req.attrName}`;
      return {
        bucketName: bucket,
        filename: `${uploadNamespace}.${req.entityId}`
      }
    }
  });
}

function withFileRef(entityId, entityName, attrName, res, onFound, onNotFound) {
  dbClient.withDb(
    err => {
      res.status(500).send(Error.handleError("connecting to Mongo/GridFS", err));
    },
    db => {
      const fileCollection = db.collection(`${bucket}.files`);
      const chunksCollection = db.collection(`${bucket}.chunks`);
      const filename = `${entityName}/${attrName}.${entityId}`;

      fileCollection.find({ filename: filename }).toArray(function (err, docs) {
        if (err) {
          res.status(500).send(Error.handleError("retrieving file info from Mongo/GridFS", err));
        } else {
          if (docs.length === 0) {
            if (onNotFound) {
              onNotFound();
            } else {
              res.status(404).send(Error.errorJson("File not found."));
            }
          } else {
            onFound(docs[0], filename, fileCollection, chunksCollection);
          }
        }
      });
    })
}

function createDownloader() {
  return (entityId, entityName, attrName, originalFilename, res) => {
    withFileRef(entityId, entityName, attrName, res,
      (fileRef, filename, fileCollection, chunksCollection) => {
        chunksCollection.find({ files_id: fileRef._id })
          .sort({ n: 1 }).toArray(function (err, chunks) {
            if (err) {
              res.status(500).send(Error.handleError("retrieving file chunks from Mongo/GridFS", err));
            } else {
              if (!chunks || chunks.length === 0) {
                res.status(404).send(Error.errorJson("File parts not found."));
              } else {
                const buffers = chunks.map(chunk => chunk.data.buffer);
                const file = Buffer.concat(buffers);
                res.attachment(originalFilename);
                res.status(200).send(file);
              }
            }
          });
      });
  }
}


function createDeleter() {
  return (entityId, entityName, attrName, res, onSuccess, onNotFound) => {
    withFileRef(entityId, entityName, attrName, res,
      (fileRef, filename, fileCollection, chunksCollection) => {
        chunksCollection.deleteMany({}, (err, obj) => {
          if (err) {
            console.log(err);
            res.status(500).send(Error.errorJson("Error deleting the file chunks."));
          } else {
            fileCollection.deleteOne({ filename: filename }, (err, obj) => {
              if (err) {
                console.log(err);
                res.status(500).send(Error.errorJson("Error deleting the file."));
              } else {
                onSuccess();
              }
            });
          }
        });
      }, onNotFound);
  };
}

module.exports = {
  createUploader: createUploader,
  createDownloader: createDownloader,
  createDeleter: createDeleter
}
