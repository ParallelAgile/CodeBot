const config = require('config');
const bytes = require('bytes');
const path = require('path');
const multer = require('multer');
const Error = require('../errors.js');

const filesizeLimitBytes = bytes.parse(config.get("uploads.maxFileSize"))

function chooseStorage() {
  const useStorage = config.get("uploads.storage");
  switch (useStorage) {
    case "filesystem":
      console.log(`Using filesystem storage engine for file uploads.`);
      return require('./FilesystemStorage');

    case "s3":
      console.log(`Using s3 storage engine for file uploads.`);
      return require('./S3Storage');

    case "gridfs":
      console.log(`Using gridfs storage engine for file uploads.`);
      return require('./GridFsStorage');

    default:
      throw `Configured storage engine "${useStorage}" must be one of: filesystem, s3, gridfs`
  }
}

const storage = chooseStorage();

function fileTypeValidator(regex) {
  let maybeRegex;
  if (regex !== undefined && regex !== "") {
    maybeRegex = regex;
  } else {
    if (config.has("uploads.types")) {
      const r = config.get("uploads.types");
      if (r !== "") maybeRegex = new RegExp(r);
    }
  }

  const checkTypes = maybeRegex != undefined;

  return (req, file, callback) => {
    if (checkTypes) {
      const ext = path.extname(file.originalname).toLowerCase();
      const mime = file.mimetype;

      const extOk = maybeRegex.test(ext);
      const mimeOk = maybeRegex.test(mime); // "image/jpeg" should match the same 'types' regex as "jpeg"

      if (extOk && mimeOk) {
        callback(null, true);
      } else {
        console.log(`${invalidFileTypeMsg}: ${ext}, ${mime}`);
        callback(invalidFileTypeMsg, false);
      }
    } else {
      callback(null, true);
    }
   }
}

const invalidFileTypeMsg = "Invalid file extension or mime type";

// Returns a constructed middleware function to upload a file.
function createUploader(fileTypeRegex) {
  const uploader = multer({
    limits: {
      fileSize: filesizeLimitBytes
    },
    fileFilter: fileTypeValidator(fileTypeRegex),
    storage: storage.createUploader()
  }).single('file');

  return (req, res, next) => {
    try {
        uploader(req, res, (err) => {
          if (err instanceof multer.MulterError) {
            // Multer error uploading
            console.log("Multer error uploading: " + err);
            res.status(500).send(err);
          } else if (err) {
            // General error uploading
            console.log("Error uploading: " + err);
            console.trace();

            if (err === invalidFileTypeMsg) {
              res.status(400).send(Error.errorJson(err));
            } else if (err.statusCode === 403) {
              res.status(500).send(Error.errorJson("We don't have access to the configured storage. Please check your project config."))
            } else {
              res.status(500).send(err);
            }

          } else {
            if (req.file === undefined) {
              console.log("No file was provided");
              res.status(400).send(Error.errorJson("File should be in a form field called 'file'"));
            } else {
              // upload worked
              console.log(`File ${req.file.originalname} uploaded to ${req.file.destination}/${req.file.filename}`);
              next();
            }
          }
        });
    } catch (err) {
        res.status(500).send(Error.handleError("POST multipart file", err));
    }
  };
}

function createDownloader() {
  return storage.createDownloader();
}

function createDeleter() {
  return storage.createDeleter();
}

// Returns a constructed middleware function to check that a file exists.
function createFileExistenceChecker() { // TODO
    return (req, res, next) => {
        next();
    }
}

// Returns a constructed middleware function to check that a file doesn't already exist.
function createFileNonexistenceChecker() { // TODO
    return (req, res, next) => {
        next();
    }
}

module.exports = {
  createUploader: createUploader,
  createDownloader: createDownloader,
  createDeleter: createDeleter,
  createFileExistenceChecker: createFileExistenceChecker,
  createFileNonexistenceChecker: createFileNonexistenceChecker
}
