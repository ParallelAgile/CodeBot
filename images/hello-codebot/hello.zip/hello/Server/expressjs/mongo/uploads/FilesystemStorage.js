const config = require('config');
const fs = require('fs');
const multer = require('multer');
const Error = require('../errors.js');

const rootFolder = config.get('uploads.filesystem.folder');

function pathTo(namespace) {
  return `${rootFolder}/matt/hello/${namespace}`;
}

function createUploader() {
  return multer.diskStorage({
    destination: (req, file, callback) => {
      const uploadNamespace = `${req.entityName}/${req.attrName}`;
      const dir = pathTo(uploadNamespace);

      try {
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
        }
        callback(null, dir);
      } catch (err) {
        console.log(`Error creating storage directory ${dir}: ${err}`);
        callback(err, null);
      }
    },
    filename: (req, file, callback) => {
      callback(null, req.entityId);
    }
  });
}


function createDownloader() {
  return (entityId, entityName, attrName, originalFilename, res) => {
    const uploadNamespace = `${entityName}/${attrName}`;
    const dir = pathTo(uploadNamespace);
    const filename = `${dir}/${entityId}`;

    if (fs.existsSync(filename)) {
      res.attachment(originalFilename).sendFile(filename, {root: "."});
    } else {
      res.status(404).send(Error.errorJson("No file has been uploaded for the requested entity/attribute."));
    }
  }
}


function createDeleter() {
  return (entityId, entityName, attrName, res, onSuccess, onNotFound) => {
    const uploadNamespace = `${entityName}/${attrName}`;
    const dir = pathTo(uploadNamespace);
    const filename = `${dir}/${entityId}`;

    try {
      if (fs.existsSync(filename)) {
        console.log(`Deleting ${filename} from filesystem.`);
        fs.unlinkSync(filename);
        onSuccess();
      } else {
        if (onNotFound) onNotFound(); else onSuccess();
      }
    } catch (err) {
      console.log(`Error deleting storage file ${filename}: ${err}`);
      res.status(500).send(Error.errorJson("Error deleting the file."));
    }
  }
}


module.exports = {
  createUploader: createUploader,
  createDownloader: createDownloader,
  createDeleter: createDeleter
}
