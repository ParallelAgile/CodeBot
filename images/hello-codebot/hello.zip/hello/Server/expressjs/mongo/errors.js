
const handleError = function (where, err) {
  var msg = "Internal Error in " + where + ": " + (err.message === undefined ? JSON.stringify(err) : err.message)
  console.log(msg)
  if (err) {
    console.log(err.stack)
  } else {
    console.log(new Error().stack)
  }
  return {
    "message": msg
  }
}

const errorJson = function (err) {
  var msg
  if (typeof err == "string") msg = err
  else if (err.errmsg !== undefined) msg = err.errmsg
  else if (err.message !== undefined) msg = err.message
  else if (err.sqlMessage !== undefined) msg = `${err.code} ${err.sqlMessage}`

  return {
    "message": msg
  }
}

const sendError = function (res, status, err) {
  return res.status(status).send(errorJson(err));
}


module.exports.handleError = handleError
module.exports.errorJson = errorJson
