db = db.getSiblingDB('hello');

db.User.update(
  {'username': 'admin'},
  {
    'username': 'admin',
    'password': '6wF408ejFh',
    'email': '',
    'roles': ''
  },
  upsert = true
);
