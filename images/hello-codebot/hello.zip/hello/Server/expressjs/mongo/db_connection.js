const config = require('config');
const MongoClient = require('mongodb').MongoClient;

/*
 * Define your database connection string here.
 * e.g.  mongodb://localhost:27017/<db name>
 * See: https://docs.mongodb.com/manual/reference/connection-string
 */
const db_url = config.get("database.mongodb.connectionUrl");

const Wrapper = function() {
};

Wrapper.prototype.withDb = function(errorCallback, successCallback) {
    var wrapper = this;
    if (!wrapper.db) {
        try {
            MongoClient.connect(db_url, { poolSize : 50, connectTimeoutMS: 10000 }, function (err, client) {
                if (err) {
                    var msg = err.message === undefined? JSON.stringify(err) : err.message;
                    console.log("Error connecting to the database with URL '" + db_url + "': " + msg);
                    errorCallback(err);
                } else {
                    console.log("Opened a new database connection");
                    wrapper.db = client.db();
                    successCallback(wrapper.db);
                }
            });
        } catch (err) {
            console.log("Error connecting to DB with URL '" + db_url + ": " + JSON.stringify(err));
            errorCallback(err);
        }

    } else {
        successCallback(wrapper.db);
    }
}

module.exports = new Wrapper();
