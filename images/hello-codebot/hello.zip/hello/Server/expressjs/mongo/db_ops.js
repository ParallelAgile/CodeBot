const wrapper = require("./db_connection.js");
const ObjectId = require('mongodb').ObjectID;
const fs = require('fs');

const dbOps = {};

const indexes = fs.existsSync("indexes.json")?
    JSON.parse(fs.readFileSync('indexes.json', 'utf8')) : [];


dbOps.ensureIndexes = function (collection) {
    const collIndexes = indexes[collection];
    if (Array.isArray(collIndexes)) {
        wrapper.withDb(
            err => {
                onResult(err, null)
            },
            db => {
                console.log(`Ensuring indexes for collection ${collection}`);
                const coll = db.collection(collection);
                collIndexes.forEach(index => {
                    const indexObj = {};
                    indexObj[index.attribute] = index.direction;
                    coll.createIndex(indexObj, { unique: index.unique });
                });
            }
        )
    }
}

dbOps.create = function(collection, columns, data, onResult) {
    wrapper.withDb(
        err => {
            onResult(err, null);
        },
        db => {
            if (Array.isArray(data)) {
                db.collection(collection).insertMany(data, {w: 1}, onResult);
            } else {
                db.collection(collection).insertOne(data, {w: 1}, onResult);
            }
        }
    );
}

dbOps.readOne = function(collection, id, onResult) {
    if (id.length === 24) {
        try {
            wrapper.withDb(
                err => {
                    onResult(err, null);
                },
                db => {
                    const options = {
                        limit: 1
                    }
                    const query = {
                        _id: new ObjectId(id)
                    }
                    db.collection(collection).find(query, options).next(onResult);
                }
            );
        } catch (err) {
            console.log("Error querying for one item: " + JSON.stringify(err));
            onResult({errmsg: "Database query error"}, null);
        }
    } else {
        onResult(dbOps.invalidIdResult, null);
    }
}

dbOps.find = function(collection, query, options, onResult) {
    wrapper.withDb(
        err => {
            onResult(err, null);
        },
        db => {
            db.collection(collection).find(query, options).toArray(onResult);
        }
    );
}

dbOps.count = function(collection, query, options, onResult) {
    wrapper.withDb(
        err => {
            onResult(err, null);
        },
        db => {
            db.collection(collection).countDocuments(query, options, onResult);
        }
    );
}


dbOps.deleteOne = function(collection, id, onResult) {
    wrapper.withDb(
        err => {
            onResult(err, null);
        },
        db => {
            var query = {
              _id: new ObjectId(id)
            };
            db.collection(collection).removeOne(query, {w: 1}, onResult);
        }
    );
}

// Remove documents with matching key-value pairs
dbOps.deleteMany = function(collection, query, onResult) {
    if (typeof query === "undefined") query = {};
    wrapper.withDb(
        err => {
            onResult(err, null);
        },
        db => {
            db.collection(collection).removeMany(query, {w: 1}, onResult);
        }
    );
}

dbOps.put = function(collection, _id, columns, data, onResult) {
    if (_id.length === 24) {
        wrapper.withDb(
            err => {
                onResult(err, null);
            },
            db => {
                const query = {
                  _id: new ObjectId(_id)
                };
                const newValues = {
                    $set: data
                };
                db.collection(collection).updateOne(query, newValues, onResult);
            }
        );
    } else {
        onResult(dbOps.invalidIdResult, null);
    }
}

dbOps.invalidIdResult = {
    errmsg: "Invalid ID parameter, to be a valid Mongo UID it must be exactly 24 characters"
};

dbOps.patch = function(collection, _id, columns, data, onResult) {
    if (_id.length === 24) {
        wrapper.withDb(
            err => {
                onResult(err, null);
            },
            db => {
                const query = {
                  _id: new ObjectId(_id)
                };
                const newValues = {
                    $set: data
                };
                db.collection(collection).updateOne(query, newValues, onResult);
            }
        );
    } else {
        onResult(dbOps.invalidIdResult, null);
    }
}

// Move incoming id field to _id.
dbOps.idToMongoId = function(entity) {
    if (entity === null || entity === undefined) return entity;
    if (entity["id"] !== undefined && typeof entity.id === "string" && entity.id.length === 24) {
        entity["_id"] = new ObjectId(entity.id);
    }
    delete entity.id;

    Object.getOwnPropertyNames(entity).forEach(name => {
        var v = entity[name];
        if (v !== null && typeof v === "object") {
            dbOps.idToMongoId(v);
        } else if (Array.isArray(v)) {
            v.forEach(el => {if (el !== null && typeof el === "object") dbOps.idToMongoId(el)});
        }
    });
    return entity;
}

// Move the _id field to id, to return via the API.
dbOps.mongoIdToId = function(entity) {
    if (entity === null || entity === undefined) return entity;
    var id = dbOps.mongoIdAsString(entity);
    if (id !== undefined) {
      entity["id"] = id;
      delete entity._id;
    }

    Object.getOwnPropertyNames(entity).forEach(name => {
        var v = entity[name];
        if (v !== null && typeof v === "object") {
            dbOps.mongoIdToId(v);
        } else if (Array.isArray(v)) {
            v.forEach(el => {if (el !== null && typeof el === "object") dbOps.mongoIdToId(el)});
        }
    });

    return entity;
}

// Returns the _id field if it exists and is a valid Mongo ID, otherwise returns undefined.
dbOps.mongoIdAsString = function(entity) {
    if (entity.hasOwnProperty("_id")) {
        var id = entity._id;
        var idType = typeof id;
        if (idType !== null && idType === "object") {
            return id.hasOwnProperty("str")? id.str : id.toString();
        } else if (idType === "string" && id.length == 24) {
            return id;
        }

    } else return undefined;
}

module.exports = dbOps;
