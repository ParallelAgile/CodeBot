const mongodb = require('mongodb');
const ObjectId = require('mongodb').ObjectID;
const typeConverter = require("../type_converter.js");
const VideoDao = require("../database/VideoDao.js");

const VideoAdapter = {};
/*
 * Create MongoDB IDs (immutable "_id" field) for any nested objects.
 */
VideoAdapter.allocateIds = function(video) {
    return video;
}

VideoAdapter.prepForCreate = function(video) {
    return VideoAdapter.allocateIds(video);
}

VideoAdapter.prepForUpdate = function(video) {
    // The top-level _id is removed from the object for update:
    delete video["_id"];
    delete video["id"];

    // This is just for the nested objects:
    return typeConverter.convert(video, VideoDao.attribute_schema);
}

module.exports = VideoAdapter;
