const mongodb = require('mongodb');
const ObjectId = require('mongodb').ObjectID;
const typeConverter = require("../type_converter.js");
const UserDao = require("../database/UserDao.js");

const UserAdapter = {};
/*
 * Create MongoDB IDs (immutable "_id" field) for any nested objects.
 */
UserAdapter.allocateIds = function(user) {
    return user;
}

UserAdapter.prepForCreate = function(user) {
    return UserAdapter.allocateIds(user);
}

UserAdapter.prepForUpdate = function(user) {
    // The top-level _id is removed from the object for update:
    delete user["_id"];
    delete user["id"];

    // This is just for the nested objects:
    return typeConverter.convert(user, UserDao.attribute_schema);
}

module.exports = UserAdapter;
