import * as React from "react"
import { useSelector } from 'react-redux'
import ReactPlayer from 'react-player'
import { AppState } from "../store"

interface Props {
  url?: string
  urlSelector?: (appState: AppState) => string | null
  noUrlMsg?: string
  cssClass?: string
}

const CbMediaPlayer: React.FC<Props> = props => {
  const selector = props.urlSelector || (() => null)
  const videoUrl = useSelector(selector) || props.url

  return videoUrl
    ? (
      <ReactPlayer
        className={props.cssClass || "cbMediaPlayer"}
        width="100%"
        url={videoUrl}
        controls={true}
        playing />
    )
    : (<div>{props.noUrlMsg || "Please choose a video to watch."}</div>)
}

export default CbMediaPlayer
