import * as React from "react"
import { Form } from "react-bootstrap"
import { useSelector } from 'react-redux'
import { AppState } from "../store"

interface Props {
    name: string,
    type?: string // text, number or password; default is text.
    valueSelector: (appState: AppState) => string | number,
    onValueChange: (newText: string | number) => void,
    className?: string
    disabled: boolean
    placeholder?: string
}

const CbTextField: React.FC<Props> = props => {
    const type = props.type || "text"
    const className = (props.className || "") + ` cb${type}Field`
    const val: string | number | boolean = useSelector(props.valueSelector)
    const value = typeof val === "boolean"? ""+val : val

    return (
        <Form.Control name={props.name}
            type={type}
            value={value}
            disabled={props.disabled}
            className={className}
            placeholder={props.placeholder}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                const value = type === "number" ? e.currentTarget.valueAsNumber : e.currentTarget.value
                props.onValueChange(value)
            }
            } />
    )
}

export default CbTextField
