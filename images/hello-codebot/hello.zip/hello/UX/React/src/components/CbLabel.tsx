import * as React from "react"
import Alert from "react-bootstrap/Alert"

interface Props {
  variant?: string,
  className?: string,
}

const CbLabel: React.FC<Props> = props => {
  const cssClass = (props.className || "") + " cbLabel"

  return (
    props.variant
      ? <Alert variant={props.variant} className={cssClass}>{ props.children }</Alert>
      : <span className={cssClass}>{ props.children }</span>
  )
}

export default CbLabel
