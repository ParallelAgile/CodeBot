import * as React from "react"
import { useSelector } from 'react-redux'
import Image from "react-bootstrap/Image"

import { AppState } from "../store"

interface Props {
  srcSelector: (appState: AppState) => string | null
  defaultSrc?: string,
  title?: string,
  className?: string,
  shape?: string,
  fluid?: boolean
}

const CbImage: React.FC<Props> = props => {
  const src = useSelector(props.srcSelector) || props.defaultSrc

  const cssClass = (props.className || "") + " cbImage"
  const rounded = props.shape === "rounded"
  const roundedCircle = props.shape === "roundedCircle"
  const thumbnail = props.shape === "thumbnail"
  const fluid = props.fluid === undefined ? true : props.fluid

  return (
    <Image title={props.title} className={cssClass} src={src} fluid={fluid} rounded={rounded} roundedCircle={roundedCircle} thumbnail={thumbnail} />
  )
}

export default CbImage
