import * as React from "react"
import { useSelector } from 'react-redux'
import Dropdown from 'react-bootstrap/Dropdown'
import DropdownButton from 'react-bootstrap/DropdownButton'

import { AppState } from "../store"
import DomainClass from '../model/_DomainClass'

interface Props {
    title: string
    datasetSelector: (appState: AppState) => DomainClass[]
    datasetFilter?: (item: DomainClass, index: number, items: DomainClass[]) => boolean
    chosenItemSelector: (appState: AppState) => DomainClass | null
    displayAttributeName: string
    onItemSelected: (selectedValue: DomainClass) => void
    className?: string
    variant?: string
}

const CbComboBox: React.FC<Props> = props => {
    const unfilteredItems: DomainClass[] = useSelector(props.datasetSelector)
    const items = props.datasetFilter ? unfilteredItems.filter(props.datasetFilter) : unfilteredItems
    const chosenItemIdSelector = (appState: AppState) => props.chosenItemSelector(appState)?.id || null
    const useVariant = props.variant || "success"

    return (
        <DropdownButton variant={useVariant} title={props.title} className={props.className}>
            {
                items.map((item, i: number) => {
                    return (
                        <CbComboBoxItem
                            key={i}
                            eventKey={"" + i}
                            item={item}
                            chosenItemIdSelector={chosenItemIdSelector}
                            displayAttributeName={props.displayAttributeName}
                            onItemSelected={props.onItemSelected}
                        />
                    )
                })
            }
        </DropdownButton>
    )
}

interface ItemProps {
    eventKey: string
    item: DomainClass
    chosenItemIdSelector: (appState: AppState) => string | null
    displayAttributeName: string
    onItemSelected: (selectedValue: DomainClass) => void
}

const CbComboBoxItem: React.FC<ItemProps> = itemProps => {
    const item = itemProps.item
    const selectedItemId: string | null = useSelector(itemProps.chosenItemIdSelector)
    const displayValue = item[itemProps.displayAttributeName] || `(missing attribute: ${itemProps.displayAttributeName})`

    return (
        <Dropdown.Item eventKey={itemProps.eventKey} active={item.id === selectedItemId} onClick={() => itemProps.onItemSelected(item)}>
            { displayValue}
        </Dropdown.Item>
    )
}

export default CbComboBox
