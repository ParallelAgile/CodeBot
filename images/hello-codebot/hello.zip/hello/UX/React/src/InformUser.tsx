import { toast } from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
import { ApiResult } from "./client/ApiResult"

export class InformUser {

  public static inform(result: ApiResult): void {
    if (result.isOk) InformUser.success(result.message)
    else if (result.status === 400 || result.status === 401) InformUser.info(result.message)
    else InformUser.error(result.message)
  }

  public static info(msg: String): void {
    toast.info(msg, {
      position: "top-center",
      autoClose: 0,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true
    })
  }

  public static success(msg: String): void {
    toast.success(msg, {
      position: "top-center",
      autoClose: 3200,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    })
  }

  public static error(msg: String): void {
    msg = msg || "Sorry, there was an error, please try again."
    toast.error(msg, {
      position: "bottom-center",
      autoClose: 3200,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
    })
  }
}
