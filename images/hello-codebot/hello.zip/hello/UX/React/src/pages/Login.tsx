import * as React from "react"
import { useEffect } from "react"
import { useDispatch, useSelector } from 'react-redux'

import { ToastContainer } from 'react-toastify'

import { Alert, Col, Container, Form, Row } from "react-bootstrap"
import Button from "react-bootstrap/Button"
import CbLabel from "../components/CbLabel"
import CbImage from "../components/CbImage"
import global_consts from "../global_consts"
import CbTextField from "../components/CbTextField"

import { UserLogin } from "../model/User"
import { loginFormFormChanged } from "../features/ui/login/login_form/actions"
import { loginFormFormCleared } from "../features/ui/login/login_form/actions"
import { loginFormSendLogin } from "../features/ui/login/login_form/actions"
import { selectLogin_LoginForm_LoginForm } from "../features/ui/login/login_form/selectors"
import { checkLoggedOut, navigateToPage } from "../features/ui/navigation"

import 'react-toastify/dist/ReactToastify.css'
import 'bootstrap/dist/css/bootstrap.css'


interface Props {
}

const Login: React.FC<Props> = props => {
    const dispatch = useDispatch()
    const selectedLoginForm_Credentials: UserLogin = useSelector(selectLogin_LoginForm_LoginForm);

    useEffect(() => {
        dispatch(checkLoggedOut)
    })

    return (
        <>
            <ToastContainer />
            <Container id="login_page" className="PageContainer">
                <Row className="justify-content-md-flex-center cbContainer">
                    <Col sm={12}>
                        <Container id="login_page_container" >
                            <Row className="justify-content-md-flex-center cbContainer">
                                <Col sm={12}>
                                    <CbImage
                                        srcSelector={() => ""}
                                        defaultSrc={global_consts.routesPrefix + "/resources/codebot-banner.png"}
                                        className="cbImage"
                                        fluid={true}
                                    />
                                </Col>
                            </Row>
                            <Row className="justify-content-md-flex-center cbContainer">
                                <Col sm={12}>
                                    <CbLabel className="h1">Hello, CodeBot - Login</CbLabel>
                                </Col>
                            </Row>
                            <Row className="justify-content-md-flex-center cbContainer">
                                <Col sm={12}>
                                    <Container id="login_form_container" >
                                      <Form>
                                       <Alert variant="primary" >
                                        <Row className="justify-content-md-flex-center cbContainer">
                                            <Col sm={4} className="text-left">
                                                <CbLabel>Enter Username</CbLabel>
                                            </Col>
                                            <Col sm={8}>
                                                <CbTextField name="username"
                                                    disabled={false} 
                                                    placeholder="enter your username here"
                                                    valueSelector={() => selectedLoginForm_Credentials.username}
 
                                                    onValueChange={
                                                        value => {
                                                            dispatch(loginFormFormChanged(selectedLoginForm_Credentials, "username", value))



                                                        }
                                                    }
                                                />
                                            </Col>
                                        </Row>
                                        <Row className="justify-content-md-flex-center cbContainer">
                                            <Col sm={4} className="text-left">
                                                <CbLabel>Enter Password</CbLabel>
                                            </Col>
                                            <Col sm={8}>
                                                <CbTextField name="password"
                                                    type="password"
                                                    disabled={false} 
                                                    placeholder="enter your password here"
                                                    valueSelector={() => selectedLoginForm_Credentials.password}
 
                                                    onValueChange={
                                                        value => {
                                                            dispatch(loginFormFormChanged(selectedLoginForm_Credentials, "password", value))



                                                        }
                                                    }
                                                />
                                            </Col>
                                        </Row>
                                        <Row className="justify-content-md-flex-center cbContainer">
                                            <Col sm={12}>
                                                <Button variant="primary" type="button"
                                                    onClick={ () => { dispatch(loginFormSendLogin()) } }
                                                >Login</Button>
                                            </Col>
                                        </Row>
                                       </Alert>
                                      </Form>
                                    </Container>
                                </Col>
                            </Row>
                            <Row className="justify-content-md-flex-center cbContainer">
                                <Col sm={12}>
                                    <Container id="nav_panel_container" className="footerNavPanel">
                                       <Alert variant="secondary" >
                                        <Row className="justify-content-md-flex-center cbContainer">
                                            <Col sm={6}>
                                                <CbLabel className="align-middle">I'm a new user</CbLabel>
                                            </Col>
                                            <Col sm={6}>
                                                <Button variant="secondary" type="button"
                                                    onClick={ () => { dispatch(navigateToPage("Register", {})) } }
                                                >Register</Button>
                                            </Col>
                                        </Row>
                                       </Alert>
                                    </Container>
                                </Col>
                            </Row>
                            <Row className="justify-content-md-flex-center cbContainer">
                                <Col sm={12}>
                                    <a target="_blank" href="https://parallelagile.github.io/CodeBot/codegen-process-guide/hello-codebot-project">
                                        Learn about this project
                                    </a>
                                </Col>
                            </Row>
                        </Container>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default Login
