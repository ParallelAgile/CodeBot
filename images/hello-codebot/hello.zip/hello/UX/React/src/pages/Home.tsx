import * as React from "react"
import { useEffect } from "react"
import { useDispatch, useSelector } from 'react-redux'

import { ToastContainer } from 'react-toastify'

import { Alert, Col, Container, Row } from "react-bootstrap"
import CbLabel from "../components/CbLabel"
import CbImage from "../components/CbImage"
import global_consts from "../global_consts"
import Button from "react-bootstrap/Button"
import CbComboBox from "../components/CbComboBox"
import CbMediaPlayer from "../components/CbMediaPlayer"

import Video from "../model/Video"
import { requestVideoItems } from "../features/domain/video/actions"
import { selectAllVideoItems } from "../features/domain/video/selectors"
import { chooseAVideoItemSelected } from "../features/ui/home/choose_a_video/actions"
import { logoutSendLogout } from "../features/ui/home/logout/actions"
import { logoutSendLogoutResult } from "../features/ui/home/logout/actions"
import { selectHome_ChooseAVideo_ChosenItem } from "../features/ui/home/choose_a_video/selectors"
import { checkLoggedIn } from "../features/ui/navigation"

import 'react-toastify/dist/ReactToastify.css'
import 'bootstrap/dist/css/bootstrap.css'


interface Props {
}

const Home: React.FC<Props> = props => {
    const dispatch = useDispatch()
    const selectedChooseAVideo_ChosenItem: Video | null = useSelector(selectHome_ChooseAVideo_ChosenItem);

    useEffect(() => {
        dispatch(checkLoggedIn)
    })

    useEffect(() => {
        dispatch(requestVideoItems) // Load the Video items from the REST API.
    }, [])

    // State 'Entry' behavior: on entry
    // 
    useEffect(() => {
        console.log("Home - on entry...");
 
    //InformUser.info("sdfsdfsdf");
 
//    const videoApi = require("../client/HelloCodeBotApi").client.videoApi
//    videoApi.createMany([
//        new Video("", "Bugsy Malone", "https://dfgdfgdfg")
//    ]);
    }, []);

    return (
        <>
            <ToastContainer />
            <Container id="home_page" className="PageContainer">
                <Row className="justify-content-md-flex-center cbContainer">
                    <Col sm={12}>
                        <Container id="home_page_container" >
                            <Row className="justify-content-md-flex-center cbContainer">
                                <Col sm={12}>
                                    <Container id="client_area_container" >
                                       <Alert variant="primary" >
                                        <Row className="justify-content-md-flex-center cbContainer">
                                            <Col sm={2}>
                                                <CbImage
                                                    srcSelector={() => ""}
                                                    defaultSrc={global_consts.routesPrefix + "/resources/zefram.png"}
                                                    className="cbImage"
                                                    fluid={false}
                                                />
                                            </Col>
                                            <Col sm={10}>
                                                <CbLabel className="h1 titleNextToImage">Learn About the CodeBot, Luke</CbLabel>
                                            </Col>
                                        </Row>
                                       </Alert>
                                    </Container>
                                </Col>
                            </Row>
                            <Row className="justify-content-md-flex-center cbContainer">
                                <Col sm={12}>

                                    <CbMediaPlayer cssClass={"cbMediaPlayer"} urlSelector={ () => selectedChooseAVideo_ChosenItem?.url || "https://youtu.be/ZUm6esxrua8" } noUrlMsg="Please choose a video to watch." />
 
                                </Col>
                            </Row>
                            <Row className="justify-content-md-flex-center cbContainer">
                                <Col sm={12}>
                                    <CbComboBox
                                        title={selectedChooseAVideo_ChosenItem?.name || 'Choose a Video'}
                                        variant={"primary"}
                                        className="cbComboBox"
                                        displayAttributeName="name"
                                        datasetSelector={selectAllVideoItems}
                                        onItemSelected={
                                            item => {
                                                const value: Video = item as Video
                                                dispatch(chooseAVideoItemSelected(value))
                                            }
                                        }
                                        // This selector is here so that a ComboBox item can be "chosen" in code by updating the UI state:
                                        chosenItemSelector={selectHome_ChooseAVideo_ChosenItem}

                                    />
                                </Col>
                            </Row>
                            <Row className="justify-content-md-flex-center cbContainer">
                                <Col sm={12}>
                                    <Container id="navigation_area_container" >
                                        <Row className="justify-content-md-flex-center cbContainer">
                                            <Col sm={12}>
                                                <a className="BuyCodeBot pulsingButton" target="_blank" href="https://parallelagile.net/BuyNow">
                                                    I want my own CodeBot NOW!
                                                </a>
                                            </Col>
                                        </Row>
                                    </Container>
                                </Col>
                            </Row>
                            <Row className="justify-content-md-flex-end cbContainer">
                                <Col sm={12}>
                                    <Button className="logout" variant="link" type="button"
                                        onClick={ () => { dispatch(logoutSendLogout()) } }
                                    >Logout</Button>
                                </Col>
                            </Row>
                        </Container>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default Home
