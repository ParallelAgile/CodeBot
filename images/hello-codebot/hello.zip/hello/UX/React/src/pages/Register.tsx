import * as React from "react"
import { useEffect } from "react"
import { useDispatch, useSelector } from 'react-redux'

import { ToastContainer } from 'react-toastify'

import { Alert, Col, Container, Form, Row } from "react-bootstrap"
import CbImage from "../components/CbImage"
import global_consts from "../global_consts"
import Button from "react-bootstrap/Button"
import CbLabel from "../components/CbLabel"
import CbTextField from "../components/CbTextField"

import User from "../model/User"
import { clientAreaFormChanged } from "../features/ui/register/client_area/actions"
import { clientAreaFormCleared } from "../features/ui/register/client_area/actions"
import { clientAreaSendRegister } from "../features/ui/register/client_area/actions"
import { selectRegister_ClientArea_RegisterForm } from "../features/ui/register/client_area/selectors"
import { checkLoggedOut, navigateToPage } from "../features/ui/navigation"

import 'react-toastify/dist/ReactToastify.css'
import 'bootstrap/dist/css/bootstrap.css'


interface Props {
}

const Register: React.FC<Props> = props => {
    const dispatch = useDispatch()
    const selectedClientArea_RegisterItem: User = useSelector(selectRegister_ClientArea_RegisterForm);

    useEffect(() => {
        dispatch(checkLoggedOut)
    })

    return (
        <>
            <ToastContainer />
            <Container id="register_page" className="PageContainer">
                <Row className="justify-content-md-flex-center cbContainer">
                    <Col sm={12}>
                        <Container id="register_page_container" >
                            <Row className="justify-content-md-flex-center cbContainer">
                                <Col sm={12}>
                                    <CbImage
                                        srcSelector={() => ""}
                                        defaultSrc={global_consts.routesPrefix + "/resources/codebot-banner.png"}
                                        className="cbImage"
                                        fluid={true}
                                    />
                                </Col>
                            </Row>
                            <Row className="justify-content-md-flex-center cbContainer">
                                <Col sm={12}>
                                    <CbLabel className="h1">Register</CbLabel>
                                </Col>
                            </Row>
                            <Row className="justify-content-md-flex-center cbContainer">
                                <Col sm={12}>
                                    <Container id="client_area_container" >
                                      <Form>
                                       <Alert variant="primary" >
                                        <Row className="justify-content-md-flex-center cbContainer">
                                            <Col sm={4} className="text-left">
                                                <CbLabel>Username</CbLabel>
                                            </Col>
                                            <Col sm={8}>
                                                <CbTextField name="username"
                                                    disabled={false} 
                                                    placeholder="Enter your username"
                                                    valueSelector={() => selectedClientArea_RegisterItem.username}
 
                                                    onValueChange={
                                                        value => {
                                                            dispatch(clientAreaFormChanged(selectedClientArea_RegisterItem, "username", value))



                                                        }
                                                    }
                                                />
                                            </Col>
                                        </Row>
                                        <Row className="justify-content-md-flex-center cbContainer">
                                            <Col sm={4} className="text-left">
                                                <CbLabel>Password</CbLabel>
                                            </Col>
                                            <Col sm={8}>
                                                <CbTextField name="password"
                                                    type="password"
                                                    disabled={false} 
                                                    placeholder="Enter your password"
                                                    valueSelector={() => selectedClientArea_RegisterItem.password}
 
                                                    onValueChange={
                                                        value => {
                                                            dispatch(clientAreaFormChanged(selectedClientArea_RegisterItem, "password", value))



                                                        }
                                                    }
                                                />
                                            </Col>
                                        </Row>
                                        <Row className="justify-content-md-flex-center cbContainer">
                                            <Col sm={4} className="text-left">
                                                <CbLabel>Email</CbLabel>
                                            </Col>
                                            <Col sm={8}>
                                                <CbTextField name="email"
                                                    type="email"
                                                    disabled={false} 
                                                    placeholder="Your email address"
                                                    valueSelector={() => selectedClientArea_RegisterItem.email}
 
                                                    onValueChange={
                                                        value => {
                                                            dispatch(clientAreaFormChanged(selectedClientArea_RegisterItem, "email", value))



                                                        }
                                                    }
                                                />
                                            </Col>
                                        </Row>
                                        <Row className="justify-content-md-flex-center cbContainer">
                                            <Col sm={12}>
                                                <Button variant="primary" type="button"
                                                    onClick={ () => { dispatch(clientAreaSendRegister()) } }
                                                >Register</Button>
                                            </Col>
                                        </Row>
                                       </Alert>
                                      </Form>
                                    </Container>
                                </Col>
                            </Row>
                            <Row className="justify-content-md-flex-center cbContainer">
                                <Col sm={12}>
                                    <Container id="navigation_container" className="footerNavPanel">
                                       <Alert variant="secondary" >
                                        <Row className="justify-content-md-flex-end cbContainer">
                                            <Col sm={6}>
                                                <CbLabel className="align-middle">Already registered?</CbLabel>
                                            </Col>
                                            <Col sm={6}>
                                                <Button variant="secondary" type="button"
                                                    onClick={ () => { dispatch(navigateToPage("Login", {})) } }
                                                >Back to Login</Button>
                                            </Col>
                                        </Row>
                                       </Alert>
                                    </Container>
                                </Col>
                            </Row>
                        </Container>
                    </Col>
                </Row>
            </Container>
        </>
    )
}

export default Register
