export default {
    /*
    * The REST API actually runs on localhost:7000. However, to prevent the browser from blocking API requests due to CORS,
    * the 'create-react-app' server (on port 3000) is configured to proxy API requests to localhost:7000.
    * See The "proxy" setting in package.json.
    * Details:  https://www.telerik.com/blogs/dealing-with-cors-in-create-react-app
    */
    apiUrlRoot: "http://localhost:3000",
    apiPath: "/matt/hello",

    routesPrefix: "",
    apiAccessToken: ""
}
