import ReactDOM from "react-dom"
import HelloCodeBotApi from "./client/HelloCodeBotApi"
import App from "./App"

import "bootstrap/dist/css/bootstrap.css"
import "./index.css"
import "./resources/exo2.css"
import "./resources/main.css"
import "./resources/opensans.css"

HelloCodeBotApi.initialiseClient()

ReactDOM.render(
  <>
    <App />
  </>,
  document.getElementById('root')
)
