import React from 'react'
import { ConnectedRouter } from 'connected-react-router'
import { Provider, ReactReduxContext } from 'react-redux'
import { Route, Switch, Redirect, useLocation } from 'react-router-dom'
import store, { history } from './store'

import globalConsts from "./global_consts"

import Register from './pages/Register'
import Home from './pages/Home'
import Login from './pages/Login'

const pathPrefix = globalConsts.routesPrefix

const App: React.FC = () => (
  <Provider store={store} context={ReactReduxContext}>
    <ConnectedRouter history={history} context={ReactReduxContext}>
      <Switch>
        <Route exact path={["", "/", pathPrefix, pathPrefix + "/"]} render={
          () => <Redirect to={pathPrefix + "/Login"} />
        } />

        <Route exact path={["/Register", pathPrefix + "/Register"]} component={Register} />
        <Route exact path={["/Home", pathPrefix + "/Home"]} component={Home} />
        <Route exact path={["/Login", pathPrefix + "/Login"]} component={Login} />
        <Route path="*">
          <NoMatch />
        </Route>
      </Switch>
    </ConnectedRouter>
  </Provider>
)

function NoMatch() {
  let location = useLocation();
  console.log("No match for location: ", location)
  return (
    <div>
      <h2>No match for <code>{location.pathname}</code></h2>
      <h6>Routes prefix: {pathPrefix}</h6>
    </div>
  )
}

export default App
