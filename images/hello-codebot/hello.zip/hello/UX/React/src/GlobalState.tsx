
export class Session {
  public jwt: string
  public username: string

  constructor(jwt: string = "", username: string = "") {
    this.jwt = jwt
    this.username = username
  }
}

/*
 * This is a "temporary state scratchpad" of sorts that can be used by
 * custom functions, as a place to put things between function calls.
 *
 * NB This is just a "lightweight" global object, without state-change listeners etc.
 * Changing a value here won't trigger a re-render. If this is what you need, consider
 * using React's own state management (Redux or React Hooks).
 */
export class GlobalState {

  /*
   * If the page is reloaded, this local state disappears.
   * To store state more permanently: Define a domain class to hold the state, and access it via the generated REST API.
   */
  public static local: object = {}

  public static session: Session = new Session()
}
