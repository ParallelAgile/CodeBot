# Hello CodeBot - React web-app

This project consists of several integrated components, which are also available individually in this zipfile:

1. TypeScript domain classes (similar to Java "POJOs")
2. REST API client library, which uses the domain classes to create a domain-driven interface with the REST API
3. Redux state management library, for "domain state" (loading & saving data via the REST API client) and "UI state" (e.g. listbox selected item)
4. The React UI - pages, components

The React UI is a relatively thin layer, with the bulk of the code & application logic in the Redux state machines. The Redux code itself knows nothing about React (even the UI state code), so can be reused in other applications, including server-side.


# Set up the React project

1. Run `npm install` to create the node-modules directory with the required libraries.
2. Set up and run the accompanying REST API, available in ../../Server/expressjs/mongo.

This web-app is pre-configured to connect to the REST API at localhost:7000, though this can be changed in `global-consts.ts`.

We also recommend loading the web-app into an IDE such as VS Code, and exploring the code from there. The easiest way (with VS Code already installed) is to simply run, from this directory:

```bash
code .
```


# Run the web-app

From this directory, run:

```bash
npm start
```

This runs the app in development mode, and will automatically load the login page in the browser.

The page will reload if you make edits. You'll also see any lint errors in the console.


# Create a release build

From this directory, run:

```bash
npm run build
```

Builds the app for production to the `build` folder.<br />
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.<br />
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.


# Create React App

Our React templates were originally bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).
