class Video   
{
    // hash represents private class fields => https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Classes/Private_class_fields
    #id;
    #Name;
    #Url;

    constructor(Name, Url, id)
    {
       
        this.#id = id;
        this.#Name = Name;
        this.#Url = Url;
    }

    equals(o)
    {
        if (o === null) return false;

        if (o instanceof Video) {
            var other = o;
            return this.#id === other.id
                && this.#Name === other.Name
                && this.#Url === other.Url
            ;
        } else return false;
    }

    toString()
    {
        return ("id: " + this.#id + ", " +
                "Name: " + this.#Name + ", " +
                "Url: " + this.#Url + ", " +
            "").slice(0, -2);
    }

    toJSON(excludeId) {
        if (excludeId)
            
            return {
                        "Name": this.#Name,
                        "Url": this.#Url,
                }
            
        else
            
            return {
                    "id": this.#id,
                        "Name": this.#Name,
                        "Url": this.#Url,
                }
            
        }

    get id() {
        return this.#id;
    }

    set id(id) {
        this.#id = id;
    }

    isIdPresent()
    {
        return !(!this.#id || 0 === this.#id.length);
    }

  // need separate getters and setters for private class fields
  // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/set
  // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/get

    get Name()
    {
        return this.#Name;
    }

    set Name(Name)
    {
      this.#Name = Name;
    }
    get Url()
    {
        return this.#Url;
    }

    set Url(Url)
    {
      this.#Url = Url;
    }

}

export default Video;