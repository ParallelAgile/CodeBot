class User   
{
    // hash represents private class fields => https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Classes/Private_class_fields
    #id;
    #Username;
    #Password;
    #Email;
    #Roles;

    constructor(Username, Password, Email, Roles, id)
    {
       
        this.#id = id;
        this.#Username = Username;
        this.#Password = Password;
        this.#Email = Email;
        this.#Roles = Roles;
    }

    equals(o)
    {
        if (o === null) return false;

        if (o instanceof User) {
            var other = o;
            return this.#id === other.id
                && this.#Username === other.Username
                && this.#Password === other.Password
                && this.#Email === other.Email
                && this.#Roles === other.Roles
            ;
        } else return false;
    }

    toString()
    {
        return ("id: " + this.#id + ", " +
                "Username: " + this.#Username + ", " +
                "Password: " + this.#Password + ", " +
                "Email: " + this.#Email + ", " +
                "Roles: " + this.#Roles + ", " +
            "").slice(0, -2);
    }

    toJSON(excludeId) {
        if (excludeId)
            
            return {
                        "Username": this.#Username,
                        "Password": this.#Password,
                        "Email": this.#Email,
                        "Roles": this.#Roles,
                }
            
        else
            
            return {
                    "id": this.#id,
                        "Username": this.#Username,
                        "Password": this.#Password,
                        "Email": this.#Email,
                        "Roles": this.#Roles,
                }
            
        }

    get id() {
        return this.#id;
    }

    set id(id) {
        this.#id = id;
    }

    isIdPresent()
    {
        return !(!this.#id || 0 === this.#id.length);
    }

  // need separate getters and setters for private class fields
  // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/set
  // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/get

    get Username()
    {
        return this.#Username;
    }

    set Username(Username)
    {
      this.#Username = Username;
    }
    get Password()
    {
        return this.#Password;
    }

    set Password(Password)
    {
      this.#Password = Password;
    }
    get Email()
    {
        return this.#Email;
    }

    set Email(Email)
    {
      this.#Email = Email;
    }
    get Roles()
    {
        return this.#Roles;
    }

    set Roles(Roles)
    {
      this.#Roles = Roles;
    }

}

export default User;