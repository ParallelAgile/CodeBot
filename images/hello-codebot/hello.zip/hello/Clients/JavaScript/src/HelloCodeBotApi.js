import axios from 'axios';
import ApiResult from "./ApiResult.js";
import CreateManyResult from "./CreateManyResult.js";
import CreateResult from "./CreateResult.js";
import DeleteResult from "./DeleteResult.js";
import FindManyResult from "./FindManyResult.js";
import FindResult from "./FindResult.js";

import UserApi from "./api/UserApi.js";
import VideoApi from "./api/VideoApi.js";

class HelloCodeBotApi
{
    #url;

    #accessTokenProvided = false;
    #accessToken;

    #jwtEnabled = true;
    #jwtToken = undefined;
    #identityClassName = "User";

    constructor(url, accessToken) {
        this.#url = url
        this.#accessTokenProvided = Boolean(accessToken)
        if (this.#accessTokenProvided) {
            this.#accessToken = accessToken
        }
    }

    static clientForPaHosting(accessToken) {
        return new HelloCodeBotApi("https://ParallelAgile.net/hosted/matt/HelloCodeBotApi", accessToken)
    }

    /**
    * Connect to your API (in /Server folder) running locally.
    */
    static clientForLocalhost() {
        return new HelloCodeBotApi("http://localhost:7000/matt/hello", "");
    }

    static clientForUrl(url) {
        return new HelloCodeBotApi(url, "");
    }

    getAxiosConfig(hasJSONBodyInRequest) {
        if (hasJSONBodyInRequest) {
            if (this.#accessTokenProvided) {
                if (this.#jwtEnabled) {
                    return {
                        headers: {
                            'Content-Type': 'application/json',
                            'PaAccessToken': this.#accessToken,
                            'Authorization': `Bearer ${this.#jwtToken}`
                        }
                    }
                } else {
                    return {
                        headers: {
                            'Content-Type': 'application/json',
                            'PaAccessToken': this.#accessToken
                        }
                    }
                }
            } else {
                if (this.#jwtEnabled) {
                    return {
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${this.#jwtToken}`
                        }
                    }
                } else {
                    return {
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    }
                }
            }
        } else {
            if (this.#accessTokenProvided) {
                if (this.#jwtEnabled) {
                    return {
                        headers: {
                            'PaAccessToken': this.#accessToken,
                            'Authorization': `Bearer ${this.#jwtToken}`
                        }
                    }
                } else {
                    return {
                        headers: {
                            'PaAccessToken': this.#accessToken
                        }
                    }
                }
            } else {
                if (this.#jwtEnabled) {
                    return {
                        headers: {
                            'Authorization': `Bearer ${this.#jwtToken}`
                        }
                    }
                } else {
                    return {
                        headers: {}
                    }
                }
            }
        }
    }

    userApi = new UserApi(this)
    videoApi = new VideoApi(this)

    async login(username, password) {
        try {
            const response = await axios.post(this.#url + "/" + this.#identityClassName + "/login", { "username": username, "password": password }, this.getAxiosConfig(true));
            if (response.status == 200) {
                this.#jwtToken = response.data["jwt"]
                return true
            } else
                return false
        } catch (err) {
            console.log(err);
            return false
        }
    }

    async createOne(entity, className) {
        if (!Boolean(this.#jwtToken))
            return new CreateResult("Unauthorized...", "", 401)
        try {
            const response = await axios.post(this.#url + "/" + className, entity, this.getAxiosConfig(true));
            if (response.status === 200 || response.status === 201)
                return new CreateResult("", response.data.insertedIds[0], response.status)
            else
                return new CreateResult(response.data.message, "", response.status)
        } catch (err) {
            console.log(err);
            return new CreateResult(err.response.data.message +"\n"+err, "", err.response.status)
        }
    }

    async createMany(entities, className) {
        if (!Boolean(this.#jwtToken))
            return new CreateManyResult("Unauthorized...", "", 401)
        try {
            const response = await axios.post(this.#url + "/" + className, entities, this.getAxiosConfig(true))
            if (response.status === 200 || response.status === 201)
                return new CreateManyResult("", response.data.insertedIds, response.status)
            else
                return new CreateManyResult(response.data.message, "", response.status)
        } catch (err) {
            console.log(err);
            return new CreateManyResult(err.response.data.message +"\n"+err, "", err.response.status)
        }
    }

    async findOne(id, className) {
        if (!Boolean(this.#jwtToken))
            return new FindResult("Unauthorized...", "", 401)
        try {
            const response = await axios.get(this.#url + "/" + className + "/" + id, this.getAxiosConfig(false));
            if (response.status === 200)
                return new FindResult("", response.data, response.status)
            else
                return new FindResult(response.data.message, "", response.status)
        } catch (err) {
            console.log(err);
            return new FindResult(err.response.data.message +"\n"+err, "", err.response.status)
        }
    }

    async findAll(className) {
        if (!Boolean(this.#jwtToken))
            return new FindManyResult("Unauthorized...", "", 401)
        try {
            const response = await axios.get(this.#url + "/" + className, this.getAxiosConfig(false));
            if (response.status === 200)
                return new FindManyResult("", response.data, response.status)
            else
                return new FindManyResult(response.data.message, "", response.status)
        } catch (err) {
            console.log(err);
            return new FindManyResult(err.response.data.message +"\n"+err, "", err.response.status)
        }
    }

    async deleteOne(id, className) {
        if (!Boolean(this.#jwtToken))
            return new DeleteResult("Unauthorized...", "", 401)
        try {
            const response = await axios.delete(this.#url + "/" + className + "/" + id, this.getAxiosConfig(false))
            if (response.status === 200)
                return new DeleteResult("", response.data.deletedCount, response.status)
            else
                return new DeleteResult(response.data.message, 0, response.status)
        } catch (err) {
            console.log(err);
            return new DeleteResult(err.response.data.message +"\n"+err, "", err.response.status)
        }
    }

    async deleteAll(className) {
        if (!Boolean(this.#jwtToken))
            return new DeleteResult("Unauthorized...", "", 401)
        try {
            const response = await axios.delete(this.#url + "/" + className, this.getAxiosConfig(false))
            if (response.status === 200)
                return new DeleteResult("", response.data.deletedCount, response.status)
            else
                return new DeleteResult(response.data.message, 0, response.status)
        } catch (err) {
            console.log(err);
            return new DeleteResult(err.response.data.message +"\n"+err, "", err.response.status)
        }
    }

    async update(newEntity, id, className) {
        if (!Boolean(this.#jwtToken))
            return new CreateResult("Unauthorized...", "", 401)
        try {
            const response = await axios.put(this.#url + "/" + className + "/" + id, newEntity, this.getAxiosConfig(true))
            if (response.status === 200)
                return new CreateResult("", id, response.status)
            else
                return new CreateResult(response.data.message, "", response.status)
        } catch (err) {
            console.log(err);
            return new CreateResult(err.response.data.message +"\n"+err, "", err.response.status)
        }
    }

    async updateSelectiveAttributes(id, attributesToReplace, className) {
        if (!Boolean(this.#jwtToken))
            return new CreateManyResult("Unauthorized...", "", 401)
        try {
            const response = await axios.patch(this.#url + "/" + className + "/" + id, attributesToReplace, this.getAxiosConfig(true))
            if (response.status === 200 || response.status === 201)
                return new CreateResult("", id, response.status)
            else
                return new CreateResult(response.data.message, "", response.status)
        } catch (err) {
            console.log(err);
            return new CreateResult(err.response.data.message +"\n"+err, "", err.response.status)
        }
    }
}

export default HelloCodeBotApi