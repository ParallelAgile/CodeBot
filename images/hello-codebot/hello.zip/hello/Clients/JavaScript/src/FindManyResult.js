import ApiResult from "./ApiResult.js";

export default class FindManyResult extends ApiResult {
    #entities
    #errorMsg
    #statusCode

    constructor(errorMsg, entities, statusCode) {
        super();
        this.#errorMsg = errorMsg
        this.#entities = entities
        this.#statusCode = statusCode
    }

    get entities() {
        return this.#entities;
    }

    get errorMsg() {
        return this.#errorMsg
    }

    get statusCode() {
        return this.#statusCode
    }

    isOk() {
        return this.#entities.length > 0
    }

    toString() {
        let sc = this.#statusCode == 0 ? "" : this.#statusCode + " "
        if (super.isStringEmpty(this.#errorMsg)) {
            {
                if (this.#entities.length === 0) {
                    return sc
                }
                return sc + this.#entities.join(", ")
            }
            return sc + this.#errorMsg
        }
        return sc
    }
}