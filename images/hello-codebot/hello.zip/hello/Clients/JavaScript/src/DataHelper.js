import User from "./model/User.js"
import Video from "./model/Video.js"

class DataHelper
{
    static generate_random_string(length) {
        var result           = '';
        var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for ( let i = 0; i < length; i++ ) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    }

    static generate_random_float(min, max) {
        return Math.random() * (max - min) + min;
    }

    static generate_random_int(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    static generate_random_boolean() {
        return Math.random() < 0.5
    }

    static generate_random_date(start, end) {
        return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
    }

    static NewUser() {
        return new User(
        "hello " + this.generate_random_string(9),
        "hello " + this.generate_random_string(9),
        "hello " + this.generate_random_string(9),
        [],
        ""
        );
    }

    static NewUserList(num) {
        let items = [];
        for (let i = 0; i < num; i++) {
            items.push(this.NewUser());
        }
        return items;
    }


    static NewVideo() {
        return new Video(
        "hello " + this.generate_random_string(9),
        "hello " + this.generate_random_string(9),
        ""
        );
    }

    static NewVideoList(num) {
        let items = [];
        for (let i = 0; i < num; i++) {
            items.push(this.NewVideo());
        }
        return items;
    }


}

export default DataHelper