export default class ApiResult {
    isOk() {

    }
    isStringEmpty(str) {
        return (!str || 0 === str.length);
    }
}