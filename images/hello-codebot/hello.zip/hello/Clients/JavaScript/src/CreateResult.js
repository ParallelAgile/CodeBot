import ApiResult from "./ApiResult.js";

export default class CreateResult extends ApiResult {
    #id
    #errorMsg
    #statusCode

    constructor(errorMsg, id, statusCode) {
        super();
        this.#errorMsg = errorMsg
        this.#id = id
        this.#statusCode = statusCode
    }

    isOk() {
        return this.#statusCode === 200 || this.#statusCode === 201;
    }

    get id() {
        return this.#id
    }

    get statusCode() {
        return this.#statusCode
    }

    get errorMsg() {
        return this.#errorMsg
    }

    toString() {
        var sc = this.#statusCode == 0 ? "" : this.#statusCode + " "
        if (super.isStringEmpty(this.#errorMsg)) {
            if (this.isStringEmpty(this.#id)) {
                return sc
            }
            return sc + this.#id
        }
        return sc + this.#errorMsg
    }
}