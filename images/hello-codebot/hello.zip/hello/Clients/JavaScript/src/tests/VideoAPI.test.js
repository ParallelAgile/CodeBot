import HelloCodeBotApi from "../HelloCodeBotApi.js"
import CreateManyResult from "../CreateManyResult.js"
import CreateResult from "../CreateResult.js"
import DeleteResult from "../DeleteResult.js"
import FindManyResult from "../FindManyResult.js"
import FindResult from "../FindResult.js"
import DataHelper from "../DataHelper.js"

const api = HelloCodeBotApi.clientForLocalhost()

describe('JWT Test', () => {
	test('Login Test', async () => {
		const loginResult = await api.login("hello", "hellohello")
		expect(loginResult).toBe(true)
	})
})

describe('Single Video API Calls (Create -> Retrieve -> Update -> Delete)', () => {
    let video = DataHelper.NewVideo()

    test('Create one', async () => {
        const createResult = await api.videoApi.createOne(video.toJSON(true));
        expect(createResult.isOk()).toBe(true)
        expect(createResult.id).toBeTruthy()
        video["id"] = createResult.id
    });

    // Read the entity back by its database ID:
    test('Retrieve by DB ID', async () => {
        const findResult = await api.videoApi.findOne(video["id"])
        expect(findResult.isOk()).toBe(true)
    });

    // Updating string attributes of the entity
    test('Update', async () => {
        video.Name = "new Name";
        video.Url = "new Url";
        const updateResult = await api.videoApi.update(video)
        expect(updateResult.isOk()).toBe(true)
    });

    // Read the entity back after update:
    test('Retrieve and check updated values', async () => {
        const findResult = await api.videoApi.findOne(video["id"])
        expect(findResult.entity).toEqual(
            expect.objectContaining({
                "id": video["id"],
                "Name": "new Name",
                "Url": "new Url",
            }))
    });

    test('Update selective attributes', async () => {
        video.Name = "newer Name";
        video.Url = "newer Url";
        const updateResult = await api.videoApi.updateSelectiveAttributes(video["id"], {
            "Name": video["Name"],
            "Url": video["Url"],
        });
        expect(updateResult.isOk()).toBe(true)
    });

    // Read the entity back after selective attributes update:
    test('Retrieve and check updated values', async () => {
        const findResult = await api.videoApi.findOne(video["id"])
        expect(findResult.entity).toEqual(
            expect.objectContaining({
                "id": video["id"],
                "Name": "newer Name",
                "Url": "newer Url",
            }))
    });

    // Finally, delete the entity:
    test('Delete entity', async () => {
        const deleteResult = await api.videoApi.deleteOne(video["id"])
        expect(deleteResult.count).toBe(1)
    });
});

describe('Multiple Video in API Calls (CreateMany -> Retrieve -> DeleteMany)', () => {
    let createManyResult

    // Create Multiple entities
    test('Create many', async () => {
        let videos = DataHelper.NewVideoList(3);
        createManyResult = await api.videoApi.createMany(videos);
        expect(createManyResult.isOk()).toBe(true)
        for(let i=0;i<createManyResult.ids.length;i++)
            expect(createManyResult.ids[i]).toBeTruthy()
    });

    // Read multiple entities back
    test('Retrieve all entities', async () => {
        const findManyResult = await api.videoApi.findAll()
        expect(findManyResult.isOk()).toBe(true)
        expect(findManyResult.entities).toEqual(
            expect.arrayContaining([
                expect.objectContaining({ "id": createManyResult.ids[0] }),
                expect.objectContaining({ "id": createManyResult.ids[1] }),
                expect.objectContaining({ "id": createManyResult.ids[2] })
            ]))
    });

    // Finally, delete multiple entities:
    test('Delete all entities', async () => {
        const deleteResult = await api.videoApi.deleteAll()
        expect(deleteResult.count).toBeGreaterThanOrEqual(3)
    });
});