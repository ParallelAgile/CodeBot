import HelloCodeBotApi from "../HelloCodeBotApi.js"
import CreateManyResult from "../CreateManyResult.js"
import CreateResult from "../CreateResult.js"
import DeleteResult from "../DeleteResult.js"
import FindManyResult from "../FindManyResult.js"
import FindResult from "../FindResult.js"
import DataHelper from "../DataHelper.js"

/*
 * Some quick examples illustrating how to use the User JavaScript API.
 */
class UserExamples
{
    // Connect either to the cloud-hosted API (if it's deployed)...
    //#api = HelloCodeBotApi.ClientForPaHosting("accesstoken");

    // ... or to the API running on localhost:
    #api = HelloCodeBotApi.clientForLocalhost();


    async makeUserLogin() {
        // redirect to login page either in react/angular/vue etc
        // get credentials from user
        // call login() in the API like below
        const loginResult = await this.#api.login("hello", "hellohello")
        if (loginResult)
            console.log("\n       Login successful! JWT acquired")
        // check loginResult, if true, redo the earlier process which failed authorization
    }


    async createRetrieveUpdateDeleteSingleUser() {

        await this.makeUserLogin()

        let findManyResult = await this.#api.userApi.findAll();
        console.log("\n       Initial #rows in DB: " + findManyResult.entities.length)

        let user = DataHelper.NewUser();
        console.log("\n       POSTing to create User: " + user.toJSON(true))

        // Create the user via the API:
        let createResult = await this.#api.userApi.createOne(user.toJSON(true));

        if (createResult.isOk()) {
            user["id"]=createResult.id
            // Read the entity back by its database ID:
            let findResult = await this.#api.userApi.findOne(user["id"]);
            console.log("\n       Find one by DB ID: " + findResult.toString());

            if (findResult.isOk()) {
                findManyResult = await this.#api.userApi.findAll();
                console.log("\n       User rows in DB: " + findManyResult.entities.length);

                // Updating string attributes of the entity
                console.log("\n       Updating string attributes of the entity using PUT: ")
                user.Username = "new Username"
                user.Password = "new Password"
                user.Email = "new Email"
                console.log(user.toJSON(false))

                createResult = await this.#api.userApi.update(user);
                if (createResult.isOk()) {
                    // Read the entity back by its database ID:
                    findResult = await this.#api.userApi.findOne(user["id"]);
                    console.log("\n       Find result after update: " + findResult.toString());
                }

                // Updating selective attributes of the entity
                console.log("\n       Update selective attributes of entity using PATCH with following new attributes: ")
                user.Username = "newer Username"
                console.log("Username: "+user["Username"])
                user.Password = "newer Password"
                console.log("Password: "+user["Password"])
                user.Email = "newer Email"
                console.log("Email: "+user["Email"])
                createResult = await this.#api.userApi.updateSelectiveAttributes(user["id"], {
                "Username": user["Username"],
                "Password": user["Password"],
                "Email": user["Email"],
                });
                if (createResult.isOk()) {
                    // Read the entity back by its database ID:
                    findResult = await this.#api.userApi.findOne(user["id"]);
                    console.log("\n       Find result after updateSelectiveAttributes: " + findResult.toString());
                }

                // Finally, delete the entity:
                let deleteResult = await this.#api.userApi.deleteOne(user["id"]);
                console.log("\n       Delete result: " + deleteResult.count);
                findManyResult = await this.#api.userApi.findAll();
                console.log("\n       User rows in DB: " + findManyResult.entities.length);
            }
        }
    }

    async createRetrieveDeleteManyUser() {
        let findManyResult = await this.#api.userApi.findAll();
        console.log("\n       Initial #rows in DB: " + findManyResult.entities.length);

        let users = DataHelper.NewUserList(3);

        console.log("\n       POSTing to create following User(s): ")
        for (let i = 0; i < users.length; i++)
            console.log(users[i].toJSON(true))

        // Creating multiple userObjects via the API:
        let createManyResult = await this.#api.userApi.createMany(users);
        console.log("\n       Create many result: " + createManyResult);

        if (createManyResult.isOk()) {
            findManyResult = await this.#api.userApi.findAll();
            console.log("\n       Find result after createMany: " + findManyResult.entities);

            if (findManyResult.isOk()) {
                console.log("\n       User rows in DB: " + findManyResult.entities.length);

                // Finally, delete all the entities
                let deleteResult = await this.#api.userApi.deleteAll();
                console.log("\n       Delete result: " + deleteResult.count);
                findManyResult = await this.#api.userApi.findAll();
                console.log("\n       User rows in DB: " + findManyResult.entities.length);
            }
        }
    }
}

let example = new UserExamples()
await example.createRetrieveUpdateDeleteSingleUser()
console.log("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
await example.createRetrieveDeleteManyUser()

export default UserExamples;