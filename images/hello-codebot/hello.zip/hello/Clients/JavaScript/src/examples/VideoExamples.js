import HelloCodeBotApi from "../HelloCodeBotApi.js"
import CreateManyResult from "../CreateManyResult.js"
import CreateResult from "../CreateResult.js"
import DeleteResult from "../DeleteResult.js"
import FindManyResult from "../FindManyResult.js"
import FindResult from "../FindResult.js"
import DataHelper from "../DataHelper.js"

/*
 * Some quick examples illustrating how to use the Video JavaScript API.
 */
class VideoExamples
{
    // Connect either to the cloud-hosted API (if it's deployed)...
    //#api = HelloCodeBotApi.ClientForPaHosting("accesstoken");

    // ... or to the API running on localhost:
    #api = HelloCodeBotApi.clientForLocalhost();


    async makeUserLogin() {
        // redirect to login page either in react/angular/vue etc
        // get credentials from user
        // call login() in the API like below
        const loginResult = await this.#api.login("hello", "hellohello")
        if (loginResult)
            console.log("\n       Login successful! JWT acquired")
        // check loginResult, if true, redo the earlier process which failed authorization
    }


    async createRetrieveUpdateDeleteSingleVideo() {

        await this.makeUserLogin()

        let findManyResult = await this.#api.videoApi.findAll();
        console.log("\n       Initial #rows in DB: " + findManyResult.entities.length)

        let video = DataHelper.NewVideo();
        console.log("\n       POSTing to create Video: " + video.toJSON(true))

        // Create the video via the API:
        let createResult = await this.#api.videoApi.createOne(video.toJSON(true));

        if (createResult.isOk()) {
            video["id"]=createResult.id
            // Read the entity back by its database ID:
            let findResult = await this.#api.videoApi.findOne(video["id"]);
            console.log("\n       Find one by DB ID: " + findResult.toString());

            if (findResult.isOk()) {
                findManyResult = await this.#api.videoApi.findAll();
                console.log("\n       Video rows in DB: " + findManyResult.entities.length);

                // Updating string attributes of the entity
                console.log("\n       Updating string attributes of the entity using PUT: ")
                video.Name = "new Name"
                video.Url = "new Url"
                console.log(video.toJSON(false))

                createResult = await this.#api.videoApi.update(video);
                if (createResult.isOk()) {
                    // Read the entity back by its database ID:
                    findResult = await this.#api.videoApi.findOne(video["id"]);
                    console.log("\n       Find result after update: " + findResult.toString());
                }

                // Updating selective attributes of the entity
                console.log("\n       Update selective attributes of entity using PATCH with following new attributes: ")
                video.Name = "newer Name"
                console.log("Name: "+video["Name"])
                video.Url = "newer Url"
                console.log("Url: "+video["Url"])
                createResult = await this.#api.videoApi.updateSelectiveAttributes(video["id"], {
                "Name": video["Name"],
                "Url": video["Url"],
                });
                if (createResult.isOk()) {
                    // Read the entity back by its database ID:
                    findResult = await this.#api.videoApi.findOne(video["id"]);
                    console.log("\n       Find result after updateSelectiveAttributes: " + findResult.toString());
                }

                // Finally, delete the entity:
                let deleteResult = await this.#api.videoApi.deleteOne(video["id"]);
                console.log("\n       Delete result: " + deleteResult.count);
                findManyResult = await this.#api.videoApi.findAll();
                console.log("\n       Video rows in DB: " + findManyResult.entities.length);
            }
        }
    }

    async createRetrieveDeleteManyVideo() {
        let findManyResult = await this.#api.videoApi.findAll();
        console.log("\n       Initial #rows in DB: " + findManyResult.entities.length);

        let videos = DataHelper.NewVideoList(3);

        console.log("\n       POSTing to create following Video(s): ")
        for (let i = 0; i < videos.length; i++)
            console.log(videos[i].toJSON(true))

        // Creating multiple videoObjects via the API:
        let createManyResult = await this.#api.videoApi.createMany(videos);
        console.log("\n       Create many result: " + createManyResult);

        if (createManyResult.isOk()) {
            findManyResult = await this.#api.videoApi.findAll();
            console.log("\n       Find result after createMany: " + findManyResult.entities);

            if (findManyResult.isOk()) {
                console.log("\n       Video rows in DB: " + findManyResult.entities.length);

                // Finally, delete all the entities
                let deleteResult = await this.#api.videoApi.deleteAll();
                console.log("\n       Delete result: " + deleteResult.count);
                findManyResult = await this.#api.videoApi.findAll();
                console.log("\n       Video rows in DB: " + findManyResult.entities.length);
            }
        }
    }
}

let example = new VideoExamples()
await example.createRetrieveUpdateDeleteSingleVideo()
console.log("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
await example.createRetrieveDeleteManyVideo()

export default VideoExamples;