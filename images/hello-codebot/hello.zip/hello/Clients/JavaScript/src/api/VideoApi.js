export class VideoApi
{
    #HelloCodeBotApi

    constructor(api) {
        this.#HelloCodeBotApi = api;
    }

    deleteAll() {
        return this.#HelloCodeBotApi.deleteAll("Video");
    }

    deleteOne(videoId) {
        return this.#HelloCodeBotApi.deleteOne(videoId, "Video");
    }

    createOne(video) {
        return this.#HelloCodeBotApi.createOne(video, "Video");
    }

    createMany(entities) {
        return this.#HelloCodeBotApi.createMany(entities, "Video");
    }

    update(video) {
        return this.#HelloCodeBotApi.update(video.toJSON(false), video.id, "Video");
    }

    updateSelectiveAttributes(videoId, newVideo) {
        return this.#HelloCodeBotApi.updateSelectiveAttributes(videoId, newVideo, "Video");
    }

    findOne(id) {
        return this.#HelloCodeBotApi.findOne(id, "Video");
    }

    findAll() {
        return this.#HelloCodeBotApi.findAll("Video");
    }
}

export default VideoApi