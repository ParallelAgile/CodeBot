export class UserApi
{
    #HelloCodeBotApi

    constructor(api) {
        this.#HelloCodeBotApi = api;
    }

    deleteAll() {
        return this.#HelloCodeBotApi.deleteAll("User");
    }

    deleteOne(userId) {
        return this.#HelloCodeBotApi.deleteOne(userId, "User");
    }

    createOne(user) {
        return this.#HelloCodeBotApi.createOne(user, "User");
    }

    createMany(entities) {
        return this.#HelloCodeBotApi.createMany(entities, "User");
    }

    update(user) {
        return this.#HelloCodeBotApi.update(user.toJSON(false), user.id, "User");
    }

    updateSelectiveAttributes(userId, newUser) {
        return this.#HelloCodeBotApi.updateSelectiveAttributes(userId, newUser, "User");
    }

    findOne(id) {
        return this.#HelloCodeBotApi.findOne(id, "User");
    }

    findAll() {
        return this.#HelloCodeBotApi.findAll("User");
    }
}

export default UserApi