import ApiResult from "./ApiResult.js";

export default class DeleteResult extends ApiResult {
    #count
    #errorMsg
    #statusCode

    constructor(errorMsg, count, statusCode) {
        super()
        this.#errorMsg = errorMsg
        this.#count = count
        this.#statusCode = statusCode
    }

    isOk() {
        return this.#count > 0
    }

    get count() {
        return this.#count
    }

    get errorMsg() {
        return this.#errorMsg
    }

    get statusCode() {
        return this.#statusCode
    }

    toString() {
        let sc = this.#statusCode == 0 ? "" : this.#statusCode + " "
        if (super.isStringEmpty(this.#errorMsg)) {
            if (this.#count === 0) {
                return sc + "Deleted count not returned"
            }
            return sc + "Deleted rows: " + this.#count
        }
        return sc + this.#errorMsg
    }
}