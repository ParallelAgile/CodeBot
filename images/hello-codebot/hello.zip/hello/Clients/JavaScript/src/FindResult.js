import ApiResult from "./ApiResult.js";

class FindResult extends ApiResult {
    #entity
    #errorMsg
    #statusCode

    constructor(errorMsg, entity, statusCode) {
        super()
        this.#errorMsg = errorMsg
        this.#entity = entity
        this.#statusCode = statusCode
    }

    isOk() {
        return Object.keys(this.#entity).length > 0
    }

    get entity() {
        return this.#entity
    }

    get errorMsg() {
        return this.#errorMsg
    }

    get statusCode() {
        return this.#statusCode
    }

    toString() {
        let sc = this.#statusCode == 0 ? "" : this.#statusCode + " "
        if (super.isStringEmpty(this.#errorMsg)) {
            {
                if (Object.keys(this.#entity).length === 0) {
                    return sc
                }
                return sc + JSON.stringify(this.#entity, null, 2)
            }
            return sc + this.#errorMsg
        }
        return sc
    }
}

export default FindResult;