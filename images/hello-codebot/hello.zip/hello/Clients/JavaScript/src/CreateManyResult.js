import ApiResult from "./ApiResult.js";

export default class CreateManyResult extends ApiResult {
    #ids
    #errorMsg
    #statusCode

    constructor(errorMsg, ids, statusCode) {
        super()
        this.#errorMsg = errorMsg
        this.#ids = ids
        this.#statusCode = statusCode
    }

    isOk() {
        return this.#ids.length > 0
    }

    get ids() {
        return this.#ids
    }

    get errorMsg() {
        return this.#errorMsg
    }

    get statusCode() {
        return this.#statusCode
    }

    toString() {
        let sc = this.#statusCode == 0 ? "" : this.#statusCode + " "
        if (super.isStringEmpty(this.#errorMsg)) {
            if (this.#ids.length === 0) {
                return sc
            }
            return sc + "Created IDs: " + this.#ids.join(",")
        }
        return sc + this.#errorMsg
    }
}