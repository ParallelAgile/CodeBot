#!/bin/bash

# This script builds both the Java domain classes and the Java API client,
# and installs them to your local Maven repository.

set -e

YOUR_HOME=~

cd ../../DomainClasses/Java
mvn install -Dmaven.repo.local=$YOUR_HOME/.m2/repository

cd ../../Client/Java
mvn install -Dmaven.repo.local=$YOUR_HOME/.m2/repository

# If you're using WSL, this copies the built jars to your Windows Maven repo:
if uname -a | grep -q '^Linux.*Microsoft'; then
    cp -r ~/.m2/repository/mattco/hello /mnt/c/Users/{your username}/.m2/repository/mattco/
fi
