package mattco.hello.api.examples;

import mattco.hello.api.HelloCodeBotApi;
import mattco.hello.api.HelloCodeBotApi.CreateResult;
import mattco.hello.api.HelloCodeBotApi.CreateManyResult;
import mattco.hello.api.HelloCodeBotApi.DeleteResult;
import mattco.hello.api.HelloCodeBotApi.FindResult;
import static mattco.hello.api.examples.ExampleDataHelper.*;
import mattco.hello.model.Video;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Some quick examples illustrating how to use the Video Java API.
 */
public class VideoExamples {

    // Connect either to the cloud-hosted API (if it's deployed)...
    private static final HelloCodeBotApi api = HelloCodeBotApi.clientForPaHosting();

    // ... or to the API running on localhost:
    //private static final HelloCodeBotApi api = HelloCodeBotApi.clientForLocalhost();

    public static void main(String[] args) {
        VideoExamples example = new VideoExamples();
        example.createAndRetrieveSingleVideo();
        example.createMany();
    }

    public void createAndRetrieveSingleVideo() {

        // Has no ID allocated yet:
        Video videoToCreate = newVideo();

        // Create the video via the API:
        CreateResult createResult = api.video.create(videoToCreate);
        System.out.println("Create result: " + createResult);

        createResult.id.ifPresent(createdId -> {
            // Read the video back by its database ID:
            FindResult<Video> findResult = api.video.findOne(createdId);
            System.out.println("Find result: " + findResult);

            findResult.entity.ifPresent(video -> {
                System.out.println("Video rows in the database (expecting at least 1): " + count());

                // Finally, delete the video:
                DeleteResult deleteResult = api.video.delete(video);
                System.out.println("Delete result: " + deleteResult);
                System.out.println("Video rows in the database: " + count());
            });
        });
    }

    public void createMany() {
        List<Video> entities = new ArrayList<>();
        entities.add(newVideo());
        entities.add(newVideo());
        entities.add(newVideo());

        CreateManyResult createManyResult = api.video.createMany(entities);
        System.out.println("Create many result: " + createManyResult);
    }

    public int count() {
        return api.video.findAll().entities.orElse(new ArrayList<>()).size();
    }
}
