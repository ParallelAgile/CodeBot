package mattco.hello.api.domain;

import mattco.hello.api.HelloCodeBotApi;
import mattco.hello.model.Video;
import kong.unirest.HttpResponse;
import kong.unirest.Unirest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * A domain-specific API client.
 * Access this class via HelloCodeBotApi.video.
 */
public class VideoApi {

  private static final Logger logger = LoggerFactory.getLogger(VideoApi.class);
  private final HelloCodeBotApi api;

  /**
   * Rather than calling this directly, use the HelloCodeBotApi.video reference.
   */
  public VideoApi(HelloCodeBotApi api) {
    this.api = api;
  }

  public HelloCodeBotApi.DeleteResult deleteAll() {
    return api.deleteAll(Video.class);
  }

  public HelloCodeBotApi.DeleteResult delete(Video video) {
    return api.delete(video.getId(), Video.class);
  }

  public HelloCodeBotApi.DeleteResult delete(String videoId) {
    return api.delete(videoId, Video.class);
  }

  public HelloCodeBotApi.CreateResult create(Video video) {
    return api.create(video, Video.class);
  }

  public HelloCodeBotApi.CreateManyResult createMany(List<Video> entities) {
    return api.createMany(entities, Video.class);
  }

  public HelloCodeBotApi.CreateResult replace(Video video) {
    return api.replace(video, Video.class);
  }

  public HelloCodeBotApi.FindResult<Video> findOne(String id) {
    return api.findOne(id, Video.class);
  }

  public HelloCodeBotApi.FindManyResult<Video> findAll() {
    return findMany(new HashMap<>());
  }

  /**
   * Use snake_case for the attribute names.
   */
  public HelloCodeBotApi.FindManyResult<Video> findMany(Map<String, Object> attrs) {
    try {
      HttpResponse<Video[]> response =
          Unirest
              .get(api.url + "/Video/")
              .queryString(attrs)
              .headers(api.customHttpHeaders)
              .asObject(Video[].class);
      return api.toFindManyResult(response);
    } catch (Exception e) {
      logger.error("Error finding Video domain entity", e);
      return new HelloCodeBotApi.FindManyResult<>(Optional.of("Error calling the API: " + e.getMessage()), Optional.empty(), 0);
    }
  }
}
