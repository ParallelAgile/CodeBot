package mattco.hello.api.examples;

import mattco.hello.api.HelloCodeBotApi;
import mattco.hello.api.HelloCodeBotApi.CreateResult;
import mattco.hello.api.HelloCodeBotApi.CreateManyResult;
import mattco.hello.api.HelloCodeBotApi.DeleteResult;
import mattco.hello.api.HelloCodeBotApi.FindResult;
import static mattco.hello.api.examples.ExampleDataHelper.*;
import mattco.hello.model.User;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Some quick examples illustrating how to use the User Java API.
 */
public class UserExamples {

    // Connect either to the cloud-hosted API (if it's deployed)...
    private static final HelloCodeBotApi api = HelloCodeBotApi.clientForPaHosting();

    // ... or to the API running on localhost:
    //private static final HelloCodeBotApi api = HelloCodeBotApi.clientForLocalhost();

    public static void main(String[] args) {
        UserExamples example = new UserExamples();
        example.createAndRetrieveSingleUser();
        example.createMany();
    }

    public void createAndRetrieveSingleUser() {

        // Has no ID allocated yet:
        User userToCreate = newUser();

        // Create the user via the API:
        CreateResult createResult = api.user.create(userToCreate);
        System.out.println("Create result: " + createResult);

        createResult.id.ifPresent(createdId -> {
            // Read the user back by its database ID:
            FindResult<User> findResult = api.user.findOne(createdId);
            System.out.println("Find result: " + findResult);

            findResult.entity.ifPresent(user -> {
                System.out.println("User rows in the database (expecting at least 1): " + count());

                // Finally, delete the user:
                DeleteResult deleteResult = api.user.delete(user);
                System.out.println("Delete result: " + deleteResult);
                System.out.println("User rows in the database: " + count());
            });
        });
    }

    public void createMany() {
        List<User> entities = new ArrayList<>();
        entities.add(newUser());
        entities.add(newUser());
        entities.add(newUser());

        CreateManyResult createManyResult = api.user.createMany(entities);
        System.out.println("Create many result: " + createManyResult);
    }

    public int count() {
        return api.user.findAll().entities.orElse(new ArrayList<>()).size();
    }
}
