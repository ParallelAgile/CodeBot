package mattco.hello.api.examples;

import mattco.hello.model.*;

import java.math.BigDecimal;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;
import java.util.List;
import java.util.Random;

public class ExampleDataHelper {

    public static Random random = new Random();
    public static int maxNestedObjects = 20;

    public static User newUser() {
        return new User(
            "Username " + Long.toHexString(Double.doubleToLongBits(random.nextDouble())),
            "Password " + Long.toHexString(Double.doubleToLongBits(random.nextDouble())),
            "Email " + Long.toHexString(Double.doubleToLongBits(random.nextDouble())),
            new ArrayList<>(Arrays.asList("Roles " + Long.toHexString(Double.doubleToLongBits(random.nextDouble())), "Roles " + Long.toHexString(Double.doubleToLongBits(random.nextDouble()))))
        );
    }

    public static List<User> newUserList(int num) {
        List<User> items = new ArrayList<>(num);
        for (int i = 0; i < num; i++) {
            items.add(newUser());
        }
        return items;
    }

    public static Video newVideo() {
        return new Video(
            "Name " + Long.toHexString(Double.doubleToLongBits(random.nextDouble())),
            "Url " + Long.toHexString(Double.doubleToLongBits(random.nextDouble()))
        );
    }

    public static List<Video> newVideoList(int num) {
        List<Video> items = new ArrayList<>(num);
        for (int i = 0; i < num; i++) {
            items.add(newVideo());
        }
        return items;
    }

}
