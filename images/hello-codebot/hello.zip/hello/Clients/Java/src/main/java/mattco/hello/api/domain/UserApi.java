package mattco.hello.api.domain;

import mattco.hello.api.HelloCodeBotApi;
import mattco.hello.model.User;
import kong.unirest.HttpResponse;
import kong.unirest.Unirest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * A domain-specific API client.
 * Access this class via HelloCodeBotApi.user.
 */
public class UserApi {

  private static final Logger logger = LoggerFactory.getLogger(UserApi.class);
  private final HelloCodeBotApi api;

  /**
   * Rather than calling this directly, use the HelloCodeBotApi.user reference.
   */
  public UserApi(HelloCodeBotApi api) {
    this.api = api;
  }

  public HelloCodeBotApi.DeleteResult deleteAll() {
    return api.deleteAll(User.class);
  }

  public HelloCodeBotApi.DeleteResult delete(User user) {
    return api.delete(user.getId(), User.class);
  }

  public HelloCodeBotApi.DeleteResult delete(String userId) {
    return api.delete(userId, User.class);
  }

  public HelloCodeBotApi.CreateResult create(User user) {
    return api.create(user, User.class);
  }

  public HelloCodeBotApi.CreateManyResult createMany(List<User> entities) {
    return api.createMany(entities, User.class);
  }

  public HelloCodeBotApi.CreateResult replace(User user) {
    return api.replace(user, User.class);
  }

  public HelloCodeBotApi.FindResult<User> findOne(String id) {
    return api.findOne(id, User.class);
  }

  public HelloCodeBotApi.FindManyResult<User> findAll() {
    return findMany(new HashMap<>());
  }

  /**
   * Use snake_case for the attribute names.
   */
  public HelloCodeBotApi.FindManyResult<User> findMany(Map<String, Object> attrs) {
    try {
      HttpResponse<User[]> response =
          Unirest
              .get(api.url + "/User/")
              .queryString(attrs)
              .headers(api.customHttpHeaders)
              .asObject(User[].class);
      return api.toFindManyResult(response);
    } catch (Exception e) {
      logger.error("Error finding User domain entity", e);
      return new HelloCodeBotApi.FindManyResult<>(Optional.of("Error calling the API: " + e.getMessage()), Optional.empty(), 0);
    }
  }
}
