package mattco.hello.api;

import mattco.hello.api.domain.*;
import mattco.hello.model.*; // requires the HelloCodeBot domain model Java library dependency (also generated).
import com.parallelagile.model.DomainObject;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import kong.unirest.gson.GsonObjectMapper;
import kong.unirest.json.JSONArray;
import kong.unirest.json.JSONObject;
import kong.unirest.Unirest;
import kong.unirest.JsonNode;
import kong.unirest.HttpResponse;
import kong.unirest.UnirestException;
import kong.unirest.UnirestParsingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Hello CodeBot REST API client.
 * Only one instance of this class should be created for your application.
 */
public class HelloCodeBotApi {

    // Replace with the latest access token (expires every 24 hours), retrieved from the CodeBot web console:
    private static final String paAccessToken = "63e7788b-83c7-4ab6-b2a8-7e7928b925ab";

    public static HelloCodeBotApi clientForPaHosting() {
        return new HelloCodeBotApi("https://ParallelAgile.net/hosted/matt/hello") {
            @Override
            protected void applyConfig() {
                Unirest.config()
                        .setDefaultHeader("PaAccessToken", paAccessToken);
            }
        };
    }

    /**
     * Connect to your API (in /Server folder) running locally.
     */
    public static HelloCodeBotApi clientForLocalhost() {
        return new HelloCodeBotApi("http://localhost:7000/matt/hello");
    }

    public static HelloCodeBotApi clientForUrl(String url) {
        return new HelloCodeBotApi(url);
    }

    private static final Logger logger = LoggerFactory.getLogger(HelloCodeBotApi.class);

    public final Map<String, String> customHttpHeaders = new HashMap<>();
    public final String url;

    /**
     * All top-level (non-nested) domain classes.
     */
    private List<Class> allDomainClasses = new ArrayList<>();

    private HelloCodeBotApi(String url) {
      this.url = url;
      applyDefaultConfig();
      registerDomainClasses();
    }

    private void registerDomainClasses() {
        // all top-level (non-nested) domain classes.
        allDomainClasses.add(User.class);
        allDomainClasses.add(Video.class);
    }

    public final UserApi user = new UserApi(this);
    public final VideoApi video = new VideoApi(this);

    private void applyDefaultConfig() {
        Unirest.config()
            .setDefaultHeader("Accept", "application/json")
            .setDefaultHeader("Content-Type", "application/json");

        applyConfig();
        applyObjectMapper();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            logger.info("Shutting down Unirest HTTP client...");
            Unirest.shutDown();
        }));
    }

    /**
     * Override this in your application to customize the HTTP config,
     * e.g. configure a proxy server or a client certificate store.
     * <p>
     * For a full set of options, see: https://github.com/Kong/unirest-java#configuration
     */
    protected void applyConfig() {
    }

    /**
     * If you want to set a different object mapper (e.g. Jackson),
     * override this method from your own separate codebase.
     */
    protected void applyObjectMapper() {
        Unirest.config().setObjectMapper(new GsonObjectMapper());
    }

    public <T extends DomainObject> DeleteResult delete(String id, Class<T> ofClass) {
        try {
            HttpResponse<JsonNode> response =
                Unirest
                    .delete(url + "/" + ofClass.getSimpleName() + "/" + id)
                    .headers(customHttpHeaders)
                    .asJson();
            return toDeleteResult(response);
        } catch (UnirestException e) {
            logger.error("Error deleting " + ofClass.getSimpleName() + " domain entity with id " + id, e);
            return new DeleteResult(Optional.of("Error calling the API: " + e.getMessage()), Optional.empty(), 0);
        }
    }

    /**
     * Deletes all data in the table/collection represented by ofClass.
     */
    public <T extends DomainObject> DeleteResult deleteAll(Class<T> ofClass) {
        try {
            HttpResponse<JsonNode> response =
                Unirest
                    .delete(url + "/" + ofClass.getSimpleName() + "/")
                    .headers(customHttpHeaders)
                    .asJson();
            return toDeleteResult(response);
        } catch (UnirestException e) {
            logger.error("Error deleting all " + ofClass.getSimpleName() + " domain entities", e);
            return new DeleteResult(Optional.of("Error calling the API: " + e.getMessage()), Optional.empty(), 0);
        }
    }

    public <T extends DomainObject> DeleteResult deleteMany(Map<String, Object> attrs, Class<T> ofClass) {
        try {
            HttpResponse<JsonNode> response =
                Unirest
                    .delete(url + "/" + ofClass.getSimpleName() + "/")
                    .headers(customHttpHeaders)
                    .body(attrs)
                    .asJson();
            return toDeleteResult(response);
        } catch (UnirestException e) {
            logger.error("Error deleting some " + ofClass.getSimpleName() + " domain entities", e);
            return new DeleteResult(Optional.of("Error calling the API: " + e.getMessage()), Optional.empty(), 0);
        }
    }

    private DeleteResult toDeleteResult(HttpResponse<JsonNode> response) {
        switch (response.getStatus()) {
            case 200:
                if (response.getParsingError().isPresent()) {
                    UnirestParsingException err = response.getParsingError().get();
                    logger.error("Error parsing delete response", err);
                    return new DeleteResult(Optional.of("Error parsing delete response"), Optional.empty(), response.getStatus());
                }

                JsonObject js = JsonParser.parseString(response.getBody().toString()).getAsJsonObject();
                Long deletedCount = js.get("deletedCount").getAsLong();
                return new DeleteResult(Optional.empty(), Optional.of(deletedCount), response.getStatus());

            default:
                String errMsg = errorMessageFrom(response);
                return new DeleteResult(Optional.of(errMsg), Optional.empty(), response.getStatus());
        }
    }

    public <T> CreateResult create(DomainObject entity, Class<T> ofClass) {
        try {
            HttpResponse<JsonNode> response =
                Unirest
                    .post(url + "/" + ofClass.getSimpleName() + "/")
                    .headers(customHttpHeaders)
                    .body(entity).asJson();

            switch (response.getStatus()) {
                case 200:
                case 201:
                    String id = idFrom(response);
                    return new CreateResult(Optional.empty(), Optional.of(id), response.getStatus());

                default:
                    String errMsg = errorMessageFrom(response);
                    return new CreateResult(Optional.of(errMsg), Optional.empty(), response.getStatus());
          }

        } catch (UnirestException e) {
            logger.error("Error creating " + ofClass.getSimpleName() + " domain entity", e);
            return new CreateResult(Optional.of("Error calling the API: " + e.getMessage()), Optional.empty(), 0);
        }
    }

    public <T extends DomainObject> CreateManyResult createMany(List<T> entities, Class<T> ofClass) {
        try {
            HttpResponse<JsonNode> response =
                Unirest
                    .post(url + "/" + ofClass.getSimpleName() + "/")
                    .headers(customHttpHeaders)
                    .body(entities).asJson();

            switch (response.getStatus()) {
                case 200:
                case 201:
                  List<String> ids = idsFrom(response);
                  return new CreateManyResult(Optional.empty(), Optional.of(ids), response.getStatus());

                default:
                  String errMsg = errorMessageFrom(response);
                  return new CreateManyResult(Optional.of(errMsg), Optional.empty(), response.getStatus());
            }

        } catch (UnirestException e) {
            logger.error("Error creating " + ofClass.getSimpleName() + " domain entities", e);
            return new CreateManyResult(Optional.of("Error calling the API: " + e.getMessage()), Optional.empty(), 0);
        }
    }

    public <T> CreateResult replace(DomainObject entity, Class<T> ofClass) {
        try {
            HttpResponse<JsonNode> response =
                Unirest
                    .put(url + "/" + ofClass.getSimpleName() + "/" + entity.getId())
                    .headers(customHttpHeaders)
                    .body(entity).asJson();

            switch (response.getStatus()) {
                case 200:
                  if (response.getParsingError().isPresent()) {
                      UnirestParsingException err = response.getParsingError().get();
                      logger.error("Error parsing replace response", err);
                      return new CreateResult(Optional.of("Error parsing replace response"), Optional.empty(), response.getStatus());
                  }
                  return new CreateResult(Optional.empty(), Optional.of(entity.getId()), response.getStatus());

               default:
                  String errMsg = errorMessageFrom(response);
                  return new CreateResult(Optional.of(errMsg), Optional.empty(), response.getStatus());
            }

        } catch (UnirestException e) {
            logger.error("Error replacing " + ofClass.getSimpleName() + " domain entity", e);
            return new CreateResult(Optional.of("Error calling the API: " + e.getMessage()), Optional.empty(), 0);
        }
    }

    public <T extends DomainObject> FindResult<T> findOne(String id, Class<T> ofClass) {
        try {
            HttpResponse<T> response =
                    Unirest
                            .get(url + "/" + ofClass.getSimpleName() + "/" + id)
                            .headers(customHttpHeaders)
                            .asObject(ofClass);

            return mapResponseBody(response);

        } catch (Exception e) {
            logger.error("Error finding " + ofClass.getSimpleName() + " domain entity", e);
            return new FindResult<>(Optional.of("Error calling the API: " + e.getMessage()), Optional.empty(), 0);
        }
    }

    private <T extends DomainObject> FindResult<T> mapResponseBody(HttpResponse<T> response) {
        try {
            T entity = response.getBody();
            if (entity == null) {
                return new FindResult<>(Optional.of("Empty response body."), Optional.empty(), response.getStatus());
            } else {
                return new FindResult<>(Optional.empty(), Optional.of(entity), response.getStatus());
            }
        } catch (UnirestParsingException e) {
            JsonObject jsErr = JsonParser.parseString(e.getOriginalBody()).getAsJsonObject();
            String errMsg = jsErr.get("message").getAsString();
            return new FindResult<>(Optional.of(errMsg), Optional.empty(), response.getStatus());
        }
    }

    public <T extends DomainObject> FindManyResult<T> toFindManyResult(HttpResponse<T[]> response) {
        switch (response.getStatus()) {
            case 200:
                if (response.getParsingError().isPresent()) {
                    UnirestParsingException err = response.getParsingError().get();
                    logger.error("Error parsing findMany response", err);
                    return new FindManyResult<>(Optional.of("Error parsing findMany response"), Optional.empty(), response.getStatus());
                }

                T[] ents = response.getBody();
                return new FindManyResult<>(Optional.empty(), Optional.of(Arrays.asList(ents)), 200);

            default:
                return new FindManyResult<>(Optional.of("Error fetching findMany result"), Optional.empty(), response.getStatus());
        }
    }


    public <T extends DomainObject> FindManyResult<T> findMany(Map<String, Object> attrs, Class<T> ofClass) {
        try {
            HttpResponse<JsonNode> response =
                    Unirest
                            .get(url + "/" + ofClass.getSimpleName() + "/")
                            .queryString(attrs)
                            .headers(customHttpHeaders)
                            .asJson();

            switch (response.getStatus()) {
                case 200:
                    JSONArray arr = response.getBody().getArray();
                    for (int i = 0, len = arr.length(); i < len; i++) {
                        JSONObject o = arr.getJSONObject(i);
                        System.out.println(o);

                    }
                    // TODO etc...

                    return new FindManyResult<>(Optional.empty(), Optional.empty(), 0);


                default:
                    return new FindManyResult<>(Optional.of(errorMessageFrom(response)), Optional.empty(), response.getStatus());
            }

        } catch (Exception e) {
            logger.error("Error finding " + ofClass.getSimpleName() + " domain entities", e);
            return new FindManyResult<>(Optional.of("Error calling the API: " + e.getMessage()), Optional.empty(), 0);
        }
    }

    private String idFrom(HttpResponse<JsonNode> response) {
        JsonObject js = JsonParser.parseString(response.getBody().toString()).getAsJsonObject();
        JsonArray arr = js.getAsJsonArray("insertedIds");
        return arr.get(0).getAsString();
    }

    private List<String> idsFrom(HttpResponse<JsonNode> response) {
        JsonObject js = JsonParser.parseString(response.getBody().toString()).getAsJsonObject();
        JsonArray jsonIds = js.getAsJsonArray("insertedIds");
        List<String> ids = new ArrayList<>();
        for (JsonElement jsonId : jsonIds) {
            ids.add(jsonId.getAsString());
        }
        return ids;
    }

    private String errorMessageFrom(HttpResponse<JsonNode> response) {
        return errorMessageFrom(response.getBody().toString());
    }

    private String errorMessageFrom(String responseBody) {
        JsonObject js = JsonParser.parseString(responseBody).getAsJsonObject();
        JsonElement el = js.get("message");
        return el == null ? "(no error message)" : el.getAsString();
    }


    /**
     * This is a convenience method for unit tests.
     * In normal use, the Api class shuts down Unirest via a JVM shutdown hook.
     */
    public void shutdown() {
        try {
            Unirest.shutDown();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public interface ApiResult<T> {
        boolean isOk();

        default boolean notOk() {
            return !isOk();
        }
    }

    public static class DeleteResult implements ApiResult {
        public final Optional<String> errorMsg;
        public final Optional<Long> deletedCount;
        public final int statusCode;

        private DeleteResult(Optional<String> errorMsg, Optional<Long> deletedCount, int statusCode) {
            this.errorMsg = errorMsg;
            this.deletedCount = deletedCount;
            this.statusCode = statusCode;
        }

        public boolean isOk() {
            return deletedCount.isPresent();
        }

        public String toString() {
            String sc = statusCode == 0 ? "" : "Status: " + statusCode + ", ";
            return sc + errorMsg.orElse(deletedCount.map(d -> "Deleted rows: " + d).orElse("Deleted count not returned"));
        }
    }

    /**
     * This will contain either the newly created record ID or an error message.
     * In case of an error, statusCode will be either 400 or 500 indicating either
     * a client-side error (e.g. invalid data) or a server-side error.
     */
    public static class CreateResult implements ApiResult {
        public final Optional<String> id;
        public final Optional<String> errorMsg;
        public final int statusCode;

        private CreateResult(Optional<String> errorMsg, Optional<String> id, int statusCode) {
            this.errorMsg = errorMsg;
            this.id = id;
            this.statusCode = statusCode;
        }

        public boolean isOk() {
            return id.isPresent();
        }

        public String toString() {
            String sc = statusCode == 0 ? "" : statusCode + " ";
            return sc + errorMsg.orElse(id.orElse(""));
        }
    }

    public static class CreateManyResult implements ApiResult {
        public final Optional<List<String>> ids;
        public final Optional<String> errorMsg;
        public final int statusCode;

        private CreateManyResult(Optional<String> errorMsg, Optional<List<String>> ids, int statusCode) {
            this.errorMsg = errorMsg;
            this.ids = ids;
            this.statusCode = statusCode;
        }

        public boolean isOk() {
            return ids.isPresent();
        }

        public String toString() {
            String sc = statusCode == 0 ? "" : statusCode + " ";
            return sc + errorMsg.orElse(ids.map(i -> "Created IDs: " + String.join(", ", i)).orElse(""));
        }
    }

    public static class FindResult<T extends DomainObject> implements ApiResult {
        public final Optional<T> entity;
        public final Optional<String> errorMsg;
        public final int statusCode;

        private FindResult(Optional<String> errorMsg, Optional<T> entity, int statusCode) {
            this.errorMsg = errorMsg;
            this.entity = entity;
            this.statusCode = statusCode;
        }

        public boolean isOk() {
            return entity.isPresent();
        }

        public String toString() {
            String sc = statusCode == 0 ? "" : statusCode + " ";
            return sc + errorMsg.orElse(entity.map(DomainObject::toString).orElse("no entity returned"));
        }
    }

    public static class FindManyResult<T extends DomainObject> implements ApiResult<T> {
        public final Optional<List<T>> entities;
        public final Optional<String> errorMsg;
        public final int statusCode;

        public FindManyResult(Optional<String> errorMsg, Optional<List<T>> entities, int statusCode) {
            this.entities = entities;
            this.errorMsg = errorMsg;
            this.statusCode = statusCode;
        }

        public boolean isOk() {
            return entities.isPresent();
        }

        public String toString() {
            String sc = statusCode == 0 ? "" : statusCode + " ";
            return sc + errorMsg.orElse(entities.map(ents -> String.join("\n", ents.toString())).orElse("no entities returned"));
        }
    }
}
