import { action } from "typesafe-actions";

import store from "../../../../store";

import { InformUser } from "../../../../InformUser"
import { SendingStatus } from "../../../domain"

import Video from "../../../../model/Video"
import { clearLoadingVideoItemsStatus } from "../../../domain/video/actions"
import { selectCreatingVideo } from "../../../domain/video/selectors"
import { selectLoadingAllVideoItems } from "../../../domain/video/selectors"
import { ITEM_SELECTED } from "./ActionTypes"
import { selectHome_ChooseAVideo_ChosenItem } from "./selectors"


// Action creators for the ChooseAVideo ComboBox:

export const chooseAVideoItemSelected = (selectedItem: Video | null) =>
    action(ITEM_SELECTED, { selectedItem })



// Listen for state changes affecting this component:

store.subscribe(() => {
    const state = store.getState();


    const loadingVideoItems = selectLoadingAllVideoItems(state)

    if (loadingVideoItems.status === SendingStatus.Failure) {
        clearLoadingVideoItemsStatus(store.dispatch);
        InformUser.error(loadingVideoItems.errorMsg);
    } else if (loadingVideoItems.status === SendingStatus.Success) {
        clearLoadingVideoItemsStatus(store.dispatch);
    }

    // Listen for result of any Video being created via this app, and auto-select it in the ComboBox:
    const creatingVideo = selectCreatingVideo(state);
    if (creatingVideo.status === SendingStatus.Success && creatingVideo.item && selectHome_ChooseAVideo_ChosenItem(state) !== creatingVideo.item) {
        store.dispatch(chooseAVideoItemSelected(creatingVideo.item))
    }
});
