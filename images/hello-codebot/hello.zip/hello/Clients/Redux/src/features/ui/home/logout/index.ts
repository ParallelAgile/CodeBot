import * as home_Logout_actions from './actions';
import home_Logout_reducer from './reducer';

/**
 * UI state and events for the Logout Button in the Home page.
 */
export {
  home_Logout_actions,
  home_Logout_reducer
}
