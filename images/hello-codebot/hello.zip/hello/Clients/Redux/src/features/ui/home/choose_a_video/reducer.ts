import { combineReducers } from "redux";
import { ActionType } from "typesafe-actions";

import * as actions from "./actions";
import { ITEM_SELECTED } from "./ActionTypes";
import Video from "../../../../model/Video";


type State = {
    readonly selected: {readonly item: Video | null};
}

type Action = ActionType<typeof actions>;

export default combineReducers<State, Action>({
    /**
     * Global "selected item" state for Choose a video in the Home page.
     */
    selected: (state = { item: null }, action) => {
        // The actions here are exported from ./actions.ts, and types from ./ActionTypes.ts:
        switch (action.type) {
            case ITEM_SELECTED:
                return {
                    item: action.payload.selectedItem
                }

            default:
                return state;
        }
    }
});
