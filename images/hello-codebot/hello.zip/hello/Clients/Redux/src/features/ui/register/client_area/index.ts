import * as register_ClientArea_actions from './actions';
import register_ClientArea_reducer from './reducer';

/**
 * UI state and events for the Client area Container in the Register page.
 */
export {
  register_ClientArea_actions,
  register_ClientArea_reducer
}
