import { combineReducers } from "redux";
import { ActionType } from "typesafe-actions";

import * as actions from "./actions";
import { SEND_REGISTER, FORM_CHANGED, FORM_CLEARED } from "./ActionTypes";
import User from "../../../../model/User";


type State = {
    readonly item: User;
}

type Action = ActionType<typeof actions>;

export default combineReducers<State, Action>({
    /**
     * Global "register new credentials" state for Client area in the Register page.
     */
    item: (state = new User(), action) => {
        // The actions here are exported from ./actions.ts, and types from ./ActionTypes.ts:
        switch (action.type) {
            case FORM_CHANGED:
                const newState = {
                    ...state
                };
                newState[action.payload.fieldName] = action.payload.value;
                return newState;

            case FORM_CLEARED:
                return action.payload.emptyItem;

            default:
                return state;
        }
    }
});
