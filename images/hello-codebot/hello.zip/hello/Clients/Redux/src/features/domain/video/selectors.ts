import { AppState } from "../../../store";
import { SendingStatus } from ".."
import {VideoState, VideoItemsState } from "./reducer"
import Video from "../../../model/Video";

export const selectLoadingAllVideoItems: (state: AppState) => VideoItemsState = (state: AppState) => state.domain.loadingVideoItems;
export const selectLoadingAllVideoItemsStatus: (state: AppState) => SendingStatus = (state: AppState) => state.domain.loadingVideoItems.status;
export const selectAllVideoItems: (state: AppState) => Video[] = (state: AppState) => state.domain.loadingVideoItems.items;

export const selectCreatingVideo: (state: AppState) => VideoState = (state: AppState) => state.domain.creatingVideo;
export const selectCreatingVideoStatus: (state: AppState) => SendingStatus = (state: AppState) => state.domain.creatingVideo.status;

export const selectDeletingVideo: (state: AppState) => VideoState = (state: AppState) => state.domain.deletingVideo;
export const selectDeletingVideoStatus: (state: AppState) => SendingStatus = (state: AppState) => state.domain.deletingVideo.status;
