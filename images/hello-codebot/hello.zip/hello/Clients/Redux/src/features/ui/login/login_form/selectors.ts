import { AppState } from "../../../../store";

import { UserLogin } from "../../../../model/User"

// These selectors retrieve data from the 'ui' state.

export const selectLogin_LoginForm_LoginForm: (s: AppState) => UserLogin = (state: AppState) =>
    state.ui.login_LoginForm.item;

