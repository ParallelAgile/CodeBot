import {
    LoadVideoItemsActionTypes,
    LOAD_VIDEO_ITEMS_IDLE,
    LOAD_VIDEO_ITEMS_START,
    LOAD_VIDEO_ITEMS_SUCCESS,
    LOAD_VIDEO_ITEMS_FAILURE,

    CreateVideoActionTypes,
    CREATE_VIDEO_IDLE,
    CREATE_VIDEO_START,
    CREATE_VIDEO_SUCCESS,
    CREATE_VIDEO_FAILURE,

    DeleteVideoActionTypes,
    DELETE_VIDEO_IDLE,
    DELETE_VIDEO_START,
    DELETE_VIDEO_SUCCESS,
    DELETE_VIDEO_FAILURE
} from "./actions";

import Video from "../../../model/Video";
import { ApiDirective } from "../../../client/ApiResult";
import { SendingStatus } from ".."


export interface VideoState {
    status: SendingStatus;
    item: Video | null;
    directive: ApiDirective;
    errorMsg: string;
}

export interface VideoItemsState {
    status: SendingStatus;
    items: Video[];
    errorMsg: string;
}


//--------------------------------------------------------------------------
// Loading Video items:

const defaultLoadingVideoItemsState: VideoItemsState = {
    status: SendingStatus.Idle,
    items: [],
    errorMsg: ""
};

export const loadingVideoItemsReducer = (state = defaultLoadingVideoItemsState, action: LoadVideoItemsActionTypes): VideoItemsState => {
    switch (action.type) {
        case LOAD_VIDEO_ITEMS_IDLE:
            return { status: SendingStatus.Idle, items: action.items, errorMsg: "" };

        case LOAD_VIDEO_ITEMS_START:
            return { status: SendingStatus.InProgress, items: [], errorMsg: "" };

        case LOAD_VIDEO_ITEMS_SUCCESS:
            return { status: SendingStatus.Success, items: action.items, errorMsg: "" };

        case LOAD_VIDEO_ITEMS_FAILURE:
            return { status: SendingStatus.Failure, items: [], errorMsg: action.errorMsg };

        default:
            return state;
    }
};

// Creating Video: -------------------------------------------------

const defaultCreatingVideoState: VideoState = {
    status: SendingStatus.Idle,
    item: new Video(),
    errorMsg: "",
    directive: {}
};

export const creatingVideoReducer = (
    state = defaultCreatingVideoState,
    action: CreateVideoActionTypes
): VideoState => {
    switch (action.type) {
        case CREATE_VIDEO_IDLE:
            return { status: SendingStatus.Idle, item: new Video(), errorMsg: "", directive: {} };

        case CREATE_VIDEO_START:
            return { status: SendingStatus.InProgress, item: state.item, errorMsg: "", directive: {} };

        case CREATE_VIDEO_SUCCESS:
            return { status: SendingStatus.Success, item: action.item, errorMsg: "", directive: action.directive };

        case CREATE_VIDEO_FAILURE:
            return {
                status: SendingStatus.Failure,
                item: state.item,
                errorMsg: action.errorMsg,
                directive: action.directive
            };

        default:
            return state;
    }
};


// Deleting Video: -------------------------------------------------------

const defaultDeletingVideoState: VideoState = {
  status: SendingStatus.Idle,
  item: null,
  errorMsg: "",
  directive: {}
};

export const deletingVideoReducer = (
  state = defaultDeletingVideoState,
  action: DeleteVideoActionTypes
): VideoState => {
  switch (action.type) {
      case DELETE_VIDEO_IDLE:
          return { status: SendingStatus.Idle, item: new Video(), errorMsg: "", directive: {} };

      case DELETE_VIDEO_START:
          return { status: SendingStatus.InProgress, item: state.item, errorMsg: "", directive: {} };

      case DELETE_VIDEO_SUCCESS:
          return { status: SendingStatus.Success, item: action.item, errorMsg: "", directive: action.directive };

      case DELETE_VIDEO_FAILURE:
          return {
              status: SendingStatus.Failure,
              item: state.item,
              errorMsg: action.errorMsg,
              directive: action.directive
          };

      default:
          return state;
  }
};

