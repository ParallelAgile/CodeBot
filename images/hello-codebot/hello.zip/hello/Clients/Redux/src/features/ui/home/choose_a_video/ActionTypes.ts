/**
 * invoked when the user clicks an item
 */
export const ITEM_SELECTED = "home/choose_a_video/ITEM_SELECTED"

