import { Dispatch } from "redux";
import store from "../../../store";

import { CreateItemAsync, DeleteItemAsync, LoadItemAsync, LoadItemsAsync, SendingStatus } from "..";
import {
    selectRegisteringUserStatus,
    selectDeletingUserStatus,
    selectCreatingUserStatus,
    selectLoadingAllUserItems
} from "./selectors"

import { ApiDirective } from "../../../client/ApiResult"
import HelloCodeBotApi from "../../../client/HelloCodeBotApi";

import User, { UserLogin } from "../../../model/User";

// action types:

export const LOGIN_IDLE = "domain_user/LOGIN_IDLE";
export const LOGIN_START = "domain_user/LOGIN_START";
export const LOGIN_SUCCESS = "domain_user/LOGIN_SUCCESS";
export const LOGIN_FAILURE = "domain_user/LOGIN_FAILURE";

export const REGISTER_USER_IDLE = "domain_user/REGISTER_IDLE";
export const REGISTER_USER_START = "domain_user/REGISTER_START";
export const REGISTER_USER_SUCCESS = "domain_user/REGISTER_SUCCESS";
export const REGISTER_USER_FAILURE = "domain_user/REGISTER_FAILURE";

export const LOAD_USER_IDLE = "domain_user/LOAD_IDLE";
export const LOAD_USER_START = "domain_user/LOAD_START";
export const LOAD_USER_SUCCESS = "domain_user/LOAD_SUCCESS";
export const LOAD_USER_FAILURE = "domain_user/LOAD_FAILURE";

export const LOAD_USER_ITEMS_IDLE = "domain_user_items/LOAD_ITEMS_IDLE";
export const LOAD_USER_ITEMS_START = "domain_user_items/LOAD_ITEMS_START";
export const LOAD_USER_ITEMS_SUCCESS = "domain_user_items/LOAD_ITEMS_SUCCESS";
export const LOAD_USER_ITEMS_FAILURE = "domain_user_items/LOAD_ITEMS_FAILURE";

export const CREATE_USER_IDLE = "domain_user/CREATE_IDLE";
export const CREATE_USER_START = "domain_user/CREATE_START";
export const CREATE_USER_SUCCESS = "domain_user/CREATE_SUCCESS";
export const CREATE_USER_FAILURE = "domain_user/CREATE_FAILURE";

export const DELETE_USER_IDLE = "domain_user_items/DELETE_IDLE";
export const DELETE_USER_START = "domain_user_items/DELETE_START";
export const DELETE_USER_SUCCESS = "domain_user_items/DELETE_SUCCESS";
export const DELETE_USER_FAILURE = "domain_user_items/DELETE_FAILURE";

interface LoginIdle extends LoadItemAsync<User> {
    type: typeof LOGIN_IDLE;
}
interface LoginStart extends LoadItemAsync<User> {
    type: typeof LOGIN_START;
}
interface LoginSuccess extends LoadItemAsync<User> {
    type: typeof LOGIN_SUCCESS;
}
interface LoginFailure extends LoadItemAsync<User> {
    type: typeof LOGIN_FAILURE;
}

interface RegisterUserIdle extends CreateItemAsync<User> {
    type: typeof REGISTER_USER_IDLE;
}
interface RegisterUserStart extends CreateItemAsync<User> {
    type: typeof REGISTER_USER_START;
}
interface RegisterUserSuccess extends CreateItemAsync<User> {
    type: typeof REGISTER_USER_SUCCESS;
}
interface RegisterUserFailure extends CreateItemAsync<User> {
    type: typeof REGISTER_USER_FAILURE;
}

interface LoadUserIdle extends LoadItemAsync<User> {
    type: typeof LOAD_USER_IDLE;
}
interface LoadUserStart extends LoadItemAsync<User> {
    type: typeof LOAD_USER_START;
}
interface LoadUserSuccess extends LoadItemAsync<User> {
    type: typeof LOAD_USER_SUCCESS;
}
interface LoadUserFailure extends LoadItemAsync<User> {
    type: typeof LOAD_USER_FAILURE;
}

interface LoadUserItemsIdle extends LoadItemsAsync<User> {
    type: typeof LOAD_USER_ITEMS_IDLE;
}
interface LoadUserItemsStart extends LoadItemsAsync<User> {
    type: typeof LOAD_USER_ITEMS_START;
}
interface LoadUserItemsSuccess extends LoadItemsAsync<User> {
    type: typeof LOAD_USER_ITEMS_SUCCESS;
}
interface LoadUserItemsFailure extends LoadItemsAsync<User> {
    type: typeof LOAD_USER_ITEMS_FAILURE;
}

interface CreateUserIdle extends CreateItemAsync<User> {
    type: typeof CREATE_USER_IDLE;
}
interface CreateUserStart extends CreateItemAsync<User> {
    type: typeof CREATE_USER_START;
}
interface CreateUserSuccess extends CreateItemAsync<User> {
    type: typeof CREATE_USER_SUCCESS;
}
interface CreateUserFailure extends CreateItemAsync<User> {
    type: typeof CREATE_USER_FAILURE;
}

interface DeleteUserIdle extends DeleteItemAsync<User> {
    type: typeof DELETE_USER_IDLE;
}
interface DeleteUserStart extends DeleteItemAsync<User> {
    type: typeof DELETE_USER_START;
}
interface DeleteUserSuccess extends DeleteItemAsync<User> {
    type: typeof DELETE_USER_SUCCESS;
}
interface DeleteUserFailure extends DeleteItemAsync<User> {
    type: typeof DELETE_USER_FAILURE;
}


export type UserLoginActionTypes = LoginIdle | LoginStart | LoginSuccess | LoginFailure;
export type RegisterUserActionTypes = RegisterUserIdle | RegisterUserStart | RegisterUserSuccess | RegisterUserFailure;
export type UserActionTypes =  LoadUserIdle | LoadUserStart | LoadUserSuccess | LoadUserFailure;
export type LoadUserItemsActionTypes = LoadUserItemsIdle | LoadUserItemsStart | LoadUserItemsSuccess | LoadUserItemsFailure;
export type CreateUserActionTypes = CreateUserIdle | CreateUserStart | CreateUserSuccess | CreateUserFailure;
export type DeleteUserActionTypes = DeleteUserIdle | DeleteUserStart | DeleteUserSuccess | DeleteUserFailure;


// actions:

// Logging in: -------------------------------------------------------

const loginIdle = (): UserLoginActionTypes => ({
    type: LOGIN_IDLE,
    loading: false,
    item: null,
    errorMsg: "",
    directive: {}
});
const loginStart = (): UserLoginActionTypes => ({
    type: LOGIN_START,
    loading: true,
    item: null,
    errorMsg: "",
    directive: {}
});
const loginSuccess = (item: User, directive: ApiDirective): UserLoginActionTypes => ({
    type: LOGIN_SUCCESS,
    loading: false,
    item: item,
    errorMsg: "",
    directive: directive
});
const loginFailure = (errorMsg: string, directive: ApiDirective): UserLoginActionTypes => ({
    type: LOGIN_FAILURE,
    loading: false,
    item: null,
    errorMsg: errorMsg,
    directive: {}
});

/**
 * No longer logging in. The UI can call this to clear the result once it's notified the user.
 */
export const clearLoginStatus = () => (dispatch: Dispatch<UserLoginActionTypes>) => {
  dispatch (loginIdle())
};

/**
 * Load the User from the REST API.
 */
export const login = (credentials: UserLogin, onSuccess: (user: User) => void) => (dispatch: Dispatch<UserLoginActionTypes>) => {
  dispatch(loginStart());

    HelloCodeBotApi.client.login(credentials).then((result) => {
        if (result.isOk && result.item) {
          onSuccess(result.item)
          dispatch(loginSuccess(result.item, result.directive));
        } else {
          dispatch(loginFailure(result.message || "There was a problem logging you in, please try again.", {}));
        }
    });
};


// Registering User: -------------------------------------------------------

const registerUserIdle = (): RegisterUserActionTypes => ({
    type: REGISTER_USER_IDLE,
    creating: false,
    item: null,
    errorMsg: "",
    directive: {}
});
const registerUserStart = (item: User): RegisterUserActionTypes => ({
    type: REGISTER_USER_START,
    creating: true,
    item: item,
    errorMsg: "",
    directive: {}
});
const registerUserSuccess = (itemWithId: User, directive: ApiDirective): RegisterUserActionTypes => ({
    type: REGISTER_USER_SUCCESS,
    creating: false,
    item: itemWithId,
    errorMsg: "",
    directive: directive
});
const registerUserFailure = (errorMsg: string, originalItem: User, directive: ApiDirective): RegisterUserActionTypes => ({
    type: REGISTER_USER_FAILURE,
    creating: false,
    item: originalItem,
    errorMsg: errorMsg,
    directive: directive
});

/**
 * Register the User via the REST API.
 */
export const registerUser = (item: User) => (dispatch: Dispatch<any>) => {
    dispatch(registerUserStart(item));

    return HelloCodeBotApi.client.userApi.registerUser(item).then((result) => {
        if (result.isOk && result.newItem) {
            dispatch(registerUserSuccess(result.newItem, result.directive));
        } else {
            dispatch(registerUserFailure(result.message, item, result.directive));
        }
    });
};

/**
 * No longer registering a User. The UI can call this to clear the result once it's notified the user.
 */
export const clearRegisteringUserStatus = () => (dispatch: Dispatch<RegisterUserActionTypes>) => {
    if (selectRegisteringUserStatus(store.getState()) !== SendingStatus.Idle) {
        dispatch(registerUserIdle());
    }
};


// Loading User items: -------------------------------------------------------

const loadUserItemsIdle = (items: User[] = []): LoadUserItemsActionTypes => ({
    type: LOAD_USER_ITEMS_IDLE,
    loading: false,
    items: items,
    errorMsg: "",
    directive: {}
});
const loadUserItemsStart = (): LoadUserItemsActionTypes => ({
    type: LOAD_USER_ITEMS_START,
    loading: true,
    items: [],
    errorMsg: "",
    directive: {}
});
const loadUserItemsSuccess = (items: User[], directive: ApiDirective): LoadUserItemsActionTypes => ({
    type: LOAD_USER_ITEMS_SUCCESS,
    loading: false,
    items: items,
    errorMsg: "",
    directive: directive
});
const loadUserItemsFailure = (errorMsg: string, directive: ApiDirective): LoadUserItemsActionTypes => ({
    type: LOAD_USER_ITEMS_FAILURE,
    loading: false,
    items: [],
    errorMsg: errorMsg,
    directive: directive
});

/**
 * No longer loading User items. The UI can call this to clear the result once it's notified the user.
 */
export const clearLoadingUserItemsStatus = (dispatch: Dispatch<LoadUserItemsActionTypes>) => {
  const loading = selectLoadingAllUserItems(store.getState());
  if (loading.status !== SendingStatus.Idle) {
      dispatch(loadUserItemsIdle(loading.items));
  }
};

/**
 * Load the User items from the REST API.
 */
export const requestUserItems = (dispatch: Dispatch<LoadUserItemsActionTypes>) => {
    dispatch(loadUserItemsStart());
    return HelloCodeBotApi.client.userApi.findAll().then((result) => {
        if (result.isOk) {
            dispatch(loadUserItemsSuccess(result.items, result.directive));
        } else {
            console.log("Error loading  user items: " + result.message);
            dispatch(loadUserItemsFailure(result.message, result.directive));
        }
    });
};


// Creating User: -------------------------------------------------------

const createUserIdle = (): CreateUserActionTypes => ({
    type: CREATE_USER_IDLE,
    creating: false,
    item: null,
    errorMsg: "",
    directive: {}
});
const createUserStart = (item: User): CreateUserActionTypes => ({
    type: CREATE_USER_START,
    creating: true,
    item: item,
    errorMsg: "",
    directive: {}
});
const createUserSuccess = (itemWithId: User, directive: ApiDirective): CreateUserActionTypes => ({
    type: CREATE_USER_SUCCESS,
    creating: false,
    item: itemWithId,
    errorMsg: "",
    directive: directive
});
const createUserFailure = (errorMsg: string, originalItem: User, directive: ApiDirective): CreateUserActionTypes => ({
    type: CREATE_USER_FAILURE,
    creating: false,
    item: originalItem,
    errorMsg: errorMsg,
    directive: directive
});

/**
 * Create the User via the REST API.
 */
export const createUser = (item: User) => (dispatch: Dispatch<any>) => {
    dispatch(createUserStart(item));

    return HelloCodeBotApi.client.userApi.createOne(item).then((result) => {
        if (result.isOk && result.newItem) {
            dispatch(createUserSuccess(result.newItem, result.directive));
            dispatch(requestUserItems) // reload the User items so ListBoxes etc are updated
        } else {
            dispatch(createUserFailure(result.message, item, result.directive));
        }
    });
};

/**
 * No longer creating a User. The UI can call this to clear the result once it's notified the user.
 */
export const clearCreatingUserStatus = () => (dispatch: Dispatch<CreateUserActionTypes>) => {
    if (selectCreatingUserStatus(store.getState()) !== SendingStatus.Idle) {
        dispatch(createUserIdle());
    }
};


// Delete User: -------------------------------------------------------

export const deleteUserIdle = (): DeleteUserActionTypes => ({
    type: DELETE_USER_IDLE,
    deleting: false,
    item: null,
    errorMsg: "",
    directive: {}
});
export const deleteUserStart = (item: User): DeleteUserActionTypes => ({
    type: DELETE_USER_START,
    deleting: true,
    item: item,
    errorMsg: "",
    directive: {}
});
export const deleteUserSuccess = (itemWithId: User, directive: ApiDirective): DeleteUserActionTypes => ({
    type: DELETE_USER_SUCCESS,
    deleting: false,
    item: itemWithId,
    errorMsg: "",
    directive: directive
});
export const deleteUserFailure = (errorMsg: string, originalItem: User, directive: ApiDirective): DeleteUserActionTypes => ({
    type: DELETE_USER_FAILURE,
    deleting: false,
    item: originalItem,
    errorMsg: errorMsg,
    directive: directive
});

/**
 * No longer deleting a User. The UI can call this to clear the result once it's notified the user.
 */
export const clearDeletingUserStatus = () => (dispatch: Dispatch<DeleteUserActionTypes>) => {
  if (selectDeletingUserStatus(store.getState()) !== SendingStatus.Idle) {
      dispatch(deleteUserIdle());
  }
};

/**
 * Delete the User via the REST API.
 */
export const deleteUser = (item: User) => (dispatch: Dispatch<any>) => {
    dispatch(deleteUserStart(item));

    return HelloCodeBotApi.client.userApi.deleteOne(item.id).then((result) => {
        if (result.isOk) {
            dispatch(deleteUserSuccess(item, result.directive));
            dispatch(requestUserItems)
        } else {
            dispatch(deleteUserFailure(result.message, item, result.directive));
        }
    });
};
