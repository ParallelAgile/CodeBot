import * as home_ChooseAVideo_actions from './actions';
import home_ChooseAVideo_reducer from './reducer';

/**
 * UI state and events for the Choose a video ComboBox in the Home page.
 */
export {
  home_ChooseAVideo_actions,
  home_ChooseAVideo_reducer
}
