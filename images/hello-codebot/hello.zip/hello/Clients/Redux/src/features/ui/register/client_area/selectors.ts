import { AppState } from "../../../../store";

import User from "../../../../model/User"

// These selectors retrieve data from the 'ui' state.

export const selectRegister_ClientArea_RegisterForm: (s: AppState) => User = (state: AppState) =>
    state.ui.register_ClientArea.item;

