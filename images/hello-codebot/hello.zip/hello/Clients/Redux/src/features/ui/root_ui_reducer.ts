import { combineReducers } from "redux";

import home_ChooseAVideo_Reducer from "./home/choose_a_video/reducer";
import home_Logout_Reducer from "./home/logout/reducer";
import login_LoginForm_Reducer from "./login/login_form/reducer";
import register_ClientArea_Reducer from "./register/client_area/reducer";

const createRootUiReducer = () =>
    combineReducers({

        // Global state for components that fire actions, e.g. item selected, button clicked,
        // which other components can then react to.

        home_ChooseAVideo: home_ChooseAVideo_Reducer,
        home_Logout: home_Logout_Reducer,
        login_LoginForm: login_LoginForm_Reducer,
        register_ClientArea: register_ClientArea_Reducer

    });
export default createRootUiReducer;
