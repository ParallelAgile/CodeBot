import {
    UserLoginActionTypes,
    LOGIN_IDLE,
    LOGIN_START,
    LOGIN_SUCCESS,
    LOGIN_FAILURE,

    RegisterUserActionTypes,
    REGISTER_USER_IDLE,
    REGISTER_USER_START,
    REGISTER_USER_SUCCESS,
    REGISTER_USER_FAILURE,

    LoadUserItemsActionTypes,
    LOAD_USER_ITEMS_IDLE,
    LOAD_USER_ITEMS_START,
    LOAD_USER_ITEMS_SUCCESS,
    LOAD_USER_ITEMS_FAILURE,

    CreateUserActionTypes,
    CREATE_USER_IDLE,
    CREATE_USER_START,
    CREATE_USER_SUCCESS,
    CREATE_USER_FAILURE,

    DeleteUserActionTypes,
    DELETE_USER_IDLE,
    DELETE_USER_START,
    DELETE_USER_SUCCESS,
    DELETE_USER_FAILURE
} from "./actions";

import User from "../../../model/User";
import { ApiDirective } from "../../../client/ApiResult";
import { SendingStatus } from ".."


export interface UserState {
    status: SendingStatus;
    item: User | null;
    directive: ApiDirective;
    errorMsg: string;
}

export interface UserItemsState {
    status: SendingStatus;
    items: User[];
    errorMsg: string;
}


// Logging in: -------------------------------------------

const defaultLoggingInState: UserState = {
    status: SendingStatus.Idle,
    item: null,
    errorMsg: "",
    directive: {}
};

export const loggingInReducer = (state = defaultLoggingInState, action: UserLoginActionTypes): UserState => {
    switch (action.type) {
        case LOGIN_IDLE:
            return { status: SendingStatus.Idle, item: null, errorMsg: "", directive: {} };

        case LOGIN_START:
            return { status: SendingStatus.InProgress, item: null, errorMsg: "", directive: {} };

        case LOGIN_SUCCESS:
            return { status: SendingStatus.Success, item: action.item, errorMsg: "", directive: action.directive };

        case LOGIN_FAILURE:
            return { status: SendingStatus.Failure, item: null, errorMsg: action.errorMsg, directive: action.directive };

        default:
            return state;
    }
};


// Registering User: -------------------------------------------------

const defaultRegisteringUserState: UserState = {
    status: SendingStatus.Idle,
    item: new User(),
    errorMsg: "",
    directive: {}
};

export const registeringUserReducer = (
    state = defaultRegisteringUserState,
    action: RegisterUserActionTypes
): UserState => {
    switch (action.type) {
        case REGISTER_USER_IDLE:
            return { status: SendingStatus.Idle, item: new User(), errorMsg: "", directive: {} };

        case REGISTER_USER_START:
            return { status: SendingStatus.InProgress, item: state.item, errorMsg: "", directive: {} };

        case REGISTER_USER_SUCCESS:
            return { status: SendingStatus.Success, item: action.item, errorMsg: "", directive: action.directive };

        case REGISTER_USER_FAILURE:
            return {
                status: SendingStatus.Failure,
                item: state.item,
                errorMsg: action.errorMsg,
                directive: action.directive
            };

        default:
            return state;
    }
};


//--------------------------------------------------------------------------
// Loading User items:

const defaultLoadingUserItemsState: UserItemsState = {
    status: SendingStatus.Idle,
    items: [],
    errorMsg: ""
};

export const loadingUserItemsReducer = (state = defaultLoadingUserItemsState, action: LoadUserItemsActionTypes): UserItemsState => {
    switch (action.type) {
        case LOAD_USER_ITEMS_IDLE:
            return { status: SendingStatus.Idle, items: action.items, errorMsg: "" };

        case LOAD_USER_ITEMS_START:
            return { status: SendingStatus.InProgress, items: [], errorMsg: "" };

        case LOAD_USER_ITEMS_SUCCESS:
            return { status: SendingStatus.Success, items: action.items, errorMsg: "" };

        case LOAD_USER_ITEMS_FAILURE:
            return { status: SendingStatus.Failure, items: [], errorMsg: action.errorMsg };

        default:
            return state;
    }
};

// Creating User: -------------------------------------------------

const defaultCreatingUserState: UserState = {
    status: SendingStatus.Idle,
    item: new User(),
    errorMsg: "",
    directive: {}
};

export const creatingUserReducer = (
    state = defaultCreatingUserState,
    action: CreateUserActionTypes
): UserState => {
    switch (action.type) {
        case CREATE_USER_IDLE:
            return { status: SendingStatus.Idle, item: new User(), errorMsg: "", directive: {} };

        case CREATE_USER_START:
            return { status: SendingStatus.InProgress, item: state.item, errorMsg: "", directive: {} };

        case CREATE_USER_SUCCESS:
            return { status: SendingStatus.Success, item: action.item, errorMsg: "", directive: action.directive };

        case CREATE_USER_FAILURE:
            return {
                status: SendingStatus.Failure,
                item: state.item,
                errorMsg: action.errorMsg,
                directive: action.directive
            };

        default:
            return state;
    }
};


// Deleting User: -------------------------------------------------------

const defaultDeletingUserState: UserState = {
  status: SendingStatus.Idle,
  item: null,
  errorMsg: "",
  directive: {}
};

export const deletingUserReducer = (
  state = defaultDeletingUserState,
  action: DeleteUserActionTypes
): UserState => {
  switch (action.type) {
      case DELETE_USER_IDLE:
          return { status: SendingStatus.Idle, item: new User(), errorMsg: "", directive: {} };

      case DELETE_USER_START:
          return { status: SendingStatus.InProgress, item: state.item, errorMsg: "", directive: {} };

      case DELETE_USER_SUCCESS:
          return { status: SendingStatus.Success, item: action.item, errorMsg: "", directive: action.directive };

      case DELETE_USER_FAILURE:
          return {
              status: SendingStatus.Failure,
              item: state.item,
              errorMsg: action.errorMsg,
              directive: action.directive
          };

      default:
          return state;
  }
};

