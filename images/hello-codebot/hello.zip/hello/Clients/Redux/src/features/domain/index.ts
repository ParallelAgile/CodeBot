import { ApiDirective } from "../../client/ApiResult";
import DomainClass from "../../model/_DomainClass";

export enum SendingStatus {
  Idle,
  InProgress,
  Success,
  Failure
}

/**
 * Load a single item from the API.
 */
export interface LoadItemAsync<T extends DomainClass> {
    loading: boolean;
    item: T | null;
    errorMsg: string;
    directive: ApiDirective;
}

/**
 * Load multiple items from the API.
 */
export interface LoadItemsAsync<T extends DomainClass> {
    loading: boolean;
    items: T[];
    errorMsg: string;
    directive: ApiDirective;
}

/**
 * Create a single item via the API.
 */
export interface CreateItemAsync<T extends DomainClass> {
  creating: boolean;
  item: T | null;
  errorMsg: string;
  directive: ApiDirective;
}

/**
 * Create multiple items via the API.
 */
export interface CreateItemsAsync<T extends DomainClass> {
  creating: boolean;
  items: T[];
  errorMsg: string;
  directive: ApiDirective;
}

/**
 * Delete a single item via the API.
 */
export interface DeleteItemAsync<T extends DomainClass> {
  deleting: boolean;
  item: T | null;
  errorMsg: string;
  directive: ApiDirective;
}
