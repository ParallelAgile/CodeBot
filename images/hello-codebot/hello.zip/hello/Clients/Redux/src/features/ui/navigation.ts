import { push } from "connected-react-router";
import { read_cookie } from "sfcookies";

import HelloCodeBotApi from "../../client/HelloCodeBotApi";
import { ApiDirective } from "../../client/ApiResult";
import global_consts from "../../global_consts";

export type SessionCookie = {
    jwt: string | null;
    userId: string | null;
    username: string | null;
};
export const sessionCookieName = "hello.session";

export const loginCheck = (ifLoggedIn: (directive: ApiDirective) => void | null, ifLoggedOut: () => void) => {
    function callLoggedIn() {
        if (ifLoggedIn) {
            HelloCodeBotApi.client.loggedIn().then((result) => {
                result.status === 200 ? ifLoggedIn(result.directive) : ifLoggedOut();
            });
        }
    }

    if (HelloCodeBotApi.client.jwtToken == null) {                                       // if the webClient hasn't yet been logged-in...
        const session: SessionCookie = read_cookie(sessionCookieName); // ... then see if we can resume with a cached JWT token.
        if (session.username && session.jwt && session.userId) {
            HelloCodeBotApi.client.setJwtToken(session.jwt);
            callLoggedIn();
        } else {
            ifLoggedOut();
        }
    } else {
        callLoggedIn();
    }
};

export const checkLoggedIn = dispatch => {
    loginCheck(
        () => null,                             // if logged in, do nothing
        () => navigateToLoginPage({})(dispatch) // if not logged in, jump to the login page
    );
};

export const checkLoggedOut = dispatch => {
    loginCheck(
        (directive: ApiDirective) => { // if logged in, jump to the initial logged-in page
            navigateToInitialPage(directive)(dispatch);
        },
        () => {}                       // if not logged in, do nothing
    );
};

export const navigateToPage = (route: string, directive: ApiDirective) => (dispatch) => {
    if (typeof directive.route === "string") {
        route = directive.route;
    }
    if (!route.startsWith("/")) route = "/" + route;
    dispatch(push(global_consts.routesPrefix + route));
};

export const navigateToLoginPage = (directive: ApiDirective) => (dispatch) => {
    navigateToPage("/Login", directive)(dispatch);
}

export const navigateToInitialPage = (directive: ApiDirective) => (dispatch) => {
    navigateToPage("/Home", directive)(dispatch);
}
