import { action } from "typesafe-actions";
import { bake_cookie } from "sfcookies";

import store from "../../../../store";
import { ApiDirective } from "../../../../client/ApiResult"
import { loginCheck, navigateToInitialPage, SessionCookie, sessionCookieName } from "../../navigation";
import HelloCodeBotApi from "../../../../client/HelloCodeBotApi";
import { clearLoginStatus, login } from "../../../domain/user/actions";
import { selectLoggingIn } from "../../../domain/user/selectors";

import { InformUser } from "../../../../InformUser"
import { SendingStatus } from "../../../domain"

import User, { UserLogin } from "../../../../model/User"
import { navigateToPage } from "../../navigation"
import { FORM_CHANGED } from "./ActionTypes"
import { FORM_CLEARED } from "./ActionTypes"


// Action creators for the LoginForm Container:

export const loginFormSendLogin = () => dispatch => {
    const state = store.getState().ui.login_LoginForm;
    dispatch(login(state.item, onLoginSuccess));
};

const onLoginSuccess = (user: User) => {
    saveJwtCookie(user);
};

const saveJwtCookie = (user: User) => {
    const newSession: SessionCookie = {
        jwt: HelloCodeBotApi.client.jwtToken,
        username: user.username,
        userId: user.id
    };

    bake_cookie(sessionCookieName, newSession);
};
export const loginFormFormChanged = (oldItem: UserLogin, fieldName: string, value: string | number | boolean) =>
    action(FORM_CHANGED, { oldItem, fieldName, value });

export const loginFormFormCleared = () =>
    action(FORM_CLEARED, { emptyItem: new UserLogin() });



// Listen for state changes affecting this component:

store.subscribe(() => {
    const state = store.getState();

    const loggingIn = selectLoggingIn(state);

    if (loggingIn.status === SendingStatus.Failure) {
        clearLoginStatus()(store.dispatch);
        InformUser.error(loggingIn.errorMsg);
    } else if (loggingIn.status === SendingStatus.Success && loggingIn.item) {
        clearLoginStatus()(store.dispatch);
        navigateToInitialPage(loggingIn.directive)(store.dispatch);
        InformUser.info(`Welcome, ${loggingIn.item.username}`);
    }

});
