/**
 * invoked when the user clicks the Register button
 */
export const SEND_REGISTER = "register/client_area/SEND_REGISTER"

/**
 * invoked when the user types something into the form
 */
export const FORM_CHANGED = "register/client_area/FORM_CHANGED"

/**
 * invoked when the submit action completes successfully
 */
export const FORM_CLEARED = "register/client_area/FORM_CLEARED"

