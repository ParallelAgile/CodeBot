/**
 * invoked when the user clicks Logout
 */
export const SEND_LOGOUT = "home/logout/SEND_LOGOUT"

/**
 * invoked once the user has logged out
 */
export const SEND_LOGOUT_RESULT = "home/logout/SEND_LOGOUT_RESULT"

