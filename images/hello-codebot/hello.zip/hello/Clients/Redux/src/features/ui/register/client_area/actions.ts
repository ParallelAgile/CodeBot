import { action } from "typesafe-actions";

import store from "../../../../store";

import { InformUser } from "../../../../InformUser"
import { SendingStatus } from "../../../domain"

import User from "../../../../model/User"
import { clearRegisteringUserStatus } from "../../../domain/user/actions"
import { registerUser } from "../../../domain/user/actions"
import { selectRegisteringUser } from "../../../domain/user/selectors"
import { navigateToPage } from "../../navigation"
import { FORM_CHANGED } from "./ActionTypes"
import { FORM_CLEARED } from "./ActionTypes"


// Action creators for the ClientArea Container:

export const clientAreaSendRegister = () => dispatch => {
    const stateToSend = store.getState().ui.register_ClientArea;
    dispatch(registerUser(stateToSend.item));
};

export const clientAreaFormChanged = (oldItem: User, fieldName: string, value: string | number | boolean) =>
    action(FORM_CHANGED, { oldItem, fieldName, value });

export const clientAreaFormCleared = () =>
    action(FORM_CLEARED, { emptyItem: new User() });



// Listen for state changes affecting this component:

store.subscribe(() => {
    const state = store.getState();

    // Listen for result of the above 'sendRegister' form submit action:
    const registeringUser = selectRegisteringUser(state);

    if (registeringUser.status === SendingStatus.Failure) {
        clearRegisteringUserStatus()(store.dispatch);
        InformUser.error(registeringUser.errorMsg);
    } else if (registeringUser.status === SendingStatus.Success) {
        clearRegisteringUserStatus()(store.dispatch);
        store.dispatch(clientAreaFormCleared());

        navigateToPage("Login", registeringUser.directive)(store.dispatch);
    }


});
