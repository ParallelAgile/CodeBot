import { Dispatch } from "redux";
import store from "../../../store";

import { CreateItemAsync, DeleteItemAsync, LoadItemAsync, LoadItemsAsync, SendingStatus } from "..";
import {
    selectDeletingVideoStatus,
    selectCreatingVideoStatus,
    selectLoadingAllVideoItems
} from "./selectors"

import { ApiDirective } from "../../../client/ApiResult"
import HelloCodeBotApi from "../../../client/HelloCodeBotApi";

import Video from "../../../model/Video";

// action types:

export const LOAD_VIDEO_IDLE = "domain_video/LOAD_IDLE";
export const LOAD_VIDEO_START = "domain_video/LOAD_START";
export const LOAD_VIDEO_SUCCESS = "domain_video/LOAD_SUCCESS";
export const LOAD_VIDEO_FAILURE = "domain_video/LOAD_FAILURE";

export const LOAD_VIDEO_ITEMS_IDLE = "domain_video_items/LOAD_ITEMS_IDLE";
export const LOAD_VIDEO_ITEMS_START = "domain_video_items/LOAD_ITEMS_START";
export const LOAD_VIDEO_ITEMS_SUCCESS = "domain_video_items/LOAD_ITEMS_SUCCESS";
export const LOAD_VIDEO_ITEMS_FAILURE = "domain_video_items/LOAD_ITEMS_FAILURE";

export const CREATE_VIDEO_IDLE = "domain_video/CREATE_IDLE";
export const CREATE_VIDEO_START = "domain_video/CREATE_START";
export const CREATE_VIDEO_SUCCESS = "domain_video/CREATE_SUCCESS";
export const CREATE_VIDEO_FAILURE = "domain_video/CREATE_FAILURE";

export const DELETE_VIDEO_IDLE = "domain_video_items/DELETE_IDLE";
export const DELETE_VIDEO_START = "domain_video_items/DELETE_START";
export const DELETE_VIDEO_SUCCESS = "domain_video_items/DELETE_SUCCESS";
export const DELETE_VIDEO_FAILURE = "domain_video_items/DELETE_FAILURE";

interface LoadVideoIdle extends LoadItemAsync<Video> {
    type: typeof LOAD_VIDEO_IDLE;
}
interface LoadVideoStart extends LoadItemAsync<Video> {
    type: typeof LOAD_VIDEO_START;
}
interface LoadVideoSuccess extends LoadItemAsync<Video> {
    type: typeof LOAD_VIDEO_SUCCESS;
}
interface LoadVideoFailure extends LoadItemAsync<Video> {
    type: typeof LOAD_VIDEO_FAILURE;
}

interface LoadVideoItemsIdle extends LoadItemsAsync<Video> {
    type: typeof LOAD_VIDEO_ITEMS_IDLE;
}
interface LoadVideoItemsStart extends LoadItemsAsync<Video> {
    type: typeof LOAD_VIDEO_ITEMS_START;
}
interface LoadVideoItemsSuccess extends LoadItemsAsync<Video> {
    type: typeof LOAD_VIDEO_ITEMS_SUCCESS;
}
interface LoadVideoItemsFailure extends LoadItemsAsync<Video> {
    type: typeof LOAD_VIDEO_ITEMS_FAILURE;
}

interface CreateVideoIdle extends CreateItemAsync<Video> {
    type: typeof CREATE_VIDEO_IDLE;
}
interface CreateVideoStart extends CreateItemAsync<Video> {
    type: typeof CREATE_VIDEO_START;
}
interface CreateVideoSuccess extends CreateItemAsync<Video> {
    type: typeof CREATE_VIDEO_SUCCESS;
}
interface CreateVideoFailure extends CreateItemAsync<Video> {
    type: typeof CREATE_VIDEO_FAILURE;
}

interface DeleteVideoIdle extends DeleteItemAsync<Video> {
    type: typeof DELETE_VIDEO_IDLE;
}
interface DeleteVideoStart extends DeleteItemAsync<Video> {
    type: typeof DELETE_VIDEO_START;
}
interface DeleteVideoSuccess extends DeleteItemAsync<Video> {
    type: typeof DELETE_VIDEO_SUCCESS;
}
interface DeleteVideoFailure extends DeleteItemAsync<Video> {
    type: typeof DELETE_VIDEO_FAILURE;
}


export type VideoActionTypes =  LoadVideoIdle | LoadVideoStart | LoadVideoSuccess | LoadVideoFailure;
export type LoadVideoItemsActionTypes = LoadVideoItemsIdle | LoadVideoItemsStart | LoadVideoItemsSuccess | LoadVideoItemsFailure;
export type CreateVideoActionTypes = CreateVideoIdle | CreateVideoStart | CreateVideoSuccess | CreateVideoFailure;
export type DeleteVideoActionTypes = DeleteVideoIdle | DeleteVideoStart | DeleteVideoSuccess | DeleteVideoFailure;


// actions:

// Loading Video items: -------------------------------------------------------

const loadVideoItemsIdle = (items: Video[] = []): LoadVideoItemsActionTypes => ({
    type: LOAD_VIDEO_ITEMS_IDLE,
    loading: false,
    items: items,
    errorMsg: "",
    directive: {}
});
const loadVideoItemsStart = (): LoadVideoItemsActionTypes => ({
    type: LOAD_VIDEO_ITEMS_START,
    loading: true,
    items: [],
    errorMsg: "",
    directive: {}
});
const loadVideoItemsSuccess = (items: Video[], directive: ApiDirective): LoadVideoItemsActionTypes => ({
    type: LOAD_VIDEO_ITEMS_SUCCESS,
    loading: false,
    items: items,
    errorMsg: "",
    directive: directive
});
const loadVideoItemsFailure = (errorMsg: string, directive: ApiDirective): LoadVideoItemsActionTypes => ({
    type: LOAD_VIDEO_ITEMS_FAILURE,
    loading: false,
    items: [],
    errorMsg: errorMsg,
    directive: directive
});

/**
 * No longer loading Video items. The UI can call this to clear the result once it's notified the user.
 */
export const clearLoadingVideoItemsStatus = (dispatch: Dispatch<LoadVideoItemsActionTypes>) => {
  const loading = selectLoadingAllVideoItems(store.getState());
  if (loading.status !== SendingStatus.Idle) {
      dispatch(loadVideoItemsIdle(loading.items));
  }
};

/**
 * Load the Video items from the REST API.
 */
export const requestVideoItems = (dispatch: Dispatch<LoadVideoItemsActionTypes>) => {
    dispatch(loadVideoItemsStart());
    return HelloCodeBotApi.client.videoApi.findAll().then((result) => {
        if (result.isOk) {
            dispatch(loadVideoItemsSuccess(result.items, result.directive));
        } else {
            console.log("Error loading  video items: " + result.message);
            dispatch(loadVideoItemsFailure(result.message, result.directive));
        }
    });
};


// Creating Video: -------------------------------------------------------

const createVideoIdle = (): CreateVideoActionTypes => ({
    type: CREATE_VIDEO_IDLE,
    creating: false,
    item: null,
    errorMsg: "",
    directive: {}
});
const createVideoStart = (item: Video): CreateVideoActionTypes => ({
    type: CREATE_VIDEO_START,
    creating: true,
    item: item,
    errorMsg: "",
    directive: {}
});
const createVideoSuccess = (itemWithId: Video, directive: ApiDirective): CreateVideoActionTypes => ({
    type: CREATE_VIDEO_SUCCESS,
    creating: false,
    item: itemWithId,
    errorMsg: "",
    directive: directive
});
const createVideoFailure = (errorMsg: string, originalItem: Video, directive: ApiDirective): CreateVideoActionTypes => ({
    type: CREATE_VIDEO_FAILURE,
    creating: false,
    item: originalItem,
    errorMsg: errorMsg,
    directive: directive
});

/**
 * Create the Video via the REST API.
 */
export const createVideo = (item: Video) => (dispatch: Dispatch<any>) => {
    dispatch(createVideoStart(item));

    return HelloCodeBotApi.client.videoApi.createOne(item).then((result) => {
        if (result.isOk && result.newItem) {
            dispatch(createVideoSuccess(result.newItem, result.directive));
            dispatch(requestVideoItems) // reload the Video items so ListBoxes etc are updated
        } else {
            dispatch(createVideoFailure(result.message, item, result.directive));
        }
    });
};

/**
 * No longer creating a Video. The UI can call this to clear the result once it's notified the user.
 */
export const clearCreatingVideoStatus = () => (dispatch: Dispatch<CreateVideoActionTypes>) => {
    if (selectCreatingVideoStatus(store.getState()) !== SendingStatus.Idle) {
        dispatch(createVideoIdle());
    }
};


// Delete Video: -------------------------------------------------------

export const deleteVideoIdle = (): DeleteVideoActionTypes => ({
    type: DELETE_VIDEO_IDLE,
    deleting: false,
    item: null,
    errorMsg: "",
    directive: {}
});
export const deleteVideoStart = (item: Video): DeleteVideoActionTypes => ({
    type: DELETE_VIDEO_START,
    deleting: true,
    item: item,
    errorMsg: "",
    directive: {}
});
export const deleteVideoSuccess = (itemWithId: Video, directive: ApiDirective): DeleteVideoActionTypes => ({
    type: DELETE_VIDEO_SUCCESS,
    deleting: false,
    item: itemWithId,
    errorMsg: "",
    directive: directive
});
export const deleteVideoFailure = (errorMsg: string, originalItem: Video, directive: ApiDirective): DeleteVideoActionTypes => ({
    type: DELETE_VIDEO_FAILURE,
    deleting: false,
    item: originalItem,
    errorMsg: errorMsg,
    directive: directive
});

/**
 * No longer deleting a Video. The UI can call this to clear the result once it's notified the user.
 */
export const clearDeletingVideoStatus = () => (dispatch: Dispatch<DeleteVideoActionTypes>) => {
  if (selectDeletingVideoStatus(store.getState()) !== SendingStatus.Idle) {
      dispatch(deleteVideoIdle());
  }
};

/**
 * Delete the Video via the REST API.
 */
export const deleteVideo = (item: Video) => (dispatch: Dispatch<any>) => {
    dispatch(deleteVideoStart(item));

    return HelloCodeBotApi.client.videoApi.deleteOne(item.id).then((result) => {
        if (result.isOk) {
            dispatch(deleteVideoSuccess(item, result.directive));
            dispatch(requestVideoItems)
        } else {
            dispatch(deleteVideoFailure(result.message, item, result.directive));
        }
    });
};
