import { combineReducers } from "redux";

import { loggingInReducer, registeringUserReducer } from "./user/reducer";
import { creatingUserReducer, loadingUserItemsReducer, deletingUserReducer } from "./user/reducer";
import { creatingVideoReducer, loadingVideoItemsReducer, deletingVideoReducer } from "./video/reducer";

const createRootDomainReducer = () =>
    combineReducers({
        loggingIn: loggingInReducer,
        registeringUser: registeringUserReducer,

        // Domain state - combined from any components with "domain" tags
        // When components start to have custom data-sets e.g. a "filter" tag, they'll need separate entries here.

        loadingUserItems: loadingUserItemsReducer,
        creatingUser: creatingUserReducer,
        deletingUser: deletingUserReducer,

        loadingVideoItems: loadingVideoItemsReducer,
        creatingVideo: creatingVideoReducer,
        deletingVideo: deletingVideoReducer
    });

export default createRootDomainReducer;
