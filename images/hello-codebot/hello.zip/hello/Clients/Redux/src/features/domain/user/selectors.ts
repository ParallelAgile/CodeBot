import { AppState } from "../../../store";
import { SendingStatus } from ".."
import {UserState, UserItemsState } from "./reducer"
import User from "../../../model/User";

export const selectLoggingIn: (state: AppState) => UserState = (state: AppState) => state.domain.loggingIn;
export const selectLoggingInStatus: (state: AppState) => SendingStatus = (state: AppState) => state.domain.loggingIn.status;

export const selectRegisteringUser: (state: AppState) => UserState = (state: AppState) => state.domain.registeringUser;
export const selectRegisteringUserStatus: (state: AppState) => SendingStatus = (state: AppState) => state.domain.registeringUser.status;

export const selectLoadingAllUserItems: (state: AppState) => UserItemsState = (state: AppState) => state.domain.loadingUserItems;
export const selectLoadingAllUserItemsStatus: (state: AppState) => SendingStatus = (state: AppState) => state.domain.loadingUserItems.status;
export const selectAllUserItems: (state: AppState) => User[] = (state: AppState) => state.domain.loadingUserItems.items;

export const selectCreatingUser: (state: AppState) => UserState = (state: AppState) => state.domain.creatingUser;
export const selectCreatingUserStatus: (state: AppState) => SendingStatus = (state: AppState) => state.domain.creatingUser.status;

export const selectDeletingUser: (state: AppState) => UserState = (state: AppState) => state.domain.deletingUser;
export const selectDeletingUserStatus: (state: AppState) => SendingStatus = (state: AppState) => state.domain.deletingUser.status;
