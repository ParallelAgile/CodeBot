import { AppState } from "../../../../store";

import Video from "../../../../model/Video"

// These selectors retrieve data from the 'ui' state.

export const selectHome_ChooseAVideo_ChosenItem: (s: AppState) => Video | null = (state: AppState) =>
    state.ui.home_ChooseAVideo.selected.item;

