import { combineReducers } from "redux";
import { ActionType } from "typesafe-actions";

import * as actions from "./actions";
import { SEND_LOGOUT, SEND_LOGOUT_RESULT } from "./ActionTypes";
import { LogoutResult } from "../../../../client/ApiResult";


type State = {
    readonly loggingOut: LogoutResult | null;
}

type Action = ActionType<typeof actions>;

export default combineReducers<State, Action>({
    /**
     * Global "logging out" state for Logout in the Home page.
     */
    loggingOut: (state = null, action) => {
        // The actions here are exported from ./actions.ts, and types from ./ActionTypes.ts:
        switch (action.type) {
            case SEND_LOGOUT_RESULT:
                return action.payload.result

            default:
                return state;
        }
    }
});
