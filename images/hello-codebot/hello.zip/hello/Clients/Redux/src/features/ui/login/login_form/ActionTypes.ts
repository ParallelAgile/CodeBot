/**
 * invoked when the user clicks the Login button
 */
export const SEND_LOGIN = "login/login_form/SEND_LOGIN"

/**
 * invoked when the user types something into the form
 */
export const FORM_CHANGED = "login/login_form/FORM_CHANGED"

/**
 * invoked when the submit action completes successfully
 */
export const FORM_CLEARED = "login/login_form/FORM_CLEARED"

