import { action } from "typesafe-actions";

import store from "../../../../store";

import { InformUser } from "../../../../InformUser"
import { SendingStatus } from "../../../domain"

import { LogoutResult } from "../../../../client/ApiResult"
import HelloCodeBotApi from "../../../../client/HelloCodeBotApi"
import { navigateToLoginPage } from "../../navigation"
import { sessionCookieName } from "../../navigation"
import { SEND_LOGOUT_RESULT } from "./ActionTypes"
import { delete_cookie } from "sfcookies"


// Action creators for the Logout Button:

/**
 * JWT tokens are non-cancellable by nature; so here we can only really "forget" the token in this app.
 */
export const logoutSendLogout = () => dispatch => {
    delete_cookie(sessionCookieName);
    HelloCodeBotApi.client.logout();
    const result = new LogoutResult("You're logged out. You might still be logged-in on other devices.");
    dispatch(logoutSendLogoutResult(result));
    dispatch(navigateToLoginPage({}));
};
export const logoutSendLogoutResult = (result: LogoutResult) =>
    action(SEND_LOGOUT_RESULT, {
        result
    });



// Listen for state changes affecting this component:

store.subscribe(() => {
    const state = store.getState();


});
