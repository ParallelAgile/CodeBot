import { combineReducers } from "redux";
import { ActionType } from "typesafe-actions";

import * as actions from "./actions";
import { SEND_LOGIN, FORM_CHANGED, FORM_CLEARED } from "./ActionTypes";
import { UserLogin } from "../../../../model/User";


type State = {
    readonly item: UserLogin;
}

type Action = ActionType<typeof actions>;

export default combineReducers<State, Action>({
    /**
     * Global "login credentials" state for Login form in the Login page.
     */
    item: (state = new UserLogin(), action) => {
        // The actions here are exported from ./actions.ts, and types from ./ActionTypes.ts:
        switch (action.type) {
            case FORM_CHANGED:
                const newState = {
                    ...state
                };
                newState[action.payload.fieldName] = action.payload.value;
                return newState;

            case FORM_CLEARED:
                return action.payload.emptyItem;

            default:
                return state;
        }
    }
});
