import {
    CreateManyResult,
    CreateResult,
    DeleteResult,
    FindManyResult,
    FindResult,
    LoggedInResult,
    LoginResult,
    LogoutResult,
    RegisterResult,
    ReplaceResult,
    UpdateResult,
} from "../ApiResult";

import DomainApi from "./_DomainApi"
import HelloCodeBotApi from "../HelloCodeBotApi"
import User, { UserLogin } from "../../model/User";

export class UserApi implements DomainApi<User> {

    private readonly api: HelloCodeBotApi

    public constructor(api: HelloCodeBotApi) {
        this.api = api
    }

    public login(credentials: UserLogin): Promise<LoginResult> {
        return this.api.login(credentials)
    }
    public logout(): Promise<LogoutResult> {
        return this.api.logout()
    }
    public loggedIn(): Promise<LoggedInResult> {
        return this.api.loggedIn()
    }

    public registerUser(user: User): Promise<RegisterResult> {

        return this.api.register(user)
    }

    public deleteAll(): Promise<DeleteResult> {
        return this.api.deleteAll("User")
    }

    public deleteOne(userId: string): Promise<DeleteResult> {
        return this.api.deleteOne(userId, "User")
    }

    public createOne(user: User): Promise<CreateResult<User>> {
        return this.api.createOne(user, "User")
    }

    public createMany(entities: User[]): Promise<CreateManyResult<User>> {
        return this.api.createMany(entities, "User")
    }

    public replace(user: User): Promise<ReplaceResult<User>> {
        return this.api.replace(user, user.id, "User")
    }

    public update(userId: string, attributesToReplace: any): Promise<UpdateResult<User>> {
        return this.api.update(userId, attributesToReplace, "User")
    }

    public findOne(id: string): Promise<FindResult<User>> {
        return this.api.findOne(id, "User")
    }

    public findAll(): Promise<FindManyResult<User>> {
        return this.api.findAll("User")
    }

    public findSome(searchParams: object): Promise<FindManyResult<User>> {
        return this.api.findSome("User", searchParams)
    }
}

export default UserApi
