import {
    CreateManyResult,
    CreateResult,
    DeleteResult,
    FindManyResult,
    FindResult,
    ReplaceResult,
    UpdateResult,
} from "../ApiResult";

import DomainApi from "./_DomainApi"
import HelloCodeBotApi from "../HelloCodeBotApi"
import Video from "../../model/Video";

export class VideoApi implements DomainApi<Video> {

    private readonly api: HelloCodeBotApi

    public constructor(api: HelloCodeBotApi) {
        this.api = api
    }

    public deleteAll(): Promise<DeleteResult> {
        return this.api.deleteAll("Video")
    }

    public deleteOne(videoId: string): Promise<DeleteResult> {
        return this.api.deleteOne(videoId, "Video")
    }

    public createOne(video: Video): Promise<CreateResult<Video>> {
        return this.api.createOne(video, "Video")
    }

    public createMany(entities: Video[]): Promise<CreateManyResult<Video>> {
        return this.api.createMany(entities, "Video")
    }

    public replace(video: Video): Promise<ReplaceResult<Video>> {
        return this.api.replace(video, video.id, "Video")
    }

    public update(videoId: string, attributesToReplace: any): Promise<UpdateResult<Video>> {
        return this.api.update(videoId, attributesToReplace, "Video")
    }

    public findOne(id: string): Promise<FindResult<Video>> {
        return this.api.findOne(id, "Video")
    }

    public findAll(): Promise<FindManyResult<Video>> {
        return this.api.findAll("Video")
    }

    public findSome(searchParams: object): Promise<FindManyResult<Video>> {
        return this.api.findSome("Video", searchParams)
    }
}

export default VideoApi
