import {
    CreateManyResult,
    CreateResult,
    DeleteResult,
    ReplaceResult,
    UpdateResult,
    FindResult,
    FindManyResult,
} from "../ApiResult";

import DomainClass from "../../model/_DomainClass";

export default interface DomainApi<T extends DomainClass> {
    findOne(id: string): Promise<FindResult<T>>;

    findAll(): Promise<FindManyResult<T>>;

    createOne(item: T): Promise<CreateResult<T>>;

    createMany(items: T[]): Promise<CreateManyResult<T>>;

    replace(item: T): Promise<ReplaceResult<T>>;

    update(id: string, attributesToReplace: any): Promise<UpdateResult<T>>;

    deleteAll(): Promise<DeleteResult>;

    deleteOne(id: string): Promise<DeleteResult>;
}
