import axios, { AxiosResponse } from "axios";
import {
    ApiDirective,
    CreateManyResult,
    CreateResult,
    DeleteResult,
    FindManyResult,
    FindResult,
    LoggedInResult,
    LoginResult,
    LogoutResult,
    RegisterResult,
    ReplaceResult,
    UpdateResult
} from "./ApiResult";

import User, { UserLogin } from "../model/User";
import DomainClass from "../model/_DomainClass";

import UserApi from "./api/UserApi";
import VideoApi from "./api/VideoApi";

import global_consts from "../global_consts";

const loginFirstMsg = "Please login first.";

export default class HelloCodeBotApi {
    private readonly rootUrl: string;

    public jwtToken: string | null = null;

    public readonly userApi: UserApi;
    public readonly videoApi: VideoApi;

    /**
     * Should be called *once only*, via one of the "initialiseClientFor.." methods below,
     * After that you can use HelloCodeBotApi.client throughout the app.
     */
    private static setClient(client: HelloCodeBotApi) {
         HelloCodeBotApi.client = client;
    }

    public static client: HelloCodeBotApi

    /**
     * Initialise the API client from global_consts.ts.
     */
    public static initialiseClient() {
        const useUrl = global_consts.apiUrlRoot + global_consts.apiPath
        HelloCodeBotApi.initialiseClientForUrl(useUrl, global_consts.apiAccessToken)
    }

    /**
     * For web-apps -- connect to a URI relative to the current domain.
     */
    public static initialiseClientForWeb() {
        HelloCodeBotApi.initialiseClientForUrl("/matt/hello")
    }

    /**
     * Connect to your API if hosted at parallelagile.net.
     */
    public static initialiseClientForPaHosting(paHostingAccessToken: string) {
        HelloCodeBotApi.initialiseClientForUrl("https://parallelagile.net/hosted/matt/hello", paHostingAccessToken)
    }

    /**
     * Connect to your API (in the /Server directory) running locally.
     */
    public static initialiseClientForLocalhost() {
        HelloCodeBotApi.initialiseClientForUrl("http://localhost:7000/matt/hello")
    }

    public static initialiseClientForUrl(url: string, paHostingAccessToken?: string) {
        HelloCodeBotApi.client = new HelloCodeBotApi(url, paHostingAccessToken)
    }

    private constructor(url: string, paHostingAccessToken?: string) {
        this.rootUrl = url;

        axios.defaults.headers.common["Content-Type"] = "application/json";
        if (paHostingAccessToken) axios.defaults.headers.common["PaAccessToken"] = paHostingAccessToken

        this.userApi = new UserApi(this)
        this.videoApi = new VideoApi(this)
    }

    private toErrorMsg(err) {
        console.log(err);
        const data = err?.response?.data;
        if (data) {
            return (data.message && data.validationErrors)
                ? `${data.message}:\n${data.validationErrors}`
                : data.message || err.message || "Sorry, the request returned an error, please try again."
        } else {
            return "There was a problem trying to contact the server."
        }
    }

    public async login(credentials: UserLogin): Promise<LoginResult> {
        try {
            const response: AxiosResponse = await axios.post(this.rootUrl + "/User/login", credentials)

            let msg: string;
            switch (response.status) {
                case 200:
                    const userJson = response.data;
                    const jwt = userJson["jwt"] || "";
                    this.setJwtToken(jwt);
                    const user: User = userJson["data"] || new User();
                    const directive: ApiDirective = userJson["directive"] || {};
                    return new LoginResult("You're logged in.", response.status, directive, user);

                case 401:
                case 403:
                    msg = response.data.message ? response.data.message : "Invalid login, please try again...";
                    return new LoginResult(msg, response.status, {});

                default:
                    msg = response.data.message ? response.data.message : "Unable to log you in, please try again.";
                    return new LoginResult(msg, response.status, {});
            }
        } catch (err) {
            return new LoginResult(this.toErrorMsg(err), err.response.status || 0, {});
        }
    }

    public setJwtToken(jwt: string | null) {
        this.jwtToken = jwt;
        if (jwt) axios.defaults.headers.common.Authorization = "Bearer " + jwt;
        else delete axios.defaults.headers.common.Authorization;
    }

    public logout(): Promise<LogoutResult> {
        this.setJwtToken(null);
        return Promise.resolve(new LogoutResult("You're logged out."))
    }

    public async loggedIn(): Promise<LoggedInResult> {
        if (!this.jwtToken) return new LoggedInResult(loginFirstMsg, 401, {});

        return axios.get(`${this.rootUrl}/User/loggedIn`)
            .then((response: AxiosResponse) => {
                const directive: ApiDirective = response.data.directive;

                return response.status === 200
                    ? new LoggedInResult("Logged in", response.status, directive, response.data)
                    : new LoggedInResult(response.data.message, response.status, directive);
            })
            .catch(err => {
                console.log(err);
                return new LoggedInResult((err.response?.data.message || "") + "\n" + err, 0, {});
            });
    }

    public async register(entity: User): Promise<RegisterResult> {
        try {
            const response: AxiosResponse = await axios.post(this.rootUrl + "/User/register", entity);
            const directive: ApiDirective = response.data.directive;

            if (response.status === 200 || response.status === 201) {
                const item: User = response.data.data; // should be the just-registered User with its new ID.
                return new RegisterResult("Registered", response.status, directive, item);
            } else {
                return new RegisterResult(response.data.message, response.status, directive);
            }
        } catch (err) {
            return new RegisterResult(this.toErrorMsg(err), err.response.status || 0, {});
        }
    }

    public async createOne<T extends DomainClass>(entity: T, className: string): Promise<CreateResult<T>> {
        if (!this.jwtToken) return new CreateResult(loginFirstMsg, 401, {});

        try {
            const response: AxiosResponse = await axios.post(this.rootUrl + "/" + className, entity);
            const directive: ApiDirective = response.data.directive;

            if (response.status === 200 || response.status === 201) {
                const item: T = response.data.data; // should be the entity with its new ID.
                return new CreateResult("Created", response.status, directive, item);
            } else {
                return new CreateResult(response.data.message, response.status, directive);
            }
        } catch (err) {
            return new CreateResult(this.toErrorMsg(err), err.response?.status || 0, {});
        }
    }

    public async createMany<T extends DomainClass>(entities: T[], className: string): Promise<CreateManyResult<T>> {
        if (!this.jwtToken) return new CreateManyResult(loginFirstMsg, 401, {});

        try {
            const response: AxiosResponse = await axios.post(this.rootUrl + "/" + className, entities);
            const directive: ApiDirective = response.data.directive;

            return response.status === 200 || response.status === 201
                ? new CreateManyResult("Created", response.status, directive,
                    response.data.data // should be the entities with their new IDs.
                )
                : new CreateManyResult(response.data.message, response.status, directive);

        } catch (err) {
            return new CreateManyResult<T>(this.toErrorMsg(err), err.response.status || 0, {});
        }
    }

    public async findOne<T extends DomainClass>(id: string, className: string): Promise<FindResult<T>> {
        if (!this.jwtToken) return new FindResult<T>(loginFirstMsg, 401, {});

        try {
            const response: AxiosResponse = await axios.get(`${this.rootUrl}/${className}/${id}`);
            const directive: ApiDirective = response.data.directive;

            return response.status === 200
                ? new FindResult<T>("Found", response.status, directive, response.data)
                : new FindResult<T>(response.data.message, response.status, directive);

        } catch (err) {
            return new FindResult<T>(this.toErrorMsg(err), err.response.status || 0, {});
        }
    }

    public async findAll<T extends DomainClass>(className: string): Promise<FindManyResult<T>> {
        if (!this.jwtToken) return new FindManyResult<T>(loginFirstMsg, 401, {});

        try {
            const response: AxiosResponse = await axios.get(this.rootUrl + "/" + className);
            const directive: ApiDirective = response.data.directive;

            return response.status === 200
                ? new FindManyResult<T>("Found...", response.status, directive, response.data.data)
                : new FindManyResult<T>(response.data.message, response.status, directive);

        } catch (err) {
            return new FindManyResult<T>(this.toErrorMsg(err), err.response.status || 0, {});
        }
    }

    public async findSome<T extends DomainClass>(className: string, searchParams: object): Promise<FindManyResult<T>> {
        if (!this.jwtToken) return new FindManyResult<T>(loginFirstMsg, 401, {});

        try {
            const response: AxiosResponse = await axios.post(this.rootUrl + "/" + className, searchParams);
            const directive: ApiDirective = response.data.directive;

            return response.status === 200
                ? new FindManyResult<T>("Found...", response.status, directive, response.data.data)
                : new FindManyResult<T>(response.data.message, response.status, directive);

        } catch (err) {
            return new FindManyResult<T>(this.toErrorMsg(err), err.response.status || 0, {});
        }
    }

    public async deleteOne(id: string, className: string): Promise<DeleteResult> {
        if (!this.jwtToken) return new DeleteResult(loginFirstMsg, 401, {});

        try {
            const response: AxiosResponse = await axios.delete(this.rootUrl + "/" + className + "/" + id);
            const directive: ApiDirective = response.data.directive;

            return response.status === 200
                ? new DeleteResult("Deleted.", response.status, directive, response.data.deletedCount)
                : new DeleteResult(response.data.message, response.status, directive);

        } catch (err) {
            return new DeleteResult(this.toErrorMsg(err), err.response.status || 0, {});
        }
    }

    public async deleteAll(className: string): Promise<DeleteResult> {
        if (!this.jwtToken) return new DeleteResult(loginFirstMsg, 401, {});

        try {
            const response: AxiosResponse = await axios.delete(this.rootUrl + "/" + className);
            const directive: ApiDirective = response.data.directive;

            return response.status === 200
                ? new DeleteResult("Deleted.", response.status, directive, response.data.deletedCount)
                : new DeleteResult(response.data.message, response.status, directive, 0);

        } catch (err) {
            return new DeleteResult(this.toErrorMsg(err), err.response.status || 0, {});
        }
    }

    public async replace<T extends DomainClass>(
        newEntity: T,
        id: string,
        className: string
    ): Promise<ReplaceResult<T>> {
        if (!this.jwtToken) return new ReplaceResult<T>(loginFirstMsg, 401, {});

        try {
            const response: AxiosResponse = await axios.put(this.rootUrl + "/" + className + "/" + id, newEntity);
            const directive: ApiDirective = response.data.directive || {};

            return response.status === 200
                ? new ReplaceResult<T>("Updated.", response.status, directive, newEntity)
                : new ReplaceResult<T>(response.data.message, response.status, directive);

        } catch (err) {
            return new ReplaceResult<T>(this.toErrorMsg(err), err.response.status || 0, {});
        }
    }

    public async update<T extends DomainClass>(
        id: string,
        attributesToReplace: any,
        className: string
    ): Promise<UpdateResult<T>> {
        if (!this.jwtToken) return new UpdateResult<T>(loginFirstMsg, 401, {});

        try {
            const response: AxiosResponse = await axios.patch(
                `${this.rootUrl}/${className}/${id}`,
                attributesToReplace
            );
            const directive: ApiDirective = response.data.directive;

            return response.status === 200
                ? new UpdateResult<T>("Updated.", response.status, directive)
                : new UpdateResult<T>(response.data.message, response.status, directive);

        } catch (err) {
            return new UpdateResult<T>(this.toErrorMsg(err), err.response.status || 0, {});
        }
    }
}
