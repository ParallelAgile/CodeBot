import DomainClass from "../model/_DomainClass";
import User from "../model/User";

export type ApiDirective = {
    route?: string
}

export type ApiResult = {
    readonly isOk: boolean;
    readonly message: string;
    readonly status: number;
    readonly directive: ApiDirective;
};

abstract class AbstractApiresult implements ApiResult {
    public readonly isOk: boolean;
    public readonly message: string;
    public readonly status: number;
    public readonly directive: ApiDirective;

    constructor(message: string, status: number, directive: ApiDirective) {
        this.message = message;
        this.status = status;
        this.directive = directive;
        this.isOk = status === 200 || status === 201;
    }
}

export class CreateResult<T extends DomainClass> extends AbstractApiresult {
    public readonly newItem?: T

    constructor(message: string, status: number, directive: ApiDirective, newItem?: T) {
        super(message, status, directive)
        this.newItem = newItem
    }
}

export class ReplaceResult<T extends DomainClass> extends CreateResult<T> {
}
export class ReplaceManyResult<T extends DomainClass> extends CreateResult<T> {
}
export class UpdateResult<T extends DomainClass> extends CreateResult<T> {
}
export class UpdateManyResult<T extends DomainClass> extends CreateResult<T> {
}

export class CreateManyResult<T extends DomainClass> extends AbstractApiresult {
    public readonly newItems?: T[]

    constructor(message: string, status: number, directive: ApiDirective, newItems: T[] = []) {
        super(message, status, directive)
        this.newItems = newItems
    }
}

export class FindManyResult<T extends DomainClass> extends AbstractApiresult {
    public readonly items: T[];

    constructor(message: string, status: number, directive: ApiDirective, items: T[] = []) {
        super(message, status, directive);
        this.items = items;
    }
}

export class FindResult<T extends DomainClass> extends AbstractApiresult {
    public readonly item?: T;

    constructor(message: string, status: number, directive: ApiDirective, item?: T) {
        super(message, status, directive);
        this.item = item;
    }
}

export class LoginResult extends FindResult<User> {}
export class LoggedInResult extends FindResult<User> {}

export class LogoutResult extends AbstractApiresult {
    constructor(message: string, directive: ApiDirective = {}) {
        super(message, 200, directive)
    }
}

export class RegisterResult extends CreateResult<User> {}

export class DeleteResult extends AbstractApiresult {
    public readonly count: number;

    constructor(message: string, status: number, directive: ApiDirective, count: number = 0) {
        super(message, status, directive);
        this.count = count;
    }
}
