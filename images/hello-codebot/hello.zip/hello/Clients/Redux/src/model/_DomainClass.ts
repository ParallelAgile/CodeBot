export default interface DomainClass {
    id: string;
}
