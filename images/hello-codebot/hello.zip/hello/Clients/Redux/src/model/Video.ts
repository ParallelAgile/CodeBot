import DomainClass from "./_DomainClass";

export default class Video implements DomainClass {

    constructor(
        public readonly id: string = "",
        public readonly name: string = "",
        public readonly url: string = "",
    ) {
    }
}

