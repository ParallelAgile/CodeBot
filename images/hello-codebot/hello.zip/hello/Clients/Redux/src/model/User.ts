import DomainClass from "./_DomainClass";

export default class User implements DomainClass {

    constructor(
        public readonly id: string = "",
        public readonly username: string = "",
        public readonly password: string = "",
        public readonly email: string = "",
        public readonly roles: string[] = [],
    ) {
    }
}

export class UserLogin {
    constructor(public readonly username: string = "", public readonly password: string = "") {}
}
