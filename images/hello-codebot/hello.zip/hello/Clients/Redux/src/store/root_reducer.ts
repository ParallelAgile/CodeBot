import { combineReducers } from "redux";
import { connectRouter } from "connected-react-router";

import createRootDomainReducer from "../features/domain/root_domain_reducer";
import createRootUiReducer from "../features/ui/root_ui_reducer";

const createRootReducer = (history) =>
    combineReducers({
        router: connectRouter(history),
        ui: createRootUiReducer(),
        domain: createRootDomainReducer()
    });

export default createRootReducer;
