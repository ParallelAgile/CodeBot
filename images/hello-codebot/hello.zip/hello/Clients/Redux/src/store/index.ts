import { createStore, compose, applyMiddleware } from "redux";
import { routerMiddleware } from "connected-react-router";
import { createBrowserHistory } from "history";
import thunk from "redux-thunk";

import createRootReducer from "./root_reducer";

export const history = createBrowserHistory();

const rootReducer = createRootReducer(history);

const store = createStore(rootReducer, compose(applyMiddleware(routerMiddleware(history), thunk)));

export type AppState = ReturnType<typeof rootReducer>;

export default store;
