# JavaScript ES6 domain model for the Hello Code Bot.

Copyright (c) MattCo.

*** Contains robot-generated code which shouldn't be modified. ***

This library can be copied and reused in your own code. A copy also exists in the generated JavaScript ES6 Client library.
