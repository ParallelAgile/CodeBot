package com.parallelagile.model;

public interface DomainObject {

  /**
   * Optionally supply an ID when creating a new Account. This must conform to any ID restrictions in your target database,
   * e.g. a 24-character numeric string for MongoDB.
   * Alternatively (and preferably), leave the ID blank and allow the API/database to create a new random ID.
   */
  void setId(String id);

  String getId();

  default boolean isIdPresent() {
    return getId() != null && !getId().isEmpty();
  }
}

