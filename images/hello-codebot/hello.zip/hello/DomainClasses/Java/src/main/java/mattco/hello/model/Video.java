package mattco.hello.model;

import com.google.gson.annotations.SerializedName;
import com.parallelagile.model.DomainObject;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

 public class Video implements DomainObject {

    @SerializedName("id")
    protected String id;

    @SerializedName("name")
    protected String name;

    @SerializedName("url")
    protected String url;

    /**
     * No-arg constructor for object-mapping libraries.
     */
    public Video() {
    }

    /**
     * Create a new Video instance without an ID.
     * Useful if you're creating a new Video record via the API.
     */
    public Video(String name, String url) {
        this("", name, url);
    }

    public Video(String id, String name, String url) {
        this.id = id;
        this.name = name;
        this.url = url;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Video) {
            final Video other = (Video) o;
            return Objects.equals(id, other.id)
                && Objects.equals(name, other.name)
                && Objects.equals(url, other.url)
                ;
        } else return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, url);
    }

    public String toString() {
        return
            "name: " + name + ", " +
            "url: " + url + ", " +
            "id: " + id;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
      this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
      this.url = url;
    }

}
