package mattco.hello.model;

import com.google.gson.annotations.SerializedName;
import com.parallelagile.model.DomainObject;
import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

 public class User implements DomainObject {

    @SerializedName("id")
    protected String id;

    @SerializedName("username")
    protected String username;

    @SerializedName("password")
    protected String password;

    @SerializedName("email")
    protected String email;

    @SerializedName("roles")
    protected List<String> roles;

    /**
     * No-arg constructor for object-mapping libraries.
     */
    public User() {
    }

    /**
     * Create a new User instance without an ID.
     * Useful if you're creating a new User record via the API.
     */
    public User(String username, String password, String email, List<String> roles) {
        this("", username, password, email, roles);
    }

    public User(String id, String username, String password, String email, List<String> roles) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.roles = roles;
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof User) {
            final User other = (User) o;
            return Objects.equals(id, other.id)
                && Objects.equals(username, other.username)
                && Objects.equals(password, other.password)
                && Objects.equals(email, other.email)
                && Objects.equals(roles, other.roles)
                ;
        } else return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, username, password, email, roles);
    }

    public String toString() {
        return
            "username: " + username + ", " +
            "password: " + password + ", " +
            "email: " + email + ", " +
            "roles: " + roles + ", " +
            "id: " + id;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
      this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
      this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
      this.email = email;
    }

    public List<String> getRoles() {
        return roles;
    }

    public void setRoles(List<String> roles) {
      this.roles = roles;
    }

}
