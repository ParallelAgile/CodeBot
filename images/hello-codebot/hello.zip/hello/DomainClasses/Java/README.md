# Java domain model for the Hello CodeBot bounded context.

Copyright (c) MattCo.

*** Contains robot-generated code which shouldn't be modified. ***

This library can be used in conjunction with the generated Java client, or simply used within your own code.

To use, first build the library using Maven (build files for Gradle and Ivy are also included):

```
mvn clean install -Dmaven.repo.local=/home/{your username}/.m2/repository
```

In Windows, depending on where your local Maven repository is located the above might be:

```
mvn clean install -Dmaven.repo.local=C:/Users/{your username}/.m2/repository
```

This will build the library jar, and install a copy to your local Maven repository.

If an older version already exists, either delete the older version, or increment the version number in `pom.xml`.

If you're using Artifactory, this jar can also be published to your organization or project's Artifactory repo.

To use the library in your own project, add the following dependency to your Maven build file:

```
    <dependency>
      <groupId>mattco.hello</groupId>
      <artifactId>HelloCodeBot</artifactId>
      <version>1</version>
    </dependency>
```
