# TypeScript domain model for the HelloCodeBot.

Copyright (c) MattCo.

*** Contains robot-generated code which shouldn't be modified. ***

This library can be copied and reused in your own code. A copy also exists in the generated TypeScript Client library.


# Running the Domain library as a standalone app

First install `typescript` and `ts-node` as dev dependencies, by running:

 ```bash
 npm install --save
 ```

Once that's done, you can import and use the required domain class into the TypeScript REPL console, by typing:

 ```bash
 npx ts-node
 ```
